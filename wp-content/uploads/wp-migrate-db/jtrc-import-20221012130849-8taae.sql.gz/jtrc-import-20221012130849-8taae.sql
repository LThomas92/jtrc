# WordPress MySQL database migration
#
# Generated: Wednesday 12. October 2022 03:34 UTC
# Hostname: localhost
# Database: `jtrc`
# URL: //localhost:8888/jtrc
# Path: /Users/lawrence/Sites/localhost/jtrc
# Tables: wp_actionscheduler_actions, wp_actionscheduler_claims, wp_actionscheduler_groups, wp_actionscheduler_logs, wp_commentmeta, wp_comments, wp_gf_draft_submissions, wp_gf_entry, wp_gf_entry_meta, wp_gf_entry_notes, wp_gf_form, wp_gf_form_meta, wp_gf_form_revisions, wp_gf_form_view, wp_gf_rest_api_keys, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_wc_admin_note_actions, wp_wc_admin_notes, wp_wc_category_lookup, wp_wc_customer_lookup, wp_wc_download_log, wp_wc_order_coupon_lookup, wp_wc_order_product_lookup, wp_wc_order_stats, wp_wc_order_tax_lookup, wp_wc_product_attributes_lookup, wp_wc_product_download_directories, wp_wc_product_meta_lookup, wp_wc_rate_limits, wp_wc_reserved_stock, wp_wc_tax_rate_classes, wp_wc_webhooks, wp_woocommerce_api_keys, wp_woocommerce_attribute_taxonomies, wp_woocommerce_downloadable_product_permissions, wp_woocommerce_log, wp_woocommerce_order_itemmeta, wp_woocommerce_order_items, wp_woocommerce_payment_tokenmeta, wp_woocommerce_payment_tokens, wp_woocommerce_sessions, wp_woocommerce_shipping_zone_locations, wp_woocommerce_shipping_zone_methods, wp_woocommerce_shipping_zones, wp_woocommerce_tax_rate_locations, wp_woocommerce_tax_rates
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, post, product, wp_global_styles
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_actionscheduler_actions`
#

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;


#
# Table structure of table `wp_actionscheduler_actions`
#

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_actions`
#
INSERT INTO `wp_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(100, 'woocommerce_cleanup_draft_orders', 'complete', '2022-09-05 23:47:18', '2022-09-05 23:47:18', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1662421638;s:18:"\0*\0first_timestamp";i:1657826716;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1662421638;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1662421638;s:15:"first_timestamp";i:1657826716;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1662421638;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2022-09-20 12:39:39', '2022-09-20 12:39:39', 0, NULL),
(101, 'woocommerce_cleanup_draft_orders', 'complete', '2022-09-21 12:39:39', '2022-09-21 12:39:39', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1663763979;s:18:"\0*\0first_timestamp";i:1657826716;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1663763979;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1663763979;s:15:"first_timestamp";i:1657826716;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1663763979;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2022-09-27 14:29:35', '2022-09-27 14:29:35', 0, NULL),
(102, 'woocommerce_cleanup_draft_orders', 'complete', '2022-09-28 14:29:35', '2022-09-28 14:29:35', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1664375375;s:18:"\0*\0first_timestamp";i:1657826716;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1664375375;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1664375375;s:15:"first_timestamp";i:1657826716;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1664375375;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2022-10-01 17:04:02', '2022-10-01 17:04:02', 0, NULL),
(103, 'wc-admin_import_customers', 'complete', '2022-09-27 15:05:03', '2022-09-27 15:05:03', '[1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1664291103;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1664291103;s:19:"scheduled_timestamp";i:1664291103;s:9:"timestamp";i:1664291103;}', 2, 1, '2022-09-27 15:05:32', '2022-09-27 15:05:32', 0, NULL),
(104, 'wc-admin_import_customers', 'complete', '2022-09-28 03:12:02', '2022-09-28 03:12:02', '[1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1664334722;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1664334722;s:19:"scheduled_timestamp";i:1664334722;s:9:"timestamp";i:1664334722;}', 2, 1, '2022-09-28 03:13:01', '2022-09-28 03:13:01', 0, NULL),
(105, 'woocommerce_cleanup_draft_orders', 'complete', '2022-10-02 17:04:02', '2022-10-02 17:04:02', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1664730242;s:18:"\0*\0first_timestamp";i:1657826716;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1664730242;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1664730242;s:15:"first_timestamp";i:1657826716;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1664730242;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2022-10-11 16:04:14', '2022-10-11 16:04:14', 0, NULL),
(106, 'woocommerce_cleanup_draft_orders', 'pending', '2022-10-12 16:04:14', '2022-10-12 16:04:14', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1665590654;s:18:"\0*\0first_timestamp";i:1657826716;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1665590654;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1665590654;s:15:"first_timestamp";i:1657826716;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1665590654;s:19:"interval_in_seconds";i:86400;}', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(107, 'wc-admin_import_customers', 'complete', '2022-10-12 03:23:07', '2022-10-12 03:23:07', '[1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1665544987;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1665544987;s:19:"scheduled_timestamp";i:1665544987;s:9:"timestamp";i:1665544987;}', 2, 1, '2022-10-12 03:24:17', '2022-10-12 03:24:17', 0, NULL) ;

#
# End of data contents of table `wp_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_claims`
#

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;


#
# Table structure of table `wp_actionscheduler_claims`
#

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_claims`
#

#
# End of data contents of table `wp_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_groups`
#

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;


#
# Table structure of table `wp_actionscheduler_groups`
#

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_groups`
#
INSERT INTO `wp_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'wc-admin-data'),
(3, 'woocommerce-db-updates'),
(4, 'woocommerce-remote-inbox-engine') ;

#
# End of data contents of table `wp_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_logs`
#

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;


#
# Table structure of table `wp_actionscheduler_logs`
#

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_logs`
#
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(208, 100, 'action created', '2022-09-04 23:47:18', '2022-09-04 23:47:18'),
(209, 100, 'action started via WP Cron', '2022-09-20 12:39:39', '2022-09-20 12:39:39'),
(210, 100, 'action complete via WP Cron', '2022-09-20 12:39:39', '2022-09-20 12:39:39'),
(211, 101, 'action created', '2022-09-20 12:39:39', '2022-09-20 12:39:39'),
(212, 101, 'action started via WP Cron', '2022-09-27 14:29:35', '2022-09-27 14:29:35'),
(213, 101, 'action complete via WP Cron', '2022-09-27 14:29:35', '2022-09-27 14:29:35'),
(214, 102, 'action created', '2022-09-27 14:29:35', '2022-09-27 14:29:35'),
(215, 103, 'action created', '2022-09-27 15:04:58', '2022-09-27 15:04:58'),
(216, 103, 'action started via Async Request', '2022-09-27 15:05:31', '2022-09-27 15:05:31'),
(217, 103, 'action complete via Async Request', '2022-09-27 15:05:32', '2022-09-27 15:05:32'),
(218, 104, 'action created', '2022-09-28 03:11:57', '2022-09-28 03:11:57'),
(219, 104, 'action started via WP Cron', '2022-09-28 03:13:01', '2022-09-28 03:13:01'),
(220, 104, 'action complete via WP Cron', '2022-09-28 03:13:01', '2022-09-28 03:13:01'),
(221, 102, 'action started via WP Cron', '2022-10-01 17:04:02', '2022-10-01 17:04:02'),
(222, 102, 'action complete via WP Cron', '2022-10-01 17:04:02', '2022-10-01 17:04:02'),
(223, 105, 'action created', '2022-10-01 17:04:02', '2022-10-01 17:04:02'),
(224, 105, 'action started via WP Cron', '2022-10-11 16:04:14', '2022-10-11 16:04:14'),
(225, 105, 'action complete via WP Cron', '2022-10-11 16:04:14', '2022-10-11 16:04:14'),
(226, 106, 'action created', '2022-10-11 16:04:14', '2022-10-11 16:04:14'),
(227, 107, 'action created', '2022-10-12 03:23:02', '2022-10-12 03:23:02'),
(228, 107, 'action started via WP Cron', '2022-10-12 03:24:17', '2022-10-12 03:24:17'),
(229, 107, 'action complete via WP Cron', '2022-10-12 03:24:17', '2022-10-12 03:24:17') ;

#
# End of data contents of table `wp_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#
INSERT INTO `wp_commentmeta` ( `meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(1, 2, 'rating', '5'),
(2, 2, 'verified', '0') ;

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2022-05-18 16:16:31', '2022-05-18 16:16:31', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', 'comment', 0, 0),
(2, 62, 'Lawrence', 'lthomas@southleft.com', 'http://localhost:8888/jtrc', '127.0.0.1', '2022-08-27 23:50:25', '2022-08-27 23:50:25', 'The Brunch Package is amazing!!', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:103.0) Gecko/20100101 Firefox/103.0', 'review', 0, 1) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_draft_submissions`
#

DROP TABLE IF EXISTS `wp_gf_draft_submissions`;


#
# Table structure of table `wp_gf_draft_submissions`
#

CREATE TABLE `wp_gf_draft_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_draft_submissions`
#

#
# End of data contents of table `wp_gf_draft_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry`
#

DROP TABLE IF EXISTS `wp_gf_entry`;


#
# Table structure of table `wp_gf_entry`
#

CREATE TABLE `wp_gf_entry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(10) unsigned NOT NULL,
  `post_id` bigint(10) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_starred` tinyint(10) NOT NULL DEFAULT '0',
  `is_read` tinyint(10) NOT NULL DEFAULT '0',
  `ip` varchar(45) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(10) DEFAULT NULL,
  `created_by` bigint(10) unsigned DEFAULT NULL,
  `transaction_type` tinyint(10) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `form_id_status` (`form_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry`
#

#
# End of data contents of table `wp_gf_entry`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry_meta`
#

DROP TABLE IF EXISTS `wp_gf_entry_meta`;


#
# Table structure of table `wp_gf_entry_meta`
#

CREATE TABLE `wp_gf_entry_meta` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(10) unsigned NOT NULL DEFAULT '0',
  `entry_id` bigint(10) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  `item_index` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `entry_id` (`entry_id`),
  KEY `meta_value` (`meta_value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry_meta`
#

#
# End of data contents of table `wp_gf_entry_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry_notes`
#

DROP TABLE IF EXISTS `wp_gf_entry_notes`;


#
# Table structure of table `wp_gf_entry_notes`
#

CREATE TABLE `wp_gf_entry_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(10) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sub_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entry_id` (`entry_id`),
  KEY `entry_user_key` (`entry_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry_notes`
#

#
# End of data contents of table `wp_gf_entry_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form`
#

DROP TABLE IF EXISTS `wp_gf_form`;


#
# Table structure of table `wp_gf_form`
#

CREATE TABLE `wp_gf_form` (
  `id` mediumint(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_active` tinyint(10) NOT NULL DEFAULT '1',
  `is_trash` tinyint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form`
#

#
# End of data contents of table `wp_gf_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form_meta`
#

DROP TABLE IF EXISTS `wp_gf_form_meta`;


#
# Table structure of table `wp_gf_form_meta`
#

CREATE TABLE `wp_gf_form_meta` (
  `form_id` mediumint(10) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form_meta`
#

#
# End of data contents of table `wp_gf_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form_revisions`
#

DROP TABLE IF EXISTS `wp_gf_form_revisions`;


#
# Table structure of table `wp_gf_form_revisions`
#

CREATE TABLE `wp_gf_form_revisions` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(10) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form_revisions`
#

#
# End of data contents of table `wp_gf_form_revisions`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form_view`
#

DROP TABLE IF EXISTS `wp_gf_form_view`;


#
# Table structure of table `wp_gf_form_view`
#

CREATE TABLE `wp_gf_form_view` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form_view`
#

#
# End of data contents of table `wp_gf_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_rest_api_keys`
#

DROP TABLE IF EXISTS `wp_gf_rest_api_keys`;


#
# Table structure of table `wp_gf_rest_api_keys`
#

CREATE TABLE `wp_gf_rest_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_rest_api_keys`
#

#
# End of data contents of table `wp_gf_rest_api_keys`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=3556 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8888/jtrc', 'yes'),
(2, 'home', 'http://localhost:8888/jtrc', 'yes'),
(3, 'blogname', 'JT&#039;s Rustic Cuisine', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'lthomas@southleft.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:162:{s:24:"^wc-auth/v([1]{1})/(.*)?";s:63:"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]";s:22:"^wc-api/v([1-3]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-3]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:7:"shop/?$";s:27:"index.php?post_type=product";s:37:"shop/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:32:"shop/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:24:"shop/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:55:"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:50:"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:31:"product-category/(.+?)/embed/?$";s:44:"index.php?product_cat=$matches[1]&embed=true";s:43:"product-category/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:25:"product-category/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:52:"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:47:"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:28:"product-tag/([^/]+)/embed/?$";s:44:"index.php?product_tag=$matches[1]&embed=true";s:40:"product-tag/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:22:"product-tag/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"product/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"product/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:33:"product/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?product=$matches[1]&wc-api=$matches[3]";s:39:"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:32:"product/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"product/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=7&cpage=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:62:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/wc-api(/(.*))?/?$";s:99:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&wc-api=$matches[6]";s:62:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:73:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:25:"(.?.+?)/orders(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&orders=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:28:"(.?.+?)/downloads(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&downloads=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:34:"(.?.+?)/payment-methods(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&payment-methods=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:40:"(.?.+?)/delete-payment-method(/(.*))?/?$";s:64:"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]";s:45:"(.?.+?)/set-default-payment-method(/(.*))?/?$";s:69:"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:34:"advanced-custom-fields-pro/acf.php";i:2;s:43:"doordash-storefront/doordash-storefront.php";i:3;s:25:"loginpress/loginpress.php";i:4;s:27:"svg-support/svg-support.php";i:5;s:45:"upload-max-file-size/upload-max-file-size.php";i:6;s:27:"woocommerce/woocommerce.php";i:7;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'jtrc', 'yes'),
(41, 'stylesheet', 'jtrc', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:1:{s:25:"loginpress/loginpress.php";a:2:{i:0;s:10:"LoginPress";i:1;s:21:"plugin_uninstallation";}}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '7', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1668442591', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '51917', 'yes'),
(100, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:114:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:1:{s:4:"read";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop manager";s:12:"capabilities";a:92:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"edit_theme_options";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(104, 'cron', 'a:18:{i:1665545742;a:1:{s:26:"action_scheduler_run_queue";a:1:{s:32:"0d04ed39571b55704c122d726248bbac";a:3:{s:8:"schedule";s:12:"every_minute";s:4:"args";a:1:{i:0;s:7:"WP Cron";}s:8:"interval";i:60;}}}i:1665546704;a:1:{s:33:"wc_admin_process_orders_milestone";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1665546712;a:1:{s:29:"wc_admin_unsnooze_admin_notes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1665548192;a:5:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1665548470;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1665550221;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1665581042;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1665591392;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1665591431;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1665591432;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1665591795;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1665602652;a:2:{s:33:"woocommerce_cleanup_personal_data";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:30:"woocommerce_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1665602702;a:1:{s:25:"woocommerce_geoip_updater";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:11:"fifteendays";s:4:"args";a:0:{}s:8:"interval";i:1296000;}}}i:1665604301;a:1:{s:14:"wc_admin_daily";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1665613442;a:2:{s:24:"woocommerce_cleanup_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:31:"woocommerce_cleanup_rate_limits";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1665619200;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1665677792;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(105, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'recovery_keys', 'a:1:{s:22:"lanVvR7kS3hTNW18DlGUHW";a:2:{s:10:"hashed_key";s:34:"$P$BL4hSiib0mwS881OnX4L2I16K16ZSd.";s:10:"created_at";i:1665545207;}}', 'yes'),
(119, 'https_detection_errors', 'a:1:{s:20:"https_request_failed";a:1:{i:0;s:21:"HTTPS request failed.";}}', 'yes'),
(128, 'theme_mods_twentytwentytwo', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1652890640;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(152, 'current_theme', 'JT\\\'s Rustic Cuisine', 'yes'),
(153, 'theme_mods_jtrc', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:6:"menu-1";i:3;s:6:"menu-2";i:22;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(154, 'theme_switched', '', 'yes'),
(159, 'recently_activated', 'a:0:{}', 'yes'),
(164, 'finished_updating_comment_type', '1', 'yes'),
(169, 'acf_version', '5.12.3', 'yes'),
(174, 'gf_db_version', '2.6.7', 'no'),
(175, 'rg_form_version', '2.6.7', 'no'),
(176, 'gform_enable_background_updates', '1', 'yes'),
(177, 'gform_pending_installation', '', 'yes'),
(178, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(179, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(181, 'gform_version_info', 'a:11:{s:12:"is_valid_key";b:1;s:6:"reason";s:0:"";s:7:"version";s:5:"2.6.7";s:3:"url";s:169:"https://s3.amazonaws.com/gravityforms/releases/gravityforms_2.6.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=qKiDSvcllgrL7hYfx1OukF%2Fi%2FRU%3D";s:15:"expiration_time";i:1689452074;s:9:"offerings";a:61:{s:12:"gravityforms";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"2.6.7";s:14:"version_latest";s:5:"2.6.7";s:3:"url";s:169:"https://s3.amazonaws.com/gravityforms/releases/gravityforms_2.6.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=qKiDSvcllgrL7hYfx1OukF%2Fi%2FRU%3D";s:10:"url_latest";s:169:"https://s3.amazonaws.com/gravityforms/releases/gravityforms_2.6.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=qKiDSvcllgrL7hYfx1OukF%2Fi%2FRU%3D";}s:21:"gravityforms2checkout";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.1";s:14:"version_latest";s:3:"2.1";s:3:"url";s:180:"https://s3.amazonaws.com/gravityforms/addons/2checkout/gravityforms2checkout_2.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=40uG8xet7l1whipWOMhzGhqYBPM%3D";s:10:"url_latest";s:180:"https://s3.amazonaws.com/gravityforms/addons/2checkout/gravityforms2checkout_2.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=40uG8xet7l1whipWOMhzGhqYBPM%3D";}s:26:"gravityformsactivecampaign";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.0";s:14:"version_latest";s:3:"2.0";s:3:"url";s:190:"https://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_2.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=Cw5d7uTrD6lTpIap2g30PcAgmMs%3D";s:10:"url_latest";s:190:"https://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_2.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=Cw5d7uTrD6lTpIap2g30PcAgmMs%3D";}s:32:"gravityformsadvancedpostcreation";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:204:"https://s3.amazonaws.com/gravityforms/addons/advancedpostcreation/gravityformsadvancedpostcreation_1.2.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=b9JGckqHFi27js3IwTNTCRwIe%2Fk%3D";s:10:"url_latest";s:204:"https://s3.amazonaws.com/gravityforms/addons/advancedpostcreation/gravityformsadvancedpostcreation_1.2.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=b9JGckqHFi27js3IwTNTCRwIe%2Fk%3D";}s:20:"gravityformsagilecrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.4";s:14:"version_latest";s:3:"1.4";s:3:"url";s:180:"https://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=OlnyI%2B7fx1I3ANFs1v2cBiqXwxM%3D";s:10:"url_latest";s:180:"https://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=OlnyI%2B7fx1I3ANFs1v2cBiqXwxM%3D";}s:19:"gravityformsakismet";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.0";s:14:"version_latest";s:3:"1.0";s:3:"url";s:178:"https://s3.amazonaws.com/gravityforms/addons/akismet/gravityformsakismet_1.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=p0%2FA0Ne2IGp0VCMvYJ16OI45sj0%3D";s:10:"url_latest";s:178:"https://s3.amazonaws.com/gravityforms/addons/akismet/gravityformsakismet_1.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=p0%2FA0Ne2IGp0VCMvYJ16OI45sj0%3D";}s:24:"gravityformsauthorizenet";a:5:{s:12:"is_available";b:1;s:7:"version";s:4:"2.11";s:14:"version_latest";s:4:"2.11";s:3:"url";s:191:"https://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.11.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=QZJEE%2Fv6%2B1n2rEmQW2jHwxsWvP0%3D";s:10:"url_latest";s:191:"https://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.11.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=QZJEE%2Fv6%2B1n2rEmQW2jHwxsWvP0%3D";}s:18:"gravityformsaweber";a:5:{s:12:"is_available";b:1;s:7:"version";s:4:"2.11";s:14:"version_latest";s:4:"2.11";s:3:"url";s:177:"https://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.11.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=yNvMJkjGDwSSJpHgnDF%2BIdbyxNU%3D";s:10:"url_latest";s:177:"https://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.11.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=yNvMJkjGDwSSJpHgnDF%2BIdbyxNU%3D";}s:21:"gravityformsbatchbook";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:180:"https://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=LisVT49MkPi1jrU2iWcup7LClGI%3D";s:10:"url_latest";s:180:"https://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=LisVT49MkPi1jrU2iWcup7LClGI%3D";}s:18:"gravityformsbreeze";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:3:"1.5";s:3:"url";s:176:"https://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=EVttLBF4Hy%2Fe31zmuJczHHsH6fY%3D";s:10:"url_latest";s:176:"https://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=EVttLBF4Hy%2Fe31zmuJczHHsH6fY%3D";}s:27:"gravityformscampaignmonitor";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.9";s:14:"version_latest";s:3:"3.9";s:3:"url";s:192:"https://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.9.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=Uy4oO3iQHoKuvdl8ukOsvQ8lQes%3D";s:10:"url_latest";s:192:"https://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.9.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=Uy4oO3iQHoKuvdl8ukOsvQ8lQes%3D";}s:20:"gravityformscampfire";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:5:"1.2.2";s:3:"url";s:182:"https://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=wK1%2FzJewmcwNZar%2FH3hMzC4JhG0%3D";s:10:"url_latest";s:182:"https://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.2.2.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=l9P7kiHg4bkRncb8ZyMjNixJ%2FqU%3D";}s:22:"gravityformscapsulecrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.6";s:14:"version_latest";s:3:"1.6";s:3:"url";s:184:"https://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.6.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=9%2Fl6JGIohBG6C9mum2PI9nSpSLk%3D";s:10:"url_latest";s:184:"https://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.6.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=9%2Fl6JGIohBG6C9mum2PI9nSpSLk%3D";}s:26:"gravityformschainedselects";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:5:"1.5.1";s:3:"url";s:190:"https://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=rAPC9XX0BYoaiD2q7WkBuL4se44%3D";s:10:"url_latest";s:192:"https://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.5.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=RLK5trMTTTa9ww8eDdeFNSnMCqY%3D";}s:23:"gravityformscleverreach";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.7";s:14:"version_latest";s:3:"1.7";s:3:"url";s:188:"https://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=7%2FzvURgS6kVWtz%2B8EMTtZDs7cmg%3D";s:10:"url_latest";s:188:"https://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=7%2FzvURgS6kVWtz%2B8EMTtZDs7cmg%3D";}s:15:"gravityformscli";a:5:{s:12:"is_available";b:1;s:7:"version";s:0:"";s:14:"version_latest";s:3:"1.4";s:3:"url";s:0:"";s:10:"url_latest";s:172:"https://s3.amazonaws.com/gravityforms/addons/cli/gravityformscli_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=Vm%2FTYF606veb%2FD24AaI891t70QY%3D";}s:27:"gravityformsconstantcontact";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.6";s:14:"version_latest";s:5:"1.6.1";s:3:"url";s:194:"https://s3.amazonaws.com/gravityforms/addons/constantcontact/gravityformsconstantcontact_1.6.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=0E4GuozuO8%2FbfPdiYlTgMno6soI%3D";s:10:"url_latest";s:196:"https://s3.amazonaws.com/gravityforms/addons/constantcontact/gravityformsconstantcontact_1.6.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=ME26Pkjb8tyGAEsd%2FDOEGkf4Hbs%3D";}s:19:"gravityformscoupons";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.0";s:14:"version_latest";s:3:"3.0";s:3:"url";s:178:"https://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_3.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=0%2FFIBXYZZiAns4tnSs8YV61dfDI%3D";s:10:"url_latest";s:178:"https://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_3.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=0%2FFIBXYZZiAns4tnSs8YV61dfDI%3D";}s:17:"gravityformsdebug";a:5:{s:12:"is_available";b:1;s:7:"version";s:0:"";s:14:"version_latest";s:10:"1.0.beta12";s:3:"url";s:0:"";s:10:"url_latest";s:181:"https://s3.amazonaws.com/gravityforms/addons/debug/gravityformsdebug_1.0.beta12.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=1O%2FeFyN6akSDfapjjSy5Y6hwwP0%3D";}s:19:"gravityformsdropbox";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:3:"3.1";s:3:"url";s:178:"https://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_3.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=HMka5xGoeeQD3Rb1epK%2F82c10cc%3D";s:10:"url_latest";s:178:"https://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_3.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=HMka5xGoeeQD3Rb1epK%2F82c10cc%3D";}s:24:"gravityformsemailoctopus";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.1";s:3:"url";s:186:"https://s3.amazonaws.com/gravityforms/addons/emailoctopus/gravityformsemailoctopus_1.2.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=D2JECZ5rMOTT8NJF2FMBmp3yyYQ%3D";s:10:"url_latest";s:188:"https://s3.amazonaws.com/gravityforms/addons/emailoctopus/gravityformsemailoctopus_1.2.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=vJdMvS3cURTZt5mzO5iDun8m7Fc%3D";}s:16:"gravityformsemma";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:5:"1.5.1";s:3:"url";s:170:"https://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=4Bt8XWxzvK2GNrs9f26Y2gxrEsY%3D";s:10:"url_latest";s:174:"https://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.5.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=0Eowv97o6eaj%2B4OCDmeNQjp8tmk%3D";}s:22:"gravityformsfreshbooks";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.8";s:14:"version_latest";s:3:"2.8";s:3:"url";s:184:"https://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.8.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=K3mietGvGr5hi7R%2FdCaq9k7xeOo%3D";s:10:"url_latest";s:184:"https://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.8.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=K3mietGvGr5hi7R%2FdCaq9k7xeOo%3D";}s:23:"gravityformsgetresponse";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.7";s:14:"version_latest";s:3:"1.7";s:3:"url";s:186:"https://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=I9YRBMi41O6wejzJWdS%2F7Hho8jM%3D";s:10:"url_latest";s:186:"https://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=I9YRBMi41O6wejzJWdS%2F7Hho8jM%3D";}s:27:"gravityformsgoogleanalytics";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.0";s:14:"version_latest";s:5:"1.0.1";s:3:"url";s:196:"https://s3.amazonaws.com/gravityforms/addons/googleanalytics/gravityformsgoogleanalytics_1.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=PlafnwMacdV2iQ3bX8til%2Bs6%2BZA%3D";s:10:"url_latest";s:194:"https://s3.amazonaws.com/gravityforms/addons/googleanalytics/gravityformsgoogleanalytics_1.0.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=FLxFa6VVe4CZ2DMNhClttQwe74A%3D";}s:21:"gravityformsgutenberg";a:5:{s:12:"is_available";b:1;s:7:"version";s:10:"1.0-rc-1.4";s:14:"version_latest";s:10:"1.0-rc-1.5";s:3:"url";s:193:"https://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-rc-1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=QvK7RnR0ygkNiZ9BCg%2B%2Bk%2B6sRzQ%3D";s:10:"url_latest";s:191:"https://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-rc-1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=4O%2B5FzqdnNDQP2GpoeTF%2BV8CHGI%3D";}s:21:"gravityformshelpscout";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.1";s:14:"version_latest";s:3:"2.1";s:3:"url";s:180:"https://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_2.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=LsW0wZDj15iXAU4r0GZNYtRyP8c%3D";s:10:"url_latest";s:180:"https://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_2.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=LsW0wZDj15iXAU4r0GZNYtRyP8c%3D";}s:20:"gravityformshighrise";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:180:"https://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=teLleGWTqpNG5T0J%2F8z04K7pYX0%3D";s:10:"url_latest";s:180:"https://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=teLleGWTqpNG5T0J%2F8z04K7pYX0%3D";}s:19:"gravityformshipchat";a:3:{s:12:"is_available";b:0;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";}s:19:"gravityformshubspot";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.7";s:14:"version_latest";s:3:"1.7";s:3:"url";s:176:"https://s3.amazonaws.com/gravityforms/addons/hubspot/gravityformshubspot_1.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=lpJfEDPXpCVZ5QUryK9KbtZu3vs%3D";s:10:"url_latest";s:176:"https://s3.amazonaws.com/gravityforms/addons/hubspot/gravityformshubspot_1.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=lpJfEDPXpCVZ5QUryK9KbtZu3vs%3D";}s:20:"gravityformsicontact";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:3:"1.5";s:3:"url";s:180:"https://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=vzz7UIFZyEQDBRcno4VSC4D%2BL5I%3D";s:10:"url_latest";s:180:"https://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=vzz7UIFZyEQDBRcno4VSC4D%2BL5I%3D";}s:19:"gravityformslogging";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:5:"1.3.1";s:3:"url";s:176:"https://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=kRhJ4slVXNXbZC4ChH5ACkyuGrE%3D";s:10:"url_latest";s:182:"https://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=JcsXt46%2B4Wbypj3%2FYAVSL2DFO0s%3D";}s:19:"gravityformsmadmimi";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.4";s:14:"version_latest";s:3:"1.4";s:3:"url";s:180:"https://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=2nRhr8U%2Bz6vIRQa%2FwBiVZTUyik8%3D";s:10:"url_latest";s:180:"https://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=2nRhr8U%2Bz6vIRQa%2FwBiVZTUyik8%3D";}s:21:"gravityformsmailchimp";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"5.1";s:14:"version_latest";s:3:"5.1";s:3:"url";s:180:"https://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_5.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=PUThoo6C7LV4CcivF9rEkt8xQtg%3D";s:10:"url_latest";s:180:"https://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_5.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=PUThoo6C7LV4CcivF9rEkt8xQtg%3D";}s:19:"gravityformsmailgun";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:5:"1.3.1";s:3:"url";s:176:"https://s3.amazonaws.com/gravityforms/addons/mailgun/gravityformsmailgun_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=LznLDQPTKR1QMSwdlq63sNDLZFI%3D";s:10:"url_latest";s:178:"https://s3.amazonaws.com/gravityforms/addons/mailgun/gravityformsmailgun_1.3.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=Hi0cvwMziX85tw91B67TbLzFtNQ%3D";}s:18:"gravityformsmollie";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.1";s:3:"url";s:176:"https://s3.amazonaws.com/gravityforms/addons/mollie/gravityformsmollie_1.2.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=CePx%2FM9z4LG8qZy5HoC6BNYn8Fk%3D";s:10:"url_latest";s:176:"https://s3.amazonaws.com/gravityforms/addons/mollie/gravityformsmollie_1.2.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=qoRSQO79EVW52pe94nnGW9LFrVs%3D";}s:26:"gravityformspartialentries";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.7";s:14:"version_latest";s:3:"1.7";s:3:"url";s:194:"https://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=6nWcmEbd2EbSN%2BwRFEq3%2BZ5YoJA%3D";s:10:"url_latest";s:194:"https://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=6nWcmEbd2EbSN%2BwRFEq3%2BZ5YoJA%3D";}s:18:"gravityformspaypal";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.5";s:14:"version_latest";s:3:"3.5";s:3:"url";s:178:"https://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=EQCj%2FPMoPU6DMzk7CLt2KzWW%2BrI%3D";s:10:"url_latest";s:178:"https://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=EQCj%2FPMoPU6DMzk7CLt2KzWW%2BrI%3D";}s:33:"gravityformspaypalexpresscheckout";a:3:{s:12:"is_available";b:0;s:7:"version";s:0:"";s:14:"version_latest";N;}s:29:"gravityformspaypalpaymentspro";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.7";s:14:"version_latest";s:3:"2.7";s:3:"url";s:198:"https://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=9mjeYNpPH7j226e0Qu%2FSTXu70iE%3D";s:10:"url_latest";s:198:"https://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=9mjeYNpPH7j226e0Qu%2FSTXu70iE%3D";}s:21:"gravityformspaypalpro";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"1.8.1";s:14:"version_latest";s:5:"1.8.4";s:3:"url";s:182:"https://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=9MLgqU5emKsO9sAc2Pk0rA6QfXI%3D";s:10:"url_latest";s:184:"https://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.4.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=dRRB5V%2B5skqmWcO7z1z7zb86FyQ%3D";}s:20:"gravityformspicatcha";a:3:{s:12:"is_available";b:0;s:7:"version";s:3:"2.0";s:14:"version_latest";s:3:"2.0";}s:16:"gravityformspipe";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.3";s:3:"url";s:172:"https://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.2.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=VuAiWnU65gL6fXZSz%2BKNZDkIq34%3D";s:10:"url_latest";s:174:"https://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=oZe6OEc4%2FPTHGcudIJvRGK3v%2BSQ%3D";}s:17:"gravityformspolls";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.9";s:14:"version_latest";s:3:"3.9";s:3:"url";s:172:"https://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.9.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=JeXkzXfWHlLApZ14cBGNOlJn5hE%3D";s:10:"url_latest";s:172:"https://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.9.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=JeXkzXfWHlLApZ14cBGNOlJn5hE%3D";}s:20:"gravityformspostmark";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:182:"https://s3.amazonaws.com/gravityforms/addons/postmark/gravityformspostmark_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=LPQHiY0%2Fs7bh5ISeT%2BJKifGO8AY%3D";s:10:"url_latest";s:182:"https://s3.amazonaws.com/gravityforms/addons/postmark/gravityformspostmark_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=LPQHiY0%2Fs7bh5ISeT%2BJKifGO8AY%3D";}s:16:"gravityformsppcp";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.4";s:14:"version_latest";s:5:"2.4.1";s:3:"url";s:172:"https://s3.amazonaws.com/gravityforms/addons/ppcp/gravityformsppcp_2.4.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=Qkz6tWXEz3Q%2FOzpZByiw4CaotGg%3D";s:10:"url_latest";s:172:"https://s3.amazonaws.com/gravityforms/addons/ppcp/gravityformsppcp_2.4.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=opPLFy8jXUInxlHH1PvNN9nK5B8%3D";}s:16:"gravityformsquiz";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.9";s:14:"version_latest";s:3:"3.9";s:3:"url";s:172:"https://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.9.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=Lpd4BS5I90FWFt9lw%2F4dm56Rfc0%3D";s:10:"url_latest";s:172:"https://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.9.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=Lpd4BS5I90FWFt9lw%2F4dm56Rfc0%3D";}s:21:"gravityformsrecaptcha";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:3:"1.1";s:3:"url";s:182:"https://s3.amazonaws.com/gravityforms/addons/recaptcha/gravityformsrecaptcha_1.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=wtEv5DpOkIN4S50bdFp%2BnvzzEpc%3D";s:10:"url_latest";s:182:"https://s3.amazonaws.com/gravityforms/addons/recaptcha/gravityformsrecaptcha_1.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=wtEv5DpOkIN4S50bdFp%2BnvzzEpc%3D";}s:19:"gravityformsrestapi";a:5:{s:12:"is_available";b:1;s:7:"version";s:10:"2.0-beta-2";s:14:"version_latest";s:10:"2.0-beta-2";s:3:"url";s:185:"https://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=pnlcy217ePeqXTiHNK6wq6gH%2BR8%3D";s:10:"url_latest";s:185:"https://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=pnlcy217ePeqXTiHNK6wq6gH%2BR8%3D";}s:20:"gravityformssendgrid";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:3:"1.5";s:3:"url";s:178:"https://s3.amazonaws.com/gravityforms/addons/sendgrid/gravityformssendgrid_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=KGhpfzvP9anI88jWvDuTy5ztYKM%3D";s:10:"url_latest";s:178:"https://s3.amazonaws.com/gravityforms/addons/sendgrid/gravityformssendgrid_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=KGhpfzvP9anI88jWvDuTy5ztYKM%3D";}s:21:"gravityformssignature";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"4.3";s:14:"version_latest";s:3:"4.3";s:3:"url";s:180:"https://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_4.3.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=XrpBk6eeZLNJe1BPJyR5MW683Io%3D";s:10:"url_latest";s:180:"https://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_4.3.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=XrpBk6eeZLNJe1BPJyR5MW683Io%3D";}s:17:"gravityformsslack";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.0";s:14:"version_latest";s:3:"2.0";s:3:"url";s:172:"https://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_2.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=YJKLeaOtUvbkkmGu1kANUqty1qE%3D";s:10:"url_latest";s:172:"https://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_2.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=YJKLeaOtUvbkkmGu1kANUqty1qE%3D";}s:18:"gravityformssquare";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.7";s:14:"version_latest";s:3:"1.7";s:3:"url";s:176:"https://s3.amazonaws.com/gravityforms/addons/square/gravityformssquare_1.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=0F3AqsumolkuFgX2OOluWqEiC%2B0%3D";s:10:"url_latest";s:176:"https://s3.amazonaws.com/gravityforms/addons/square/gravityformssquare_1.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=0F3AqsumolkuFgX2OOluWqEiC%2B0%3D";}s:18:"gravityformsstripe";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"4.2";s:14:"version_latest";s:5:"4.2.1";s:3:"url";s:174:"https://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_4.2.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=3sE9MGDc8D8LMYSCiXGdsLy4IH4%3D";s:10:"url_latest";s:176:"https://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_4.2.1.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=vqOsiEds8JwNhusMxlqr433v7OA%3D";}s:18:"gravityformssurvey";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.7";s:14:"version_latest";s:3:"3.7";s:3:"url";s:174:"https://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=kL1AOj2N9i8vM6BVSGzfKfJnFxg%3D";s:10:"url_latest";s:174:"https://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=kL1AOj2N9i8vM6BVSGzfKfJnFxg%3D";}s:18:"gravityformstrello";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.0";s:14:"version_latest";s:3:"2.0";s:3:"url";s:180:"https://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_2.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=dJPI%2BPMDd%2FiklCGaSCX1ic%2BqZjY%3D";s:10:"url_latest";s:180:"https://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_2.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=dJPI%2BPMDd%2FiklCGaSCX1ic%2BqZjY%3D";}s:18:"gravityformstwilio";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.9";s:14:"version_latest";s:3:"2.9";s:3:"url";s:174:"https://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.9.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=VdG6hkeQDVYPm7WQX5EwskcOFro%3D";s:10:"url_latest";s:174:"https://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.9.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=VdG6hkeQDVYPm7WQX5EwskcOFro%3D";}s:28:"gravityformsuserregistration";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"5.0";s:14:"version_latest";s:3:"5.0";s:3:"url";s:196:"https://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_5.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=4jNOMJmuO9b6riadSKt%2FreIHkXw%3D";s:10:"url_latest";s:196:"https://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_5.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=4jNOMJmuO9b6riadSKt%2FreIHkXw%3D";}s:20:"gravityformswebhooks";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:3:"1.5";s:3:"url";s:178:"https://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=GUZRhG4twOFofSXr47ALnCuCdxc%3D";s:10:"url_latest";s:178:"https://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=GUZRhG4twOFofSXr47ALnCuCdxc%3D";}s:18:"gravityformszapier";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"4.2";s:14:"version_latest";s:3:"4.2";s:3:"url";s:174:"https://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_4.2.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=9sIHwmZEp7KuM2rUlSZEiw9Cmd4%3D";s:10:"url_latest";s:174:"https://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_4.2.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=9sIHwmZEp7KuM2rUlSZEiw9Cmd4%3D";}s:19:"gravityformszohocrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.0";s:14:"version_latest";s:3:"2.0";s:3:"url";s:180:"https://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_2.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=ocswGhiUYTxZWtiXF21Bi%2FL%2BXaQ%3D";s:10:"url_latest";s:180:"https://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_2.0.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=ocswGhiUYTxZWtiXF21Bi%2FL%2BXaQ%3D";}}s:9:"is_active";s:1:"1";s:12:"product_code";s:7:"GFELITE";s:14:"version_latest";s:5:"2.6.7";s:10:"url_latest";s:169:"https://s3.amazonaws.com/gravityforms/releases/gravityforms_2.6.7.zip?AWSAccessKeyId=AKIA5U3GBHC5WDRZA6NK&Expires=1665677055&Signature=qKiDSvcllgrL7hYfx1OukF%2Fi%2FRU%3D";s:9:"timestamp";i:1665504255;}', 'no'),
(184, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5T0RreU56VjhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMkxUQTVMVEE0SURFMk9qQTVPalEzIjtzOjM6InVybCI7czoyNjoiaHR0cDovL2xvY2FsaG9zdDo4ODg4L2p0cmMiO30=', 'yes'),
(194, 'rg_gforms_key', '681ecfbb58949c3f317ed3a3eb3adb24', 'yes'),
(195, 'gf_site_key', '514efd9a-f5b4-46ca-92b7-a83de29be779', 'yes'),
(196, 'gf_site_secret', '706e910f-b06d-4ff2-ba7b-b265da3133d3', 'yes'),
(197, 'rg_gforms_enable_akismet', '1', 'yes'),
(198, 'rg_gforms_currency', '', 'yes'),
(199, 'gform_enable_toolbar_menu', '1', 'yes'),
(214, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:21:"lthomas@southleft.com";s:7:"version";s:5:"6.0.2";s:9:"timestamp";i:1662335244;}', 'no'),
(316, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(447, 'action_scheduler_hybrid_store_demarkation', '30', 'yes'),
(448, 'schema-ActionScheduler_StoreSchema', '6.0.1653853899', 'yes'),
(449, 'schema-ActionScheduler_LoggerSchema', '3.0.1653853899', 'yes'),
(452, 'woocommerce_schema_version', '430', 'yes'),
(453, 'woocommerce_store_address', '41 Alstead Road', 'yes'),
(454, 'woocommerce_store_address_2', '', 'yes'),
(455, 'woocommerce_store_city', 'Valley Stream', 'yes'),
(456, 'woocommerce_default_country', 'US:NY', 'yes'),
(457, 'woocommerce_store_postcode', '11580', 'yes'),
(458, 'woocommerce_allowed_countries', 'all', 'yes'),
(459, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(460, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(461, 'woocommerce_ship_to_countries', '', 'yes'),
(462, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(463, 'woocommerce_default_customer_address', 'base', 'yes'),
(464, 'woocommerce_calc_taxes', 'no', 'yes'),
(465, 'woocommerce_enable_coupons', 'yes', 'yes'),
(466, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(467, 'woocommerce_currency', 'USD', 'yes'),
(468, 'woocommerce_currency_pos', 'left', 'yes'),
(469, 'woocommerce_price_thousand_sep', ',', 'yes'),
(470, 'woocommerce_price_decimal_sep', '.', 'yes'),
(471, 'woocommerce_price_num_decimals', '2', 'yes'),
(472, 'woocommerce_shop_page_id', '31', 'yes'),
(473, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(474, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(475, 'woocommerce_placeholder_image', '30', 'yes'),
(476, 'woocommerce_weight_unit', 'kg', 'yes'),
(477, 'woocommerce_dimension_unit', 'cm', 'yes'),
(478, 'woocommerce_enable_reviews', 'yes', 'yes'),
(479, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(480, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(481, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(482, 'woocommerce_review_rating_required', 'yes', 'no'),
(483, 'woocommerce_manage_stock', 'yes', 'yes'),
(484, 'woocommerce_hold_stock_minutes', '60', 'no'),
(485, 'woocommerce_notify_low_stock', 'yes', 'no'),
(486, 'woocommerce_notify_no_stock', 'yes', 'no'),
(487, 'woocommerce_stock_email_recipient', 'lthomas@southleft.com', 'no'),
(488, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(489, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(490, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(491, 'woocommerce_stock_format', '', 'yes'),
(492, 'woocommerce_file_download_method', 'force', 'no'),
(493, 'woocommerce_downloads_redirect_fallback_allowed', 'no', 'no'),
(494, 'woocommerce_downloads_require_login', 'no', 'no'),
(495, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(496, 'woocommerce_downloads_add_hash_to_filename', 'yes', 'yes'),
(498, 'woocommerce_attribute_lookup_direct_updates', 'no', 'yes'),
(499, 'woocommerce_prices_include_tax', 'no', 'yes'),
(500, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(501, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(502, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(503, 'woocommerce_tax_classes', '', 'yes'),
(504, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(505, 'woocommerce_tax_display_cart', 'excl', 'yes'),
(506, 'woocommerce_price_display_suffix', '', 'yes'),
(507, 'woocommerce_tax_total_display', 'itemized', 'no'),
(508, 'woocommerce_enable_shipping_calc', 'yes', 'no') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(509, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(510, 'woocommerce_ship_to_destination', 'billing', 'no'),
(511, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(512, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(513, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'),
(514, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no'),
(515, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(516, 'woocommerce_registration_generate_username', 'yes', 'no'),
(517, 'woocommerce_registration_generate_password', 'yes', 'no'),
(518, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(519, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(520, 'woocommerce_allow_bulk_remove_personal_data', 'no', 'no'),
(521, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'yes'),
(522, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'yes'),
(523, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(524, 'woocommerce_trash_pending_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:4:"days";}', 'no'),
(525, 'woocommerce_trash_failed_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:4:"days";}', 'no'),
(526, 'woocommerce_trash_cancelled_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:4:"days";}', 'no'),
(527, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(528, 'woocommerce_email_from_name', 'JT&#039;s Rustic Cuisine', 'no'),
(529, 'woocommerce_email_from_address', 'lthomas@southleft.com', 'no'),
(530, 'woocommerce_email_header_image', '', 'no'),
(531, 'woocommerce_email_footer_text', '{site_title} &mdash; Built with {WooCommerce}', 'no'),
(532, 'woocommerce_email_base_color', '#7f54b3', 'no'),
(533, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(534, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(535, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(536, 'woocommerce_merchant_email_notifications', 'no', 'no'),
(537, 'woocommerce_cart_page_id', '32', 'no'),
(538, 'woocommerce_checkout_page_id', '33', 'no'),
(539, 'woocommerce_myaccount_page_id', '34', 'no'),
(540, 'woocommerce_terms_page_id', '', 'no'),
(541, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(542, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(543, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(544, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(545, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(546, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(547, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(548, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(549, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(550, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(551, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(552, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(553, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(554, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(555, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(556, 'woocommerce_api_enabled', 'no', 'yes'),
(557, 'woocommerce_allow_tracking', 'yes', 'no'),
(558, 'woocommerce_show_marketplace_suggestions', 'yes', 'no'),
(559, 'woocommerce_single_image_width', '600', 'yes'),
(560, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(561, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(562, 'woocommerce_demo_store', 'no', 'no'),
(563, 'wc_downloads_approved_directories_mode', 'enabled', 'yes'),
(564, 'woocommerce_permalinks', 'a:5:{s:12:"product_base";s:7:"product";s:13:"category_base";s:16:"product-category";s:8:"tag_base";s:11:"product-tag";s:14:"attribute_base";s:0:"";s:22:"use_verbose_page_rules";b:0;}', 'yes'),
(565, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(566, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(569, 'default_product_cat', '17', 'yes'),
(571, 'woocommerce_refund_returns_page_id', '35', 'yes'),
(574, 'woocommerce_paypal_settings', 'a:23:{s:7:"enabled";s:2:"no";s:5:"title";s:6:"PayPal";s:11:"description";s:85:"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.";s:5:"email";s:21:"lthomas@southleft.com";s:8:"advanced";s:0:"";s:8:"testmode";s:2:"no";s:5:"debug";s:2:"no";s:16:"ipn_notification";s:3:"yes";s:14:"receiver_email";s:21:"lthomas@southleft.com";s:14:"identity_token";s:0:"";s:14:"invoice_prefix";s:3:"WC-";s:13:"send_shipping";s:3:"yes";s:16:"address_override";s:2:"no";s:13:"paymentaction";s:4:"sale";s:9:"image_url";s:0:"";s:11:"api_details";s:0:"";s:12:"api_username";s:0:"";s:12:"api_password";s:0:"";s:13:"api_signature";s:0:"";s:20:"sandbox_api_username";s:0:"";s:20:"sandbox_api_password";s:0:"";s:21:"sandbox_api_signature";s:0:"";s:12:"_should_load";s:2:"no";}', 'yes'),
(575, 'woocommerce_version', '6.7.0', 'yes'),
(576, 'woocommerce_db_version', '6.7.0', 'yes'),
(577, 'woocommerce_admin_install_timestamp', '1653853903', 'yes'),
(578, 'woocommerce_inbox_variant_assignment', '6', 'yes'),
(583, 'action_scheduler_lock_async-request-runner', '1665545749', 'yes'),
(584, 'woocommerce_admin_notices', 'a:2:{i:0;s:6:"update";i:1;s:20:"no_secure_connection";}', 'yes'),
(585, 'woocommerce_maxmind_geolocation_settings', 'a:1:{s:15:"database_prefix";s:32:"HbWFmuRN67Q5oAnvXaQ4Sq6nve6iChjo";}', 'yes'),
(587, 'widget_woocommerce_widget_cart', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(588, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(589, 'widget_woocommerce_layered_nav', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(590, 'widget_woocommerce_price_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(591, 'widget_woocommerce_product_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(592, 'widget_woocommerce_product_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(593, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(594, 'widget_woocommerce_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(595, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(596, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(597, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(598, 'widget_woocommerce_rating_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(605, 'wc_remote_inbox_notifications_stored_state', 'O:8:"stdClass":2:{s:22:"there_were_no_products";b:1;s:22:"there_are_now_products";b:1;}', 'no'),
(606, 'wc_blocks_surface_cart_checkout_probability', '24', 'yes'),
(607, 'wc_blocks_db_schema_version', '260', 'yes'),
(629, 'woocommerce_task_list_tracked_completed_tasks', 'a:4:{i:0;s:8:"purchase";i:1;s:14:"store_creation";i:2;s:13:"store_details";i:3;s:8:"products";}', 'yes'),
(630, 'woocommerce_task_list_completed_lists', 'a:2:{i:0;s:8:"extended";i:1;s:19:"extended_two_column";}', 'yes'),
(640, 'woocommerce_onboarding_profile', 'a:10:{s:18:"is_agree_marketing";b:0;s:11:"store_email";s:25:"lawrencegthomas@gmail.com";s:8:"industry";a:1:{i:0;a:1:{s:4:"slug";s:10:"food-drink";}}s:13:"product_types";a:1:{i:0;s:8:"physical";}s:13:"product_count";s:6:"11-100";s:14:"selling_venues";s:2:"no";s:12:"setup_client";b:1;s:19:"business_extensions";a:0:{}s:5:"theme";s:4:"jtrc";s:9:"completed";b:1;}', 'yes'),
(643, 'wc_has_tracked_default_theme', '1', 'yes'),
(645, 'woocommerce_task_list_dismissed_tasks', 'a:0:{}', 'yes'),
(646, 'woocommerce_task_list_prompt_shown', '1', 'yes'),
(1242, 'woocommerce_marketplace_suggestions', 'a:2:{s:11:"suggestions";a:28:{i:0;a:4:{s:4:"slug";s:28:"product-edit-meta-tab-header";s:7:"context";s:28:"product-edit-meta-tab-header";s:5:"title";s:22:"Recommended extensions";s:13:"allow-dismiss";b:0;}i:1;a:6:{s:4:"slug";s:39:"product-edit-meta-tab-footer-browse-all";s:7:"context";s:28:"product-edit-meta-tab-footer";s:9:"link-text";s:21:"Browse all extensions";s:3:"url";s:64:"https://woocommerce.com/product-category/woocommerce-extensions/";s:8:"promoted";s:31:"category-woocommerce-extensions";s:13:"allow-dismiss";b:0;}i:2;a:9:{s:4:"slug";s:46:"product-edit-mailchimp-woocommerce-memberships";s:7:"product";s:33:"woocommerce-memberships-mailchimp";s:14:"show-if-active";a:1:{i:0;s:23:"woocommerce-memberships";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:116:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/mailchimp-for-memberships.svg";s:5:"title";s:25:"Mailchimp for Memberships";s:4:"copy";s:79:"Completely automate your email lists by syncing membership changes to Mailchimp";s:11:"button-text";s:10:"Learn More";s:3:"url";s:67:"https://woocommerce.com/products/mailchimp-woocommerce-memberships/";}i:3;a:9:{s:4:"slug";s:19:"product-edit-addons";s:7:"product";s:26:"woocommerce-product-addons";s:14:"show-if-active";a:2:{i:0;s:25:"woocommerce-subscriptions";i:1;s:20:"woocommerce-bookings";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:106:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-add-ons.svg";s:5:"title";s:15:"Product Add-Ons";s:4:"copy";s:93:"Offer add-ons like gift wrapping, special messages or other special options for your products";s:11:"button-text";s:10:"Learn More";s:3:"url";s:49:"https://woocommerce.com/products/product-add-ons/";}i:4;a:9:{s:4:"slug";s:46:"product-edit-woocommerce-subscriptions-gifting";s:7:"product";s:33:"woocommerce-subscriptions-gifting";s:14:"show-if-active";a:1:{i:0;s:25:"woocommerce-subscriptions";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:116:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/gifting-for-subscriptions.svg";s:5:"title";s:25:"Gifting for Subscriptions";s:4:"copy";s:70:"Let customers buy subscriptions for others - they\'re the ultimate gift";s:11:"button-text";s:10:"Learn More";s:3:"url";s:67:"https://woocommerce.com/products/woocommerce-subscriptions-gifting/";}i:5;a:9:{s:4:"slug";s:42:"product-edit-teams-woocommerce-memberships";s:7:"product";s:33:"woocommerce-memberships-for-teams";s:14:"show-if-active";a:1:{i:0;s:23:"woocommerce-memberships";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:112:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/teams-for-memberships.svg";s:5:"title";s:21:"Teams for Memberships";s:4:"copy";s:123:"Adds B2B functionality to WooCommerce Memberships, allowing sites to sell team, group, corporate, or family member accounts";s:11:"button-text";s:10:"Learn More";s:3:"url";s:63:"https://woocommerce.com/products/teams-woocommerce-memberships/";}i:6;a:8:{s:4:"slug";s:29:"product-edit-variation-images";s:7:"product";s:39:"woocommerce-additional-variation-images";s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:118:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/additional-variation-images.svg";s:5:"title";s:27:"Additional Variation Images";s:4:"copy";s:72:"Showcase your products in the best light with a image for each variation";s:11:"button-text";s:10:"Learn More";s:3:"url";s:73:"https://woocommerce.com/products/woocommerce-additional-variation-images/";}i:7;a:9:{s:4:"slug";s:47:"product-edit-woocommerce-subscription-downloads";s:7:"product";s:34:"woocommerce-subscription-downloads";s:14:"show-if-active";a:1:{i:0;s:25:"woocommerce-subscriptions";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:113:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscription-downloads.svg";s:5:"title";s:22:"Subscription Downloads";s:4:"copy";s:57:"Give customers special downloads with their subscriptions";s:11:"button-text";s:10:"Learn More";s:3:"url";s:68:"https://woocommerce.com/products/woocommerce-subscription-downloads/";}i:8;a:8:{s:4:"slug";s:31:"product-edit-min-max-quantities";s:7:"product";s:30:"woocommerce-min-max-quantities";s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:109:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/min-max-quantities.svg";s:5:"title";s:18:"Min/Max Quantities";s:4:"copy";s:81:"Specify minimum and maximum allowed product quantities for orders to be completed";s:11:"button-text";s:10:"Learn More";s:3:"url";s:52:"https://woocommerce.com/products/min-max-quantities/";}i:9;a:8:{s:4:"slug";s:28:"product-edit-name-your-price";s:7:"product";s:27:"woocommerce-name-your-price";s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:106:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/name-your-price.svg";s:5:"title";s:15:"Name Your Price";s:4:"copy";s:70:"Let customers pay what they want - useful for donations, tips and more";s:11:"button-text";s:10:"Learn More";s:3:"url";s:49:"https://woocommerce.com/products/name-your-price/";}i:10;a:8:{s:4:"slug";s:42:"product-edit-woocommerce-one-page-checkout";s:7:"product";s:29:"woocommerce-one-page-checkout";s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:108:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/one-page-checkout.svg";s:5:"title";s:17:"One Page Checkout";s:4:"copy";s:92:"Don\'t make customers click around - let them choose products, checkout & pay all on one page";s:11:"button-text";s:10:"Learn More";s:3:"url";s:63:"https://woocommerce.com/products/woocommerce-one-page-checkout/";}i:11;a:9:{s:4:"slug";s:24:"product-edit-automatewoo";s:7:"product";s:11:"automatewoo";s:14:"show-if-active";a:1:{i:0;s:25:"woocommerce-subscriptions";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:104:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscriptions.svg";s:5:"title";s:23:"Automate your marketing";s:4:"copy";s:89:"Win customers and keep them coming back with a nearly endless range of powerful workflows";s:11:"button-text";s:10:"Learn More";s:3:"url";s:45:"https://woocommerce.com/products/automatewoo/";}i:12;a:4:{s:4:"slug";s:19:"orders-empty-header";s:7:"context";s:24:"orders-list-empty-header";s:5:"title";s:20:"Tools for your store";s:13:"allow-dismiss";b:0;}i:13;a:6:{s:4:"slug";s:30:"orders-empty-footer-browse-all";s:7:"context";s:24:"orders-list-empty-footer";s:9:"link-text";s:21:"Browse all extensions";s:3:"url";s:64:"https://woocommerce.com/product-category/woocommerce-extensions/";s:8:"promoted";s:31:"category-woocommerce-extensions";s:13:"allow-dismiss";b:0;}i:14;a:8:{s:4:"slug";s:19:"orders-empty-wc-pay";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:20:"woocommerce-payments";s:4:"icon";s:111:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/woocommerce-payments.svg";s:5:"title";s:20:"WooCommerce Payments";s:4:"copy";s:125:"Securely accept payments and manage transactions directly from your WooCommerce dashboard – no setup costs or monthly fees.";s:11:"button-text";s:10:"Learn More";s:3:"url";s:54:"https://woocommerce.com/products/woocommerce-payments/";}i:15;a:8:{s:4:"slug";s:19:"orders-empty-zapier";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:18:"woocommerce-zapier";s:4:"icon";s:97:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/zapier.svg";s:5:"title";s:6:"Zapier";s:4:"copy";s:88:"Save time and increase productivity by connecting your store to more than 1000+ services";s:11:"button-text";s:10:"Learn More";s:3:"url";s:52:"https://woocommerce.com/products/woocommerce-zapier/";}i:16;a:8:{s:4:"slug";s:30:"orders-empty-shipment-tracking";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:29:"woocommerce-shipment-tracking";s:4:"icon";s:108:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/shipment-tracking.svg";s:5:"title";s:17:"Shipment Tracking";s:4:"copy";s:86:"Let customers know when their orders will arrive by adding shipment tracking to emails";s:11:"button-text";s:10:"Learn More";s:3:"url";s:51:"https://woocommerce.com/products/shipment-tracking/";}i:17;a:8:{s:4:"slug";s:32:"orders-empty-table-rate-shipping";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:31:"woocommerce-table-rate-shipping";s:4:"icon";s:110:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/table-rate-shipping.svg";s:5:"title";s:19:"Table Rate Shipping";s:4:"copy";s:122:"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count";s:11:"button-text";s:10:"Learn More";s:3:"url";s:53:"https://woocommerce.com/products/table-rate-shipping/";}i:18;a:8:{s:4:"slug";s:40:"orders-empty-shipping-carrier-extensions";s:7:"context";s:22:"orders-list-empty-body";s:4:"icon";s:118:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/shipping-carrier-extensions.svg";s:5:"title";s:27:"Shipping Carrier Extensions";s:4:"copy";s:116:"Show live rates from FedEx, UPS, USPS and more directly on your store - never under or overcharge for shipping again";s:11:"button-text";s:13:"Find Carriers";s:8:"promoted";s:26:"category-shipping-carriers";s:3:"url";s:99:"https://woocommerce.com/product-category/woocommerce-extensions/shipping-methods/shipping-carriers/";}i:19;a:8:{s:4:"slug";s:32:"orders-empty-google-product-feed";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:25:"woocommerce-product-feeds";s:4:"icon";s:110:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/google-product-feed.svg";s:5:"title";s:19:"Google Product Feed";s:4:"copy";s:76:"Increase sales by letting customers find you when they\'re shopping on Google";s:11:"button-text";s:10:"Learn More";s:3:"url";s:53:"https://woocommerce.com/products/google-product-feed/";}i:20;a:4:{s:4:"slug";s:35:"products-empty-header-product-types";s:7:"context";s:26:"products-list-empty-header";s:5:"title";s:23:"Other types of products";s:13:"allow-dismiss";b:0;}i:21;a:6:{s:4:"slug";s:32:"products-empty-footer-browse-all";s:7:"context";s:26:"products-list-empty-footer";s:9:"link-text";s:21:"Browse all extensions";s:3:"url";s:64:"https://woocommerce.com/product-category/woocommerce-extensions/";s:8:"promoted";s:31:"category-woocommerce-extensions";s:13:"allow-dismiss";b:0;}i:22;a:8:{s:4:"slug";s:30:"products-empty-product-vendors";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:27:"woocommerce-product-vendors";s:4:"icon";s:106:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-vendors.svg";s:5:"title";s:15:"Product Vendors";s:4:"copy";s:47:"Turn your store into a multi-vendor marketplace";s:11:"button-text";s:10:"Learn More";s:3:"url";s:49:"https://woocommerce.com/products/product-vendors/";}i:23;a:8:{s:4:"slug";s:26:"products-empty-memberships";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:23:"woocommerce-memberships";s:4:"icon";s:102:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/memberships.svg";s:5:"title";s:11:"Memberships";s:4:"copy";s:76:"Give members access to restricted content or products, for a fee or for free";s:11:"button-text";s:10:"Learn More";s:3:"url";s:57:"https://woocommerce.com/products/woocommerce-memberships/";}i:24;a:9:{s:4:"slug";s:35:"products-empty-woocommerce-deposits";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:20:"woocommerce-deposits";s:14:"show-if-active";a:1:{i:0;s:20:"woocommerce-bookings";}s:4:"icon";s:99:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/deposits.svg";s:5:"title";s:8:"Deposits";s:4:"copy";s:75:"Make it easier for customers to pay by offering a deposit or a payment plan";s:11:"button-text";s:10:"Learn More";s:3:"url";s:54:"https://woocommerce.com/products/woocommerce-deposits/";}i:25;a:8:{s:4:"slug";s:40:"products-empty-woocommerce-subscriptions";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:25:"woocommerce-subscriptions";s:4:"icon";s:104:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscriptions.svg";s:5:"title";s:13:"Subscriptions";s:4:"copy";s:97:"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis";s:11:"button-text";s:10:"Learn More";s:3:"url";s:59:"https://woocommerce.com/products/woocommerce-subscriptions/";}i:26;a:8:{s:4:"slug";s:35:"products-empty-woocommerce-bookings";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:20:"woocommerce-bookings";s:4:"icon";s:99:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/bookings.svg";s:5:"title";s:8:"Bookings";s:4:"copy";s:99:"Allow customers to book appointments, make reservations or rent equipment without leaving your site";s:11:"button-text";s:10:"Learn More";s:3:"url";s:54:"https://woocommerce.com/products/woocommerce-bookings/";}i:27;a:8:{s:4:"slug";s:30:"products-empty-product-bundles";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:27:"woocommerce-product-bundles";s:4:"icon";s:106:"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-bundles.svg";s:5:"title";s:15:"Product Bundles";s:4:"copy";s:49:"Offer customizable bundles and assembled products";s:11:"button-text";s:10:"Learn More";s:3:"url";s:49:"https://woocommerce.com/products/product-bundles/";}}s:7:"updated";i:1661641056;}', 'no'),
(1246, 'woocommerce_ces_tracks_queue', 'a:0:{}', 'yes'),
(1252, 'woocommerce_clear_ces_tracks_queue_for_page', '', 'yes'),
(1398, 'category_children', 'a:0:{}', 'yes'),
(1501, 'woocommerce_tracker_last_send', '1665504258', 'yes'),
(1511, 'woocommerce_tracker_ua', 'a:4:{i:0;s:84:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:101.0) Gecko/20100101 Firefox/101.0";i:1;s:84:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:102.0) Gecko/20100101 Firefox/102.0";i:2;s:84:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:103.0) Gecko/20100101 Firefox/103.0";i:3;s:84:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:105.0) Gecko/20100101 Firefox/105.0";}', 'no'),
(1571, 'woocommerce_task_list_reminder_bar_hidden', 'yes', 'yes'),
(1587, 'user_count', '1', 'no'),
(1588, 'db_upgraded', '', 'yes'),
(1626, 'can_compress_scripts', '1', 'no'),
(1710, 'woocommerce_analytics_enabled', 'yes', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1716, 'gf_previous_db_version', '2.6.6', 'yes'),
(1717, 'gf_upgrade_lock', '', 'yes'),
(1718, 'gform_sticky_admin_messages', 'a:0:{}', 'yes'),
(1721, 'gf_rest_api_db_version', '2.6.7', 'yes'),
(1727, 'woocommerce_attribute_lookup_enabled', 'yes', 'yes'),
(1912, 'loginpress_customization', 'a:8:{s:12:"setting_logo";s:67:"http://localhost:8888/jtrc/wp-content/uploads/2022/07/jtrc_logo.png";s:20:"customize_logo_width";i:143;s:18:"gallery_background";s:78:"http://localhost:8888/jtrc/wp-content/plugins/loginpress/img/gallery/img-9.jpg";s:20:"customize_form_width";i:603;s:21:"customize_form_height";i:308;s:21:"customize_form_radius";i:9;s:21:"customize_form_shadow";i:0;s:22:"customize_form_opacity";i:0;}', 'yes'),
(1913, 'loginpress_setting', 'a:7:{s:18:"session_expiration";i:0;s:16:"auto_remember_me";s:2:"on";s:21:"enable_reg_pass_field";s:2:"on";s:11:"login_order";s:7:"default";s:16:"lostpassword_url";s:2:"on";s:14:"reset_settings";s:3:"off";s:20:"loginpress_uninstall";s:3:"off";}', 'yes'),
(1915, 'loginpress_active_time', '1658247703', 'no'),
(1916, 'loginpress_premium', '', 'yes'),
(1918, '_loginpress_optin', 'no', 'yes'),
(1928, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(1929, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(1938, 'woocommerce_maybe_regenerate_images_hash', '0354fa9fd89ed0769e68ad19ec0251fa', 'yes'),
(2061, 'product_cat_children', 'a:0:{}', 'yes'),
(2463, 'loginpress_review_dismiss', 'yes', 'no'),
(2483, 'options_instagram', 'https://www.instagram.com/jtrusticcuisine/', 'no'),
(2484, '_options_instagram', 'field_630ae4a02b2d4', 'no'),
(2485, 'options_design_link', 'a:3:{s:5:"title";s:12:"lawsandcodes";s:3:"url";s:37:"http://www.instagram.com/lawsandcodes";s:6:"target";s:0:"";}', 'no'),
(2486, '_options_design_link', 'field_630ae543c64a4', 'no'),
(2498, 'widget_ddsoo_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(2502, 'DDSOO_businessId', '', 'yes'),
(2503, 'DDSOO_businessId_publish', '', 'yes'),
(2504, 'DDSOO_buttonText', 'Order Pickup & Delivery', 'yes'),
(2505, 'DDSOO_buttonText_publish', '', 'yes'),
(2506, 'DDSOO_position', '', 'yes'),
(2507, 'DDSOO_position_publish', '', 'yes'),
(2508, 'DDSOO_buttonBackgroundColor', '#ff0000', 'yes'),
(2509, 'DDSOO_buttonBackgroundColor_publish', '', 'yes'),
(2510, 'DDSOO_floatingBar', '0', 'yes'),
(2511, 'DDSOO_floatingBar_publish', '', 'yes'),
(2512, 'DDSOO_backgroundColor', '#ffffff', 'yes'),
(2513, 'DDSOO_backgroundColor_publish', '', 'yes'),
(2514, 'DDSOO_advanced_input', '1', 'yes'),
(2515, 'DDSOO_advanced_input_publish', '', 'yes'),
(2535, 'action_scheduler_migration_status', 'complete', 'yes'),
(2556, 'options_delivery_services', '3', 'no'),
(2557, '_options_delivery_services', 'field_630aed7634194', 'no'),
(2560, 'bodhi_svgs_plugin_version', '2.4.2', 'yes'),
(2569, 'options_delivery_services_0_logo', '132', 'no'),
(2570, '_options_delivery_services_0_logo', 'field_630aedc134195', 'no'),
(2571, 'options_delivery_services_0_link', '', 'no'),
(2572, '_options_delivery_services_0_link', 'field_630aedd134196', 'no'),
(2573, 'options_delivery_services_1_logo', '131', 'no'),
(2574, '_options_delivery_services_1_logo', 'field_630aedc134195', 'no'),
(2575, 'options_delivery_services_1_link', '', 'no'),
(2576, '_options_delivery_services_1_link', 'field_630aedd134196', 'no'),
(2577, 'options_delivery_services_2_logo', '130', 'no'),
(2578, '_options_delivery_services_2_logo', 'field_630aedc134195', 'no'),
(2579, 'options_delivery_services_2_link', '', 'no'),
(2580, '_options_delivery_services_2_link', 'field_630aedd134196', 'no'),
(2630, 'options_copyright_year', '2022', 'no'),
(2631, '_options_copyright_year', 'field_630af76094f8a', 'no'),
(2643, 'options_annoucement_banner', 'We Deliver! Check us out on <a href="http://www.ubereats.com" target="_blank" rel="noopener">Uber Eats</a>, <a href="http://www.doordash.com" target="_blank" rel="noopener">Doordash</a> or <a href="http://www.grubhub.com" target="_blank" rel="noopener">Grubhub!</a>', 'no'),
(2644, '_options_annoucement_banner', 'field_630af8619f7af', 'no'),
(2738, 'options_delivery_options_title', 'We Deliver!', 'no'),
(2739, '_options_delivery_options_title', 'field_630b03b2bdd61', 'no'),
(2740, 'options_payment_options_title', 'We Accept:', 'no'),
(2741, '_options_payment_options_title', 'field_630b036467cd2', 'no'),
(2742, 'options_payment_options', '', 'no'),
(2743, '_options_payment_options', 'field_630b036d67cd3', 'no'),
(3538, 'recovery_mode_email_last_sent', '1665545207', 'yes'),
(3544, 'wp_migrate_addon_schema', '1', 'yes'),
(3555, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1665545687;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=796 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 7, '_edit_lock', '1658260317:1'),
(4, 10, '_edit_last', '1'),
(5, 10, '_edit_lock', '1653843153:1'),
(6, 15, '_wp_attached_file', '2022/05/brooke-lark-08bOYnH_r_E-unsplash-scaled.jpg'),
(7, 15, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2560;s:6:"height";i:2031;s:4:"file";s:51:"2022/05/brooke-lark-08bOYnH_r_E-unsplash-scaled.jpg";s:8:"filesize";i:382001;s:5:"sizes";a:11:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:51:"brooke-lark-08bOYnH_r_E-unsplash-scaled-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4361;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:51:"brooke-lark-08bOYnH_r_E-unsplash-scaled-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2668;}s:18:"woocommerce_single";a:5:{s:4:"file";s:51:"brooke-lark-08bOYnH_r_E-unsplash-scaled-300x238.jpg";s:5:"width";i:300;s:6:"height";i:238;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10771;}s:6:"medium";a:5:{s:4:"file";s:44:"brooke-lark-08bOYnH_r_E-unsplash-300x238.jpg";s:5:"width";i:300;s:6:"height";i:238;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10802;}s:5:"large";a:5:{s:4:"file";s:45:"brooke-lark-08bOYnH_r_E-unsplash-1024x812.jpg";s:5:"width";i:1024;s:6:"height";i:812;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:81029;}s:9:"thumbnail";a:5:{s:4:"file";s:44:"brooke-lark-08bOYnH_r_E-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4349;}s:12:"medium_large";a:5:{s:4:"file";s:44:"brooke-lark-08bOYnH_r_E-unsplash-768x609.jpg";s:5:"width";i:768;s:6:"height";i:609;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:49843;}s:9:"1536x1536";a:5:{s:4:"file";s:46:"brooke-lark-08bOYnH_r_E-unsplash-1536x1219.jpg";s:5:"width";i:1536;s:6:"height";i:1219;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:162129;}s:9:"2048x2048";a:5:{s:4:"file";s:46:"brooke-lark-08bOYnH_r_E-unsplash-2048x1625.jpg";s:5:"width";i:2048;s:6:"height";i:1625;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:262849;}s:12:"shop_catalog";a:6:{s:4:"file";s:51:"brooke-lark-08bOYnH_r_E-unsplash-scaled-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4361;s:9:"uncropped";b:0;}s:14:"shop_thumbnail";a:5:{s:4:"file";s:51:"brooke-lark-08bOYnH_r_E-unsplash-scaled-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2668;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(8, 16, '_wp_attached_file', '2022/05/food-13549.png'),
(9, 16, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:531;s:6:"height";i:518;s:4:"file";s:22:"2022/05/food-13549.png";s:8:"filesize";i:632802;s:5:"sizes";a:7:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"food-13549-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:48943;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"food-13549-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:23091;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"food-13549-300x293.png";s:5:"width";i:300;s:6:"height";i:293;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:173280;}s:6:"medium";a:5:{s:4:"file";s:22:"food-13549-300x293.png";s:5:"width";i:300;s:6:"height";i:293;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:173280;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"food-13549-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:48943;}s:12:"shop_catalog";a:6:{s:4:"file";s:22:"food-13549-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:48943;s:9:"uncropped";b:0;}s:14:"shop_thumbnail";a:5:{s:4:"file";s:22:"food-13549-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:23091;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(10, 17, '_wp_attached_file', '2022/05/lily-banse-YHSwy6uqvk-unsplash-scaled.jpg'),
(11, 17, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:49:"2022/05/lily-banse-YHSwy6uqvk-unsplash-scaled.jpg";s:8:"filesize";i:920967;s:5:"sizes";a:11:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:49:"lily-banse-YHSwy6uqvk-unsplash-scaled-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8597;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:49:"lily-banse-YHSwy6uqvk-unsplash-scaled-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4687;}s:18:"woocommerce_single";a:5:{s:4:"file";s:49:"lily-banse-YHSwy6uqvk-unsplash-scaled-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19731;}s:6:"medium";a:5:{s:4:"file";s:42:"lily-banse-YHSwy6uqvk-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19730;}s:5:"large";a:5:{s:4:"file";s:43:"lily-banse-YHSwy6uqvk-unsplash-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:180036;}s:9:"thumbnail";a:5:{s:4:"file";s:42:"lily-banse-YHSwy6uqvk-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8601;}s:12:"medium_large";a:5:{s:4:"file";s:42:"lily-banse-YHSwy6uqvk-unsplash-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:105962;}s:9:"1536x1536";a:5:{s:4:"file";s:44:"lily-banse-YHSwy6uqvk-unsplash-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:373385;}s:9:"2048x2048";a:5:{s:4:"file";s:44:"lily-banse-YHSwy6uqvk-unsplash-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:623647;}s:12:"shop_catalog";a:6:{s:4:"file";s:49:"lily-banse-YHSwy6uqvk-unsplash-scaled-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8597;s:9:"uncropped";b:0;}s:14:"shop_thumbnail";a:5:{s:4:"file";s:49:"lily-banse-YHSwy6uqvk-unsplash-scaled-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4687;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(12, 7, '_edit_last', '1'),
(13, 7, 'homepage_slider_0_image', '67'),
(14, 7, '_homepage_slider_0_image', 'field_6293a522797d3'),
(15, 7, 'homepage_slider_0_name', 'Waffles'),
(16, 7, '_homepage_slider_0_name', 'field_6293a537797d4'),
(17, 7, 'homepage_slider_0_link', 'a:3:{s:5:"title";s:22:"Waffles ( Small Size )";s:3:"url";s:38:"//localhost:3000/jtrc/product/waffles/";s:6:"target";s:0:"";}'),
(18, 7, '_homepage_slider_0_link', 'field_6293a53d797d5'),
(19, 7, 'homepage_slider_1_image', '70'),
(20, 7, '_homepage_slider_1_image', 'field_6293a522797d3'),
(21, 7, 'homepage_slider_1_name', 'Scrambled Eggs'),
(22, 7, '_homepage_slider_1_name', 'field_6293a537797d4'),
(23, 7, 'homepage_slider_1_link', 'a:3:{s:5:"title";s:24:"Scrambled Eggs ( Small )";s:3:"url";s:51:"//localhost:3000/jtrc/product/scrambled-eggs-small/";s:6:"target";s:0:"";}'),
(24, 7, '_homepage_slider_1_link', 'field_6293a53d797d5'),
(31, 7, 'homepage_slider', '2'),
(32, 7, '_homepage_slider', 'field_6293a512797d2'),
(33, 18, 'homepage_slider_0_image', '15'),
(34, 18, '_homepage_slider_0_image', 'field_6293a522797d3'),
(35, 18, 'homepage_slider_0_name', ''),
(36, 18, '_homepage_slider_0_name', 'field_6293a537797d4'),
(37, 18, 'homepage_slider_0_link', ''),
(38, 18, '_homepage_slider_0_link', 'field_6293a53d797d5'),
(39, 18, 'homepage_slider_1_image', '16'),
(40, 18, '_homepage_slider_1_image', 'field_6293a522797d3'),
(41, 18, 'homepage_slider_1_name', ''),
(42, 18, '_homepage_slider_1_name', 'field_6293a537797d4'),
(43, 18, 'homepage_slider_1_link', ''),
(44, 18, '_homepage_slider_1_link', 'field_6293a53d797d5'),
(45, 18, 'homepage_slider_2_image', '17'),
(46, 18, '_homepage_slider_2_image', 'field_6293a522797d3'),
(47, 18, 'homepage_slider_2_name', ''),
(48, 18, '_homepage_slider_2_name', 'field_6293a537797d4'),
(49, 18, 'homepage_slider_2_link', ''),
(50, 18, '_homepage_slider_2_link', 'field_6293a53d797d5'),
(51, 18, 'homepage_slider', '3'),
(52, 18, '_homepage_slider', 'field_6293a512797d2'),
(71, 21, '_edit_lock', '1653860190:1'),
(72, 23, '_edit_last', '1'),
(73, 23, '_edit_lock', '1653858119:1'),
(74, 30, '_wp_attached_file', 'woocommerce-placeholder.png'),
(75, 30, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1200;s:6:"height";i:1200;s:4:"file";s:27:"woocommerce-placeholder.png";s:8:"filesize";i:102644;s:5:"sizes";a:7:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:35:"woocommerce-placeholder-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4209;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:35:"woocommerce-placeholder-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2273;}s:18:"woocommerce_single";a:5:{s:4:"file";s:35:"woocommerce-placeholder-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:11776;}s:6:"medium";a:5:{s:4:"file";s:35:"woocommerce-placeholder-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:11776;}s:5:"large";a:5:{s:4:"file";s:37:"woocommerce-placeholder-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:92539;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"woocommerce-placeholder-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4209;}s:12:"medium_large";a:5:{s:4:"file";s:35:"woocommerce-placeholder-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:56337;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(76, 36, '_menu_item_type', 'post_type'),
(77, 36, '_menu_item_menu_item_parent', '0'),
(78, 36, '_menu_item_object_id', '21'),
(79, 36, '_menu_item_object', 'page'),
(80, 36, '_menu_item_target', ''),
(81, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(82, 36, '_menu_item_xfn', ''),
(83, 36, '_menu_item_url', ''),
(85, 21, '_edit_last', '1'),
(86, 21, 'menu_title', 'Our Menu'),
(87, 21, '_menu_title', 'field_6293d1bb456ea'),
(88, 21, 'breakfast_items', '2'),
(89, 21, '_breakfast_items', 'field_6293cd42889c2'),
(90, 38, 'menu_title', 'Our Menu'),
(91, 38, '_menu_title', 'field_6293d1bb456ea'),
(92, 38, 'breakfast_items', ''),
(93, 38, '_breakfast_items', 'field_6293cd42889c2'),
(94, 21, 'breakfast_items_0_menu_item_name', 'Waffles'),
(95, 21, '_breakfast_items_0_menu_item_name', 'field_6293cd9b889c3'),
(96, 21, 'breakfast_items_0_menu_item_description', 'Waffles Item Description Text'),
(97, 21, '_breakfast_items_0_menu_item_description', 'field_6293ce19cf03f'),
(98, 21, 'breakfast_items_0_menu_item_price_s', '50'),
(99, 21, '_breakfast_items_0_menu_item_price_s', 'field_6293cdd8889c4'),
(100, 21, 'breakfast_items_0_menu_item_price_f', '100'),
(101, 21, '_breakfast_items_0_menu_item_price_f', 'field_6293cdec889c5'),
(102, 21, 'breakfast_items_0_menu_item_link', ''),
(103, 21, '_breakfast_items_0_menu_item_link', 'field_6293ce85f443b'),
(104, 39, 'menu_title', 'Our Menu'),
(105, 39, '_menu_title', 'field_6293d1bb456ea'),
(106, 39, 'breakfast_items', '1'),
(107, 39, '_breakfast_items', 'field_6293cd42889c2'),
(108, 39, 'breakfast_items_0_menu_item_name', 'Waffles'),
(109, 39, '_breakfast_items_0_menu_item_name', 'field_6293cd9b889c3'),
(110, 39, 'breakfast_items_0_menu_item_description', ''),
(111, 39, '_breakfast_items_0_menu_item_description', 'field_6293ce19cf03f'),
(112, 39, 'breakfast_items_0_menu_item_price_s', '50'),
(113, 39, '_breakfast_items_0_menu_item_price_s', 'field_6293cdd8889c4'),
(114, 39, 'breakfast_items_0_menu_item_price_f', '100'),
(115, 39, '_breakfast_items_0_menu_item_price_f', 'field_6293cdec889c5'),
(116, 39, 'breakfast_items_0_menu_item_link', ''),
(117, 39, '_breakfast_items_0_menu_item_link', 'field_6293ce85f443b'),
(118, 21, 'menu_description', '<blockquote id="output" class="page-generator__lorem">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</blockquote>'),
(119, 21, '_menu_description', 'field_6293d39ff58ee'),
(120, 21, 'breakfast_items_1_menu_item_name', 'Bacon'),
(121, 21, '_breakfast_items_1_menu_item_name', 'field_6293cd9b889c3'),
(122, 21, 'breakfast_items_1_menu_item_description', 'Bacon Item Description Text'),
(123, 21, '_breakfast_items_1_menu_item_description', 'field_6293ce19cf03f'),
(124, 21, 'breakfast_items_1_menu_item_price_s', '65'),
(125, 21, '_breakfast_items_1_menu_item_price_s', 'field_6293cdd8889c4') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(126, 21, 'breakfast_items_1_menu_item_price_f', '90'),
(127, 21, '_breakfast_items_1_menu_item_price_f', 'field_6293cdec889c5'),
(128, 21, 'breakfast_items_1_menu_item_link', ''),
(129, 21, '_breakfast_items_1_menu_item_link', 'field_6293ce85f443b'),
(130, 41, 'menu_title', 'Our Menu'),
(131, 41, '_menu_title', 'field_6293d1bb456ea'),
(132, 41, 'breakfast_items', '2'),
(133, 41, '_breakfast_items', 'field_6293cd42889c2'),
(134, 41, 'breakfast_items_0_menu_item_name', 'Waffles'),
(135, 41, '_breakfast_items_0_menu_item_name', 'field_6293cd9b889c3'),
(136, 41, 'breakfast_items_0_menu_item_description', 'Waffles Item Description Text'),
(137, 41, '_breakfast_items_0_menu_item_description', 'field_6293ce19cf03f'),
(138, 41, 'breakfast_items_0_menu_item_price_s', '50'),
(139, 41, '_breakfast_items_0_menu_item_price_s', 'field_6293cdd8889c4'),
(140, 41, 'breakfast_items_0_menu_item_price_f', '100'),
(141, 41, '_breakfast_items_0_menu_item_price_f', 'field_6293cdec889c5'),
(142, 41, 'breakfast_items_0_menu_item_link', ''),
(143, 41, '_breakfast_items_0_menu_item_link', 'field_6293ce85f443b'),
(144, 41, 'menu_description', '<blockquote id="output" class="page-generator__lorem">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</blockquote>'),
(145, 41, '_menu_description', 'field_6293d39ff58ee'),
(146, 41, 'breakfast_items_1_menu_item_name', 'Bacon'),
(147, 41, '_breakfast_items_1_menu_item_name', 'field_6293cd9b889c3'),
(148, 41, 'breakfast_items_1_menu_item_description', 'Bacon Item Description Text'),
(149, 41, '_breakfast_items_1_menu_item_description', 'field_6293ce19cf03f'),
(150, 41, 'breakfast_items_1_menu_item_price_s', '65'),
(151, 41, '_breakfast_items_1_menu_item_price_s', 'field_6293cdd8889c4'),
(152, 41, 'breakfast_items_1_menu_item_price_f', '90'),
(153, 41, '_breakfast_items_1_menu_item_price_f', 'field_6293cdec889c5'),
(154, 41, 'breakfast_items_1_menu_item_link', ''),
(155, 41, '_breakfast_items_1_menu_item_link', 'field_6293ce85f443b'),
(156, 21, 'appetizers_items_0_menu_item_name', 'Fried Chicken Cheddar Biscuit Sliders'),
(157, 21, '_appetizers_items_0_menu_item_name', 'field_6293df36d1f5f'),
(158, 21, 'appetizers_items_0_menu_item_description', 'Steamed, char-grilled, pan-fried, stir-fried, or slow-cooked.'),
(159, 21, '_appetizers_items_0_menu_item_description', 'field_6293df36d1f60'),
(160, 21, 'appetizers_items_0_quantityprice_small', '20pcs/$100'),
(161, 21, '_appetizers_items_0_quantityprice_small', 'field_6293df36d1f61'),
(162, 21, 'appetizers_items_0_quantityprice_large', '40pcs/$150'),
(163, 21, '_appetizers_items_0_quantityprice_large', 'field_6293df36d1f62'),
(164, 21, 'appetizers_items_0_menu_item_link', ''),
(165, 21, '_appetizers_items_0_menu_item_link', 'field_6293df36d1f63'),
(166, 21, 'appetizers_items_1_menu_item_name', 'Fried Tilapia Tacos'),
(167, 21, '_appetizers_items_1_menu_item_name', 'field_6293df36d1f5f'),
(168, 21, 'appetizers_items_1_menu_item_description', 'Steamed, char-grilled, pan-fried, stir-fried, or slow-cooked.'),
(169, 21, '_appetizers_items_1_menu_item_description', 'field_6293df36d1f60'),
(170, 21, 'appetizers_items_1_quantityprice_small', '20pcs/$100'),
(171, 21, '_appetizers_items_1_quantityprice_small', 'field_6293df36d1f61'),
(172, 21, 'appetizers_items_1_quantityprice_large', '40pcs/$170'),
(173, 21, '_appetizers_items_1_quantityprice_large', 'field_6293df36d1f62'),
(174, 21, 'appetizers_items_1_menu_item_link', ''),
(175, 21, '_appetizers_items_1_menu_item_link', 'field_6293df36d1f63'),
(176, 21, 'appetizers_items_2_menu_item_name', 'Seared Crab Cakes'),
(177, 21, '_appetizers_items_2_menu_item_name', 'field_6293df36d1f5f'),
(178, 21, 'appetizers_items_2_menu_item_description', 'Steamed, char-grilled, pan-fried, stir-fried, or slow-cooked.'),
(179, 21, '_appetizers_items_2_menu_item_description', 'field_6293df36d1f60'),
(180, 21, 'appetizers_items_2_quantityprice_small', '20pcs/$90'),
(181, 21, '_appetizers_items_2_quantityprice_small', 'field_6293df36d1f61'),
(182, 21, 'appetizers_items_2_quantityprice_large', '40pcs/$140'),
(183, 21, '_appetizers_items_2_quantityprice_large', 'field_6293df36d1f62'),
(184, 21, 'appetizers_items_2_menu_item_link', ''),
(185, 21, '_appetizers_items_2_menu_item_link', 'field_6293df36d1f63'),
(186, 21, 'appetizers_items', '3'),
(187, 21, '_appetizers_items', 'field_6293df36d1f5e'),
(188, 48, 'menu_title', 'Our Menu'),
(189, 48, '_menu_title', 'field_6293d1bb456ea'),
(190, 48, 'breakfast_items', '2'),
(191, 48, '_breakfast_items', 'field_6293cd42889c2'),
(192, 48, 'breakfast_items_0_menu_item_name', 'Waffles'),
(193, 48, '_breakfast_items_0_menu_item_name', 'field_6293cd9b889c3'),
(194, 48, 'breakfast_items_0_menu_item_description', 'Waffles Item Description Text'),
(195, 48, '_breakfast_items_0_menu_item_description', 'field_6293ce19cf03f'),
(196, 48, 'breakfast_items_0_menu_item_price_s', '50'),
(197, 48, '_breakfast_items_0_menu_item_price_s', 'field_6293cdd8889c4'),
(198, 48, 'breakfast_items_0_menu_item_price_f', '100'),
(199, 48, '_breakfast_items_0_menu_item_price_f', 'field_6293cdec889c5'),
(200, 48, 'breakfast_items_0_menu_item_link', ''),
(201, 48, '_breakfast_items_0_menu_item_link', 'field_6293ce85f443b'),
(202, 48, 'menu_description', '<blockquote id="output" class="page-generator__lorem">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</blockquote>'),
(203, 48, '_menu_description', 'field_6293d39ff58ee'),
(204, 48, 'breakfast_items_1_menu_item_name', 'Bacon'),
(205, 48, '_breakfast_items_1_menu_item_name', 'field_6293cd9b889c3'),
(206, 48, 'breakfast_items_1_menu_item_description', 'Bacon Item Description Text'),
(207, 48, '_breakfast_items_1_menu_item_description', 'field_6293ce19cf03f'),
(208, 48, 'breakfast_items_1_menu_item_price_s', '65'),
(209, 48, '_breakfast_items_1_menu_item_price_s', 'field_6293cdd8889c4'),
(210, 48, 'breakfast_items_1_menu_item_price_f', '90'),
(211, 48, '_breakfast_items_1_menu_item_price_f', 'field_6293cdec889c5'),
(212, 48, 'breakfast_items_1_menu_item_link', ''),
(213, 48, '_breakfast_items_1_menu_item_link', 'field_6293ce85f443b'),
(214, 48, 'appetizers_items_0_menu_item_name', 'Fried Chicken Cheddar Biscuit Sliders'),
(215, 48, '_appetizers_items_0_menu_item_name', 'field_6293df36d1f5f'),
(216, 48, 'appetizers_items_0_menu_item_description', 'Steamed, char-grilled, pan-fried, stir-fried, or slow-cooked.'),
(217, 48, '_appetizers_items_0_menu_item_description', 'field_6293df36d1f60'),
(218, 48, 'appetizers_items_0_quantityprice_small', '20pcs/$100'),
(219, 48, '_appetizers_items_0_quantityprice_small', 'field_6293df36d1f61'),
(220, 48, 'appetizers_items_0_quantityprice_large', '40pcs/$150'),
(221, 48, '_appetizers_items_0_quantityprice_large', 'field_6293df36d1f62'),
(222, 48, 'appetizers_items_0_menu_item_link', ''),
(223, 48, '_appetizers_items_0_menu_item_link', 'field_6293df36d1f63'),
(224, 48, 'appetizers_items_1_menu_item_name', 'Fried Tilapia Tacos'),
(225, 48, '_appetizers_items_1_menu_item_name', 'field_6293df36d1f5f') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(226, 48, 'appetizers_items_1_menu_item_description', 'Steamed, char-grilled, pan-fried, stir-fried, or slow-cooked.'),
(227, 48, '_appetizers_items_1_menu_item_description', 'field_6293df36d1f60'),
(228, 48, 'appetizers_items_1_quantityprice_small', '20pcs/$100'),
(229, 48, '_appetizers_items_1_quantityprice_small', 'field_6293df36d1f61'),
(230, 48, 'appetizers_items_1_quantityprice_large', '40pcs/$170'),
(231, 48, '_appetizers_items_1_quantityprice_large', 'field_6293df36d1f62'),
(232, 48, 'appetizers_items_1_menu_item_link', ''),
(233, 48, '_appetizers_items_1_menu_item_link', 'field_6293df36d1f63'),
(234, 48, 'appetizers_items_2_menu_item_name', 'Seared Crab Cakes'),
(235, 48, '_appetizers_items_2_menu_item_name', 'field_6293df36d1f5f'),
(236, 48, 'appetizers_items_2_menu_item_description', 'Steamed, char-grilled, pan-fried, stir-fried, or slow-cooked.'),
(237, 48, '_appetizers_items_2_menu_item_description', 'field_6293df36d1f60'),
(238, 48, 'appetizers_items_2_quantityprice_small', '20pcs/$90'),
(239, 48, '_appetizers_items_2_quantityprice_small', 'field_6293df36d1f61'),
(240, 48, 'appetizers_items_2_quantityprice_large', '40pcs/$140'),
(241, 48, '_appetizers_items_2_quantityprice_large', 'field_6293df36d1f62'),
(242, 48, 'appetizers_items_2_menu_item_link', ''),
(243, 48, '_appetizers_items_2_menu_item_link', 'field_6293df36d1f63'),
(244, 48, 'appetizers_items', '3'),
(245, 48, '_appetizers_items', 'field_6293df36d1f5e'),
(252, 55, '_edit_lock', '1664311211:1'),
(253, 57, '_menu_item_type', 'post_type'),
(254, 57, '_menu_item_menu_item_parent', '0'),
(255, 57, '_menu_item_object_id', '55'),
(256, 57, '_menu_item_object', 'page'),
(257, 57, '_menu_item_target', ''),
(258, 57, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(259, 57, '_menu_item_xfn', ''),
(260, 57, '_menu_item_url', ''),
(262, 58, '_menu_item_type', 'post_type'),
(263, 58, '_menu_item_menu_item_parent', '0'),
(264, 58, '_menu_item_object_id', '32'),
(265, 58, '_menu_item_object', 'page'),
(266, 58, '_menu_item_target', ''),
(267, 58, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(268, 58, '_menu_item_xfn', ''),
(269, 58, '_menu_item_url', ''),
(271, 59, '_menu_item_type', 'post_type'),
(272, 59, '_menu_item_menu_item_parent', '0'),
(273, 59, '_menu_item_object_id', '31'),
(274, 59, '_menu_item_object', 'page'),
(275, 59, '_menu_item_target', ''),
(276, 59, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(277, 59, '_menu_item_xfn', ''),
(278, 59, '_menu_item_url', ''),
(280, 60, '_menu_item_type', 'post_type'),
(281, 60, '_menu_item_menu_item_parent', '0'),
(282, 60, '_menu_item_object_id', '21'),
(283, 60, '_menu_item_object', 'page'),
(284, 60, '_menu_item_target', ''),
(285, 60, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(286, 60, '_menu_item_xfn', ''),
(287, 60, '_menu_item_url', ''),
(289, 61, 'homepage_slider_0_image', '15'),
(290, 61, '_homepage_slider_0_image', 'field_6293a522797d3'),
(291, 61, 'homepage_slider_0_name', 'Food Item Name'),
(292, 61, '_homepage_slider_0_name', 'field_6293a537797d4'),
(293, 61, 'homepage_slider_0_link', ''),
(294, 61, '_homepage_slider_0_link', 'field_6293a53d797d5'),
(295, 61, 'homepage_slider_1_image', '17'),
(296, 61, '_homepage_slider_1_image', 'field_6293a522797d3'),
(297, 61, 'homepage_slider_1_name', 'Food Item Name'),
(298, 61, '_homepage_slider_1_name', 'field_6293a537797d4'),
(299, 61, 'homepage_slider_1_link', ''),
(300, 61, '_homepage_slider_1_link', 'field_6293a53d797d5'),
(301, 61, 'homepage_slider', '2'),
(302, 61, '_homepage_slider', 'field_6293a512797d2'),
(303, 62, '_edit_last', '1'),
(304, 62, '_edit_lock', '1661640919:1'),
(305, 62, '_children', 'a:2:{i:0;i:63;i:1;i:66;}'),
(306, 62, 'total_sales', '0'),
(307, 62, '_tax_status', 'taxable'),
(308, 62, '_tax_class', ''),
(309, 62, '_manage_stock', 'no'),
(310, 62, '_backorders', 'no'),
(311, 62, '_sold_individually', 'no'),
(312, 62, '_virtual', 'no'),
(313, 62, '_downloadable', 'no'),
(314, 62, '_download_limit', '-1'),
(315, 62, '_download_expiry', '-1'),
(316, 62, '_stock', NULL),
(317, 62, '_stock_status', 'instock'),
(318, 62, '_wc_average_rating', '5.00'),
(319, 62, '_wc_review_count', '1'),
(320, 62, '_product_version', '6.7.0'),
(321, 63, '_edit_last', '1'),
(322, 63, '_edit_lock', '1658162671:1'),
(323, 63, 'total_sales', '0'),
(324, 63, '_tax_status', 'taxable'),
(325, 63, '_tax_class', ''),
(326, 63, '_manage_stock', 'no'),
(327, 63, '_backorders', 'no'),
(328, 63, '_sold_individually', 'no'),
(329, 63, '_virtual', 'no'),
(330, 63, '_downloadable', 'no'),
(331, 63, '_download_limit', '-1'),
(332, 63, '_download_expiry', '-1'),
(333, 63, '_stock', NULL),
(334, 63, '_stock_status', 'outofstock'),
(335, 63, '_wc_average_rating', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(336, 63, '_wc_review_count', '0'),
(337, 63, '_product_attributes', 'a:2:{s:10:"small-size";a:6:{s:4:"name";s:10:"Small Size";s:5:"value";s:5:"Small";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:0;}s:10:"large-size";a:6:{s:4:"name";s:10:"Large Size";s:5:"value";s:5:"Large";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:0;}}'),
(338, 63, '_product_version', '6.7.0'),
(358, 63, '_regular_price', '50.00'),
(359, 63, '_price', '50.00'),
(360, 66, '_edit_last', '1'),
(361, 66, '_edit_lock', '1661650000:1'),
(362, 66, '_regular_price', '100.00'),
(363, 66, 'total_sales', '0'),
(364, 66, '_tax_status', 'taxable'),
(365, 66, '_tax_class', ''),
(366, 66, '_manage_stock', 'no'),
(367, 66, '_backorders', 'no'),
(368, 66, '_sold_individually', 'no'),
(369, 66, '_virtual', 'no'),
(370, 66, '_downloadable', 'no'),
(371, 66, '_download_limit', '-1'),
(372, 66, '_download_expiry', '-1'),
(373, 66, '_stock', NULL),
(374, 66, '_stock_status', 'instock'),
(375, 66, '_wc_average_rating', '0'),
(376, 66, '_wc_review_count', '0'),
(377, 66, '_product_version', '6.7.0'),
(378, 66, '_price', '100.00'),
(379, 67, '_wp_attached_file', '2022/05/mae-mu-dEUyLofZe5o-unsplash-scaled.jpg'),
(380, 67, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2560;s:6:"height";i:2048;s:4:"file";s:46:"2022/05/mae-mu-dEUyLofZe5o-unsplash-scaled.jpg";s:8:"filesize";i:536883;s:5:"sizes";a:12:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:46:"mae-mu-dEUyLofZe5o-unsplash-scaled-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18812;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:46:"mae-mu-dEUyLofZe5o-unsplash-scaled-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4196;}s:18:"woocommerce_single";a:5:{s:4:"file";s:46:"mae-mu-dEUyLofZe5o-unsplash-scaled-300x240.jpg";s:5:"width";i:300;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15228;}s:6:"medium";a:5:{s:4:"file";s:39:"mae-mu-dEUyLofZe5o-unsplash-300x240.jpg";s:5:"width";i:300;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15215;}s:5:"large";a:5:{s:4:"file";s:40:"mae-mu-dEUyLofZe5o-unsplash-1024x819.jpg";s:5:"width";i:1024;s:6:"height";i:819;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:109681;}s:9:"thumbnail";a:5:{s:4:"file";s:39:"mae-mu-dEUyLofZe5o-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6940;}s:12:"medium_large";a:5:{s:4:"file";s:39:"mae-mu-dEUyLofZe5o-unsplash-768x614.jpg";s:5:"width";i:768;s:6:"height";i:614;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:67218;}s:9:"1536x1536";a:5:{s:4:"file";s:41:"mae-mu-dEUyLofZe5o-unsplash-1536x1229.jpg";s:5:"width";i:1536;s:6:"height";i:1229;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:222744;}s:9:"2048x2048";a:5:{s:4:"file";s:41:"mae-mu-dEUyLofZe5o-unsplash-2048x1639.jpg";s:5:"width";i:2048;s:6:"height";i:1639;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:368806;}s:12:"shop_catalog";a:6:{s:4:"file";s:46:"mae-mu-dEUyLofZe5o-unsplash-scaled-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6946;s:9:"uncropped";b:0;}s:11:"shop_single";a:5:{s:4:"file";s:46:"mae-mu-dEUyLofZe5o-unsplash-scaled-300x240.jpg";s:5:"width";i:300;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15228;}s:14:"shop_thumbnail";a:5:{s:4:"file";s:46:"mae-mu-dEUyLofZe5o-unsplash-scaled-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4196;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(381, 63, '_thumbnail_id', '67'),
(382, 62, '_price', '50.00'),
(383, 62, '_price', '100.00'),
(384, 68, 'homepage_slider_0_image', '67'),
(385, 68, '_homepage_slider_0_image', 'field_6293a522797d3'),
(386, 68, 'homepage_slider_0_name', 'Waffles'),
(387, 68, '_homepage_slider_0_name', 'field_6293a537797d4'),
(388, 68, 'homepage_slider_0_link', 'a:3:{s:5:"title";s:22:"Waffles ( Small Size )";s:3:"url";s:43:"http://localhost:8888/jtrc/product/waffles/";s:6:"target";s:0:"";}'),
(389, 68, '_homepage_slider_0_link', 'field_6293a53d797d5'),
(390, 68, 'homepage_slider_1_image', '17'),
(391, 68, '_homepage_slider_1_image', 'field_6293a522797d3'),
(392, 68, 'homepage_slider_1_name', 'Food Item Name'),
(393, 68, '_homepage_slider_1_name', 'field_6293a537797d4'),
(394, 68, 'homepage_slider_1_link', ''),
(395, 68, '_homepage_slider_1_link', 'field_6293a53d797d5'),
(396, 68, 'homepage_slider', '2'),
(397, 68, '_homepage_slider', 'field_6293a512797d2'),
(398, 69, '_edit_last', '1'),
(399, 69, '_edit_lock', '1653885572:1'),
(400, 70, '_wp_attached_file', '2022/05/scrambled-eggs-sq.webp'),
(401, 70, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1200;s:6:"height";i:1200;s:4:"file";s:30:"2022/05/scrambled-eggs-sq.webp";s:8:"filesize";i:115994;s:5:"sizes";a:10:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:30:"scrambled-eggs-sq-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:7304;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:30:"scrambled-eggs-sq-100x100.webp";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:4006;}s:18:"woocommerce_single";a:5:{s:4:"file";s:30:"scrambled-eggs-sq-300x300.webp";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:18354;}s:6:"medium";a:5:{s:4:"file";s:30:"scrambled-eggs-sq-300x300.webp";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:18354;}s:5:"large";a:5:{s:4:"file";s:32:"scrambled-eggs-sq-1024x1024.webp";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:88808;}s:9:"thumbnail";a:5:{s:4:"file";s:30:"scrambled-eggs-sq-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:7304;}s:12:"medium_large";a:5:{s:4:"file";s:30:"scrambled-eggs-sq-768x768.webp";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:61498;}s:12:"shop_catalog";a:6:{s:4:"file";s:30:"scrambled-eggs-sq-150x150.webp";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:7304;s:9:"uncropped";b:0;}s:11:"shop_single";a:5:{s:4:"file";s:30:"scrambled-eggs-sq-300x300.webp";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:18354;}s:14:"shop_thumbnail";a:5:{s:4:"file";s:30:"scrambled-eggs-sq-100x100.webp";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:4006;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(402, 71, 'homepage_slider_0_image', '67'),
(403, 71, '_homepage_slider_0_image', 'field_6293a522797d3'),
(404, 71, 'homepage_slider_0_name', 'Waffles'),
(405, 71, '_homepage_slider_0_name', 'field_6293a537797d4'),
(406, 71, 'homepage_slider_0_link', 'a:3:{s:5:"title";s:22:"Waffles ( Small Size )";s:3:"url";s:43:"http://localhost:8888/jtrc/product/waffles/";s:6:"target";s:0:"";}'),
(407, 71, '_homepage_slider_0_link', 'field_6293a53d797d5'),
(408, 71, 'homepage_slider_1_image', '70'),
(409, 71, '_homepage_slider_1_image', 'field_6293a522797d3'),
(410, 71, 'homepage_slider_1_name', 'Scrambled eggs'),
(411, 71, '_homepage_slider_1_name', 'field_6293a537797d4'),
(412, 71, 'homepage_slider_1_link', ''),
(413, 71, '_homepage_slider_1_link', 'field_6293a53d797d5'),
(414, 71, 'homepage_slider', '2'),
(415, 71, '_homepage_slider', 'field_6293a512797d2'),
(416, 69, '_regular_price', '40.00'),
(417, 69, 'total_sales', '0'),
(418, 69, '_tax_status', 'taxable'),
(419, 69, '_tax_class', ''),
(420, 69, '_manage_stock', 'no'),
(421, 69, '_backorders', 'no'),
(422, 69, '_sold_individually', 'no'),
(423, 69, '_virtual', 'no'),
(424, 69, '_downloadable', 'no'),
(425, 69, '_download_limit', '-1'),
(426, 69, '_download_expiry', '-1'),
(427, 69, '_stock', NULL),
(428, 69, '_stock_status', 'instock'),
(429, 69, '_wc_average_rating', '0'),
(430, 69, '_wc_review_count', '0'),
(431, 69, '_product_version', '6.5.1'),
(432, 69, '_price', '40.00'),
(433, 72, 'homepage_slider_0_image', '67'),
(434, 72, '_homepage_slider_0_image', 'field_6293a522797d3'),
(435, 72, 'homepage_slider_0_name', 'Waffles'),
(436, 72, '_homepage_slider_0_name', 'field_6293a537797d4'),
(437, 72, 'homepage_slider_0_link', 'a:3:{s:5:"title";s:22:"Waffles ( Small Size )";s:3:"url";s:43:"http://localhost:8888/jtrc/product/waffles/";s:6:"target";s:0:"";}'),
(438, 72, '_homepage_slider_0_link', 'field_6293a53d797d5'),
(439, 72, 'homepage_slider_1_image', '70'),
(440, 72, '_homepage_slider_1_image', 'field_6293a522797d3'),
(441, 72, 'homepage_slider_1_name', 'Scrambled Eggs'),
(442, 72, '_homepage_slider_1_name', 'field_6293a537797d4'),
(443, 72, 'homepage_slider_1_link', ''),
(444, 72, '_homepage_slider_1_link', 'field_6293a53d797d5'),
(445, 72, 'homepage_slider', '2'),
(446, 72, '_homepage_slider', 'field_6293a512797d2'),
(447, 73, 'homepage_slider_0_image', '67'),
(448, 73, '_homepage_slider_0_image', 'field_6293a522797d3'),
(449, 73, 'homepage_slider_0_name', 'Waffles'),
(450, 73, '_homepage_slider_0_name', 'field_6293a537797d4'),
(451, 73, 'homepage_slider_0_link', 'a:3:{s:5:"title";s:22:"Waffles ( Small Size )";s:3:"url";s:43:"http://localhost:8888/jtrc/product/waffles/";s:6:"target";s:0:"";}'),
(452, 73, '_homepage_slider_0_link', 'field_6293a53d797d5'),
(453, 73, 'homepage_slider_1_image', '70'),
(454, 73, '_homepage_slider_1_image', 'field_6293a522797d3') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(455, 73, 'homepage_slider_1_name', 'Scrambled Eggs'),
(456, 73, '_homepage_slider_1_name', 'field_6293a537797d4'),
(457, 73, 'homepage_slider_1_link', 'a:3:{s:5:"title";s:24:"Scrambled Eggs ( Small )";s:3:"url";s:56:"http://localhost:8888/jtrc/product/scrambled-eggs-small/";s:6:"target";s:0:"";}'),
(458, 73, '_homepage_slider_1_link', 'field_6293a53d797d5'),
(459, 73, 'homepage_slider', '2'),
(460, 73, '_homepage_slider', 'field_6293a512797d2'),
(461, 69, '_thumbnail_id', '70'),
(464, 7, 'featured_products', 'a:3:{i:0;s:2:"62";i:1;s:2:"69";i:2;s:2:"66";}'),
(465, 7, '_featured_products', 'field_62944b46814ca'),
(466, 76, 'homepage_slider_0_image', '67'),
(467, 76, '_homepage_slider_0_image', 'field_6293a522797d3'),
(468, 76, 'homepage_slider_0_name', 'Waffles'),
(469, 76, '_homepage_slider_0_name', 'field_6293a537797d4'),
(470, 76, 'homepage_slider_0_link', 'a:3:{s:5:"title";s:22:"Waffles ( Small Size )";s:3:"url";s:43:"http://localhost:8888/jtrc/product/waffles/";s:6:"target";s:0:"";}'),
(471, 76, '_homepage_slider_0_link', 'field_6293a53d797d5'),
(472, 76, 'homepage_slider_1_image', '70'),
(473, 76, '_homepage_slider_1_image', 'field_6293a522797d3'),
(474, 76, 'homepage_slider_1_name', 'Scrambled Eggs'),
(475, 76, '_homepage_slider_1_name', 'field_6293a537797d4'),
(476, 76, 'homepage_slider_1_link', 'a:3:{s:5:"title";s:24:"Scrambled Eggs ( Small )";s:3:"url";s:56:"http://localhost:8888/jtrc/product/scrambled-eggs-small/";s:6:"target";s:0:"";}'),
(477, 76, '_homepage_slider_1_link', 'field_6293a53d797d5'),
(478, 76, 'homepage_slider', '2'),
(479, 76, '_homepage_slider', 'field_6293a512797d2'),
(480, 76, 'featured_products', 'a:3:{i:0;s:2:"62";i:1;s:2:"69";i:2;s:2:"66";}'),
(481, 76, '_featured_products', 'field_62944b46814ca'),
(482, 77, '_menu_item_type', 'post_type'),
(483, 77, '_menu_item_menu_item_parent', '0'),
(484, 77, '_menu_item_object_id', '55'),
(485, 77, '_menu_item_object', 'page'),
(486, 77, '_menu_item_target', ''),
(487, 77, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(488, 77, '_menu_item_xfn', ''),
(489, 77, '_menu_item_url', ''),
(500, 79, '_menu_item_type', 'post_type'),
(501, 79, '_menu_item_menu_item_parent', '0'),
(502, 79, '_menu_item_object_id', '31'),
(503, 79, '_menu_item_object', 'page'),
(504, 79, '_menu_item_target', ''),
(505, 79, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(506, 79, '_menu_item_xfn', ''),
(507, 79, '_menu_item_url', ''),
(509, 36, '_wp_old_date', '2022-05-29'),
(516, 83, '_edit_last', '1'),
(517, 83, '_edit_lock', '1661695463:1'),
(518, 7, 'featured_breakfast_items', 'a:2:{i:0;s:2:"66";i:1;s:2:"63";}'),
(519, 7, '_featured_breakfast_items', 'field_62d06c020cdae'),
(520, 85, 'homepage_slider_0_image', '67'),
(521, 85, '_homepage_slider_0_image', 'field_6293a522797d3'),
(522, 85, 'homepage_slider_0_name', 'Waffles'),
(523, 85, '_homepage_slider_0_name', 'field_6293a537797d4'),
(524, 85, 'homepage_slider_0_link', 'a:3:{s:5:"title";s:22:"Waffles ( Small Size )";s:3:"url";s:38:"//localhost:3000/jtrc/product/waffles/";s:6:"target";s:0:"";}'),
(525, 85, '_homepage_slider_0_link', 'field_6293a53d797d5'),
(526, 85, 'homepage_slider_1_image', '70'),
(527, 85, '_homepage_slider_1_image', 'field_6293a522797d3'),
(528, 85, 'homepage_slider_1_name', 'Scrambled Eggs'),
(529, 85, '_homepage_slider_1_name', 'field_6293a537797d4'),
(530, 85, 'homepage_slider_1_link', 'a:3:{s:5:"title";s:24:"Scrambled Eggs ( Small )";s:3:"url";s:51:"//localhost:3000/jtrc/product/scrambled-eggs-small/";s:6:"target";s:0:"";}'),
(531, 85, '_homepage_slider_1_link', 'field_6293a53d797d5'),
(532, 85, 'homepage_slider', '2'),
(533, 85, '_homepage_slider', 'field_6293a512797d2'),
(534, 85, 'featured_products', 'a:3:{i:0;s:2:"62";i:1;s:2:"69";i:2;s:2:"66";}'),
(535, 85, '_featured_products', 'field_62944b46814ca'),
(536, 85, 'featured_breakfast_items', 'a:2:{i:0;s:2:"66";i:1;s:2:"63";}'),
(537, 85, '_featured_breakfast_items', 'field_62d06c020cdae'),
(538, 7, 'featured_breakfast_packages', 'a:1:{i:0;s:2:"62";}'),
(539, 7, '_featured_breakfast_packages', 'field_62d071a998c70'),
(540, 87, 'homepage_slider_0_image', '67'),
(541, 87, '_homepage_slider_0_image', 'field_6293a522797d3'),
(542, 87, 'homepage_slider_0_name', 'Waffles'),
(543, 87, '_homepage_slider_0_name', 'field_6293a537797d4'),
(544, 87, 'homepage_slider_0_link', 'a:3:{s:5:"title";s:22:"Waffles ( Small Size )";s:3:"url";s:38:"//localhost:3000/jtrc/product/waffles/";s:6:"target";s:0:"";}'),
(545, 87, '_homepage_slider_0_link', 'field_6293a53d797d5'),
(546, 87, 'homepage_slider_1_image', '70'),
(547, 87, '_homepage_slider_1_image', 'field_6293a522797d3'),
(548, 87, 'homepage_slider_1_name', 'Scrambled Eggs'),
(549, 87, '_homepage_slider_1_name', 'field_6293a537797d4'),
(550, 87, 'homepage_slider_1_link', 'a:3:{s:5:"title";s:24:"Scrambled Eggs ( Small )";s:3:"url";s:51:"//localhost:3000/jtrc/product/scrambled-eggs-small/";s:6:"target";s:0:"";}'),
(551, 87, '_homepage_slider_1_link', 'field_6293a53d797d5'),
(552, 87, 'homepage_slider', '2'),
(553, 87, '_homepage_slider', 'field_6293a512797d2'),
(554, 87, 'featured_products', 'a:3:{i:0;s:2:"62";i:1;s:2:"69";i:2;s:2:"66";}'),
(555, 87, '_featured_products', 'field_62944b46814ca'),
(556, 87, 'featured_breakfast_items', 'a:2:{i:0;s:2:"66";i:1;s:2:"63";}'),
(557, 87, '_featured_breakfast_items', 'field_62d06c020cdae'),
(558, 87, 'featured_breakfast_packages', 'a:1:{i:0;s:2:"62";}'),
(559, 87, '_featured_breakfast_packages', 'field_62d071a998c70'),
(560, 88, '_wp_attached_file', '2022/05/brooke-lark-aGjP08-HbYY-unsplash-scaled.jpg'),
(561, 88, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:51:"2022/05/brooke-lark-aGjP08-HbYY-unsplash-scaled.jpg";s:8:"filesize";i:753333;s:5:"sizes";a:12:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:51:"brooke-lark-aGjP08-HbYY-unsplash-scaled-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:27442;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:51:"brooke-lark-aGjP08-HbYY-unsplash-scaled-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4740;}s:18:"woocommerce_single";a:5:{s:4:"file";s:51:"brooke-lark-aGjP08-HbYY-unsplash-scaled-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20060;}s:6:"medium";a:5:{s:4:"file";s:44:"brooke-lark-aGjP08-HbYY-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20136;}s:5:"large";a:5:{s:4:"file";s:45:"brooke-lark-aGjP08-HbYY-unsplash-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:165909;}s:9:"thumbnail";a:5:{s:4:"file";s:44:"brooke-lark-aGjP08-HbYY-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8632;}s:12:"medium_large";a:5:{s:4:"file";s:44:"brooke-lark-aGjP08-HbYY-unsplash-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:100904;}s:9:"1536x1536";a:5:{s:4:"file";s:46:"brooke-lark-aGjP08-HbYY-unsplash-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:326745;}s:9:"2048x2048";a:5:{s:4:"file";s:46:"brooke-lark-aGjP08-HbYY-unsplash-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:524972;}s:12:"shop_catalog";a:6:{s:4:"file";s:51:"brooke-lark-aGjP08-HbYY-unsplash-scaled-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8624;s:9:"uncropped";b:0;}s:11:"shop_single";a:5:{s:4:"file";s:51:"brooke-lark-aGjP08-HbYY-unsplash-scaled-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20060;}s:14:"shop_thumbnail";a:5:{s:4:"file";s:51:"brooke-lark-aGjP08-HbYY-unsplash-scaled-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4740;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(562, 62, '_thumbnail_id', '88'),
(563, 89, '_wp_attached_file', '2022/05/erion-dalti-S8Aroj0Y4TA-unsplash-scaled.jpg'),
(564, 89, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2560;s:6:"height";i:2553;s:4:"file";s:51:"2022/05/erion-dalti-S8Aroj0Y4TA-unsplash-scaled.jpg";s:8:"filesize";i:1005056;s:5:"sizes";a:12:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:51:"erion-dalti-S8Aroj0Y4TA-unsplash-scaled-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7522;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:51:"erion-dalti-S8Aroj0Y4TA-unsplash-scaled-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4286;}s:18:"woocommerce_single";a:5:{s:4:"file";s:51:"erion-dalti-S8Aroj0Y4TA-unsplash-scaled-300x299.jpg";s:5:"width";i:300;s:6:"height";i:299;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22001;}s:6:"medium";a:5:{s:4:"file";s:44:"erion-dalti-S8Aroj0Y4TA-unsplash-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22017;}s:5:"large";a:5:{s:4:"file";s:46:"erion-dalti-S8Aroj0Y4TA-unsplash-1024x1021.jpg";s:5:"width";i:1024;s:6:"height";i:1021;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:184321;}s:9:"thumbnail";a:5:{s:4:"file";s:44:"erion-dalti-S8Aroj0Y4TA-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7531;}s:12:"medium_large";a:5:{s:4:"file";s:44:"erion-dalti-S8Aroj0Y4TA-unsplash-768x766.jpg";s:5:"width";i:768;s:6:"height";i:766;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:108644;}s:9:"1536x1536";a:5:{s:4:"file";s:46:"erion-dalti-S8Aroj0Y4TA-unsplash-1536x1532.jpg";s:5:"width";i:1536;s:6:"height";i:1532;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:396194;}s:9:"2048x2048";a:5:{s:4:"file";s:46:"erion-dalti-S8Aroj0Y4TA-unsplash-2048x2042.jpg";s:5:"width";i:2048;s:6:"height";i:2042;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:675130;}s:12:"shop_catalog";a:6:{s:4:"file";s:51:"erion-dalti-S8Aroj0Y4TA-unsplash-scaled-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7522;s:9:"uncropped";b:0;}s:11:"shop_single";a:5:{s:4:"file";s:51:"erion-dalti-S8Aroj0Y4TA-unsplash-scaled-300x299.jpg";s:5:"width";i:300;s:6:"height";i:299;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22001;}s:14:"shop_thumbnail";a:5:{s:4:"file";s:51:"erion-dalti-S8Aroj0Y4TA-unsplash-scaled-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4286;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(565, 66, '_thumbnail_id', '89'),
(566, 90, '_wp_attached_file', '2022/07/jtrc_logo.png'),
(567, 90, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:4167;s:6:"height";i:4167;s:4:"file";s:21:"2022/07/jtrc_logo.png";s:8:"filesize";i:1992473;s:5:"sizes";a:12:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:21:"jtrc_logo-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14029;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:21:"jtrc_logo-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:7760;}s:18:"woocommerce_single";a:5:{s:4:"file";s:21:"jtrc_logo-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:36732;}s:6:"medium";a:5:{s:4:"file";s:21:"jtrc_logo-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:36732;}s:5:"large";a:5:{s:4:"file";s:23:"jtrc_logo-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:183646;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"jtrc_logo-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14029;}s:12:"medium_large";a:5:{s:4:"file";s:21:"jtrc_logo-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:123663;}s:9:"1536x1536";a:5:{s:4:"file";s:23:"jtrc_logo-1536x1536.png";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:328333;}s:9:"2048x2048";a:5:{s:4:"file";s:23:"jtrc_logo-2048x2048.png";s:5:"width";i:2048;s:6:"height";i:2048;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:502557;}s:12:"shop_catalog";a:6:{s:4:"file";s:21:"jtrc_logo-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14029;s:9:"uncropped";b:0;}s:11:"shop_single";a:5:{s:4:"file";s:21:"jtrc_logo-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:36732;}s:14:"shop_thumbnail";a:5:{s:4:"file";s:21:"jtrc_logo-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:7760;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(575, 96, '_edit_last', '1'),
(576, 96, '_edit_lock', '1658260291:1'),
(577, 96, 'total_sales', '0'),
(578, 96, '_tax_status', 'taxable'),
(579, 96, '_tax_class', ''),
(580, 96, '_manage_stock', 'no') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(581, 96, '_backorders', 'no'),
(582, 96, '_sold_individually', 'no'),
(583, 96, '_virtual', 'no'),
(584, 96, '_downloadable', 'no'),
(585, 96, '_download_limit', '-1'),
(586, 96, '_download_expiry', '-1'),
(587, 96, '_stock', NULL),
(588, 96, '_stock_status', 'outofstock'),
(589, 96, '_wc_average_rating', '0'),
(590, 96, '_wc_review_count', '0'),
(591, 96, '_product_attributes', 'a:1:{s:8:"quantity";a:6:{s:4:"name";s:8:"Quantity";s:5:"value";s:7:"20 | 40";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:0;}}'),
(592, 96, '_product_version', '6.7.0'),
(627, 99, '_wp_attached_file', '2022/07/tabitha-turner-Ns2aJ5OXKds-unsplash-scaled.jpg'),
(628, 99, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1920;s:4:"file";s:54:"2022/07/tabitha-turner-Ns2aJ5OXKds-unsplash-scaled.jpg";s:8:"filesize";i:1019433;s:5:"sizes";a:12:{s:6:"medium";a:5:{s:4:"file";s:47:"tabitha-turner-Ns2aJ5OXKds-unsplash-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20486;}s:5:"large";a:5:{s:4:"file";s:48:"tabitha-turner-Ns2aJ5OXKds-unsplash-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:186320;}s:9:"thumbnail";a:5:{s:4:"file";s:47:"tabitha-turner-Ns2aJ5OXKds-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8212;}s:12:"medium_large";a:5:{s:4:"file";s:47:"tabitha-turner-Ns2aJ5OXKds-unsplash-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:109830;}s:9:"1536x1536";a:5:{s:4:"file";s:49:"tabitha-turner-Ns2aJ5OXKds-unsplash-1536x1152.jpg";s:5:"width";i:1536;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:387579;}s:9:"2048x2048";a:5:{s:4:"file";s:49:"tabitha-turner-Ns2aJ5OXKds-unsplash-2048x1536.jpg";s:5:"width";i:2048;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:658388;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:54:"tabitha-turner-Ns2aJ5OXKds-unsplash-scaled-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:26699;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:47:"tabitha-turner-Ns2aJ5OXKds-unsplash-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20486;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:47:"tabitha-turner-Ns2aJ5OXKds-unsplash-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4472;}s:12:"shop_catalog";a:5:{s:4:"file";s:47:"tabitha-turner-Ns2aJ5OXKds-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8212;}s:11:"shop_single";a:5:{s:4:"file";s:47:"tabitha-turner-Ns2aJ5OXKds-unsplash-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20486;}s:14:"shop_thumbnail";a:5:{s:4:"file";s:47:"tabitha-turner-Ns2aJ5OXKds-unsplash-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4472;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:39:"tabitha-turner-Ns2aJ5OXKds-unsplash.jpg";}'),
(629, 96, '_thumbnail_id', '99'),
(630, 7, 'featured_appetizers_package', 'a:1:{i:0;s:2:"96";}'),
(631, 7, '_featured_appetizers_package', 'field_62d6def8e06e8'),
(632, 7, 'featured_appetizers_items', 'a:2:{i:0;s:2:"96";i:1;s:2:"69";}'),
(633, 7, '_featured_appetizers_items', 'field_62d6e132e06e9'),
(634, 100, 'homepage_slider_0_image', '67'),
(635, 100, '_homepage_slider_0_image', 'field_6293a522797d3'),
(636, 100, 'homepage_slider_0_name', 'Waffles'),
(637, 100, '_homepage_slider_0_name', 'field_6293a537797d4'),
(638, 100, 'homepage_slider_0_link', 'a:3:{s:5:"title";s:22:"Waffles ( Small Size )";s:3:"url";s:38:"//localhost:3000/jtrc/product/waffles/";s:6:"target";s:0:"";}'),
(639, 100, '_homepage_slider_0_link', 'field_6293a53d797d5'),
(640, 100, 'homepage_slider_1_image', '70'),
(641, 100, '_homepage_slider_1_image', 'field_6293a522797d3'),
(642, 100, 'homepage_slider_1_name', 'Scrambled Eggs'),
(643, 100, '_homepage_slider_1_name', 'field_6293a537797d4'),
(644, 100, 'homepage_slider_1_link', 'a:3:{s:5:"title";s:24:"Scrambled Eggs ( Small )";s:3:"url";s:51:"//localhost:3000/jtrc/product/scrambled-eggs-small/";s:6:"target";s:0:"";}'),
(645, 100, '_homepage_slider_1_link', 'field_6293a53d797d5'),
(646, 100, 'homepage_slider', '2'),
(647, 100, '_homepage_slider', 'field_6293a512797d2'),
(648, 100, 'featured_products', 'a:3:{i:0;s:2:"62";i:1;s:2:"69";i:2;s:2:"66";}'),
(649, 100, '_featured_products', 'field_62944b46814ca'),
(650, 100, 'featured_breakfast_items', 'a:2:{i:0;s:2:"66";i:1;s:2:"63";}'),
(651, 100, '_featured_breakfast_items', 'field_62d06c020cdae'),
(652, 100, 'featured_breakfast_packages', 'a:1:{i:0;s:2:"62";}'),
(653, 100, '_featured_breakfast_packages', 'field_62d071a998c70'),
(654, 100, 'featured_appetizers_package', 'a:1:{i:0;s:2:"96";}'),
(655, 100, '_featured_appetizers_package', 'field_62d6def8e06e8'),
(656, 100, 'featured_appetizers_items', 'a:2:{i:0;s:2:"96";i:1;s:2:"69";}'),
(657, 100, '_featured_appetizers_items', 'field_62d6e132e06e9'),
(658, 96, '_regular_price', '100.00'),
(659, 96, '_price', '100.00'),
(660, 55, '_wp_page_template', 'default'),
(661, 101, '_edit_last', '1'),
(662, 101, '_edit_lock', '1664311039:1'),
(663, 103, '_wp_attached_file', '2022/07/image0.jpeg'),
(664, 103, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1282;s:6:"height";i:1270;s:4:"file";s:19:"2022/07/image0.jpeg";s:8:"filesize";i:198837;s:5:"sizes";a:10:{s:6:"medium";a:5:{s:4:"file";s:19:"image0-300x297.jpeg";s:5:"width";i:300;s:6:"height";i:297;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12803;}s:5:"large";a:5:{s:4:"file";s:21:"image0-1024x1014.jpeg";s:5:"width";i:1024;s:6:"height";i:1014;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:71837;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"image0-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5459;}s:12:"medium_large";a:5:{s:4:"file";s:19:"image0-768x761.jpeg";s:5:"width";i:768;s:6:"height";i:761;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:47543;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:19:"image0-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13076;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:19:"image0-300x297.jpeg";s:5:"width";i:300;s:6:"height";i:297;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12803;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:19:"image0-100x100.jpeg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3643;}s:12:"shop_catalog";a:5:{s:4:"file";s:19:"image0-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5459;}s:11:"shop_single";a:5:{s:4:"file";s:19:"image0-300x297.jpeg";s:5:"width";i:300;s:6:"height";i:297;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12803;}s:14:"shop_thumbnail";a:5:{s:4:"file";s:19:"image0-100x100.jpeg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3643;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1658250400";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(665, 55, '_edit_last', '1'),
(666, 55, 'profile_image', '103'),
(667, 55, '_profile_image', 'field_62d71babcd1c0'),
(668, 104, 'profile_image', '103'),
(669, 104, '_profile_image', 'field_62d71babcd1c0'),
(670, 105, 'profile_image', '103'),
(671, 105, '_profile_image', 'field_62d71babcd1c0'),
(672, 106, '_edit_lock', '1658265870:1'),
(673, 108, '_edit_lock', '1658288955:1'),
(683, 111, '_menu_item_type', 'post_type'),
(684, 111, '_menu_item_menu_item_parent', '0'),
(685, 111, '_menu_item_object_id', '108'),
(686, 111, '_menu_item_object', 'page'),
(687, 111, '_menu_item_target', ''),
(688, 111, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(689, 111, '_menu_item_xfn', ''),
(690, 111, '_menu_item_url', ''),
(691, 113, '_edit_last', '1'),
(692, 113, '_edit_lock', '1661640869:1'),
(693, 62, 'serving_size', '20'),
(694, 62, '_serving_size', 'field_630aa10db0892'),
(695, 62, '_wc_rating_count', 'a:1:{i:5;i:1;}'),
(696, 115, '_edit_lock', '1661649281:1'),
(697, 117, '_menu_item_type', 'post_type'),
(698, 117, '_menu_item_menu_item_parent', '0'),
(699, 117, '_menu_item_object_id', '115'),
(700, 117, '_menu_item_object', 'page'),
(701, 117, '_menu_item_target', ''),
(702, 117, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(703, 117, '_menu_item_xfn', ''),
(704, 117, '_menu_item_url', ''),
(706, 118, '_menu_item_type', 'post_type'),
(707, 118, '_menu_item_menu_item_parent', '0'),
(708, 118, '_menu_item_object_id', '106'),
(709, 118, '_menu_item_object', 'page'),
(710, 118, '_menu_item_target', ''),
(711, 118, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(712, 118, '_menu_item_xfn', ''),
(713, 118, '_menu_item_url', ''),
(715, 36, '_wp_old_date', '2022-05-30'),
(716, 77, '_wp_old_date', '2022-05-30'),
(717, 79, '_wp_old_date', '2022-05-30'),
(721, 120, '_menu_item_type', 'post_type'),
(722, 120, '_menu_item_menu_item_parent', '0'),
(723, 120, '_menu_item_object_id', '55'),
(724, 120, '_menu_item_object', 'page'),
(725, 120, '_menu_item_target', ''),
(726, 120, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(727, 120, '_menu_item_xfn', ''),
(728, 120, '_menu_item_url', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(730, 121, '_menu_item_type', 'post_type'),
(731, 121, '_menu_item_menu_item_parent', '0'),
(732, 121, '_menu_item_object_id', '106'),
(733, 121, '_menu_item_object', 'page'),
(734, 121, '_menu_item_target', ''),
(735, 121, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(736, 121, '_menu_item_xfn', ''),
(737, 121, '_menu_item_url', ''),
(739, 111, '_wp_old_date', '2022-07-20'),
(740, 122, '_edit_last', '1'),
(741, 122, '_edit_lock', '1661666106:1'),
(742, 130, '_wp_attached_file', '2022/08/doordash-logo.svg'),
(743, 130, '_wp_attachment_metadata', 'a:4:{s:5:"width";i:2500;s:6:"height";i:292;s:4:"file";s:17:"doordash-logo.svg";s:5:"sizes";a:12:{s:9:"thumbnail";a:5:{s:5:"width";s:3:"150";s:6:"height";d:18;s:4:"crop";b:0;s:4:"file";s:17:"doordash-logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:6:"medium";a:5:{s:5:"width";s:3:"300";s:6:"height";d:35;s:4:"crop";b:0;s:4:"file";s:17:"doordash-logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:12:"medium_large";a:5:{s:5:"width";s:3:"768";s:6:"height";d:90;s:4:"crop";b:0;s:4:"file";s:17:"doordash-logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:5:"large";a:5:{s:5:"width";s:4:"1024";s:6:"height";d:120;s:4:"crop";b:0;s:4:"file";s:17:"doordash-logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:9:"1536x1536";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:17:"doordash-logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:9:"2048x2048";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:17:"doordash-logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:21:"woocommerce_thumbnail";a:6:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:17:"doordash-logo.svg";s:9:"mime-type";s:13:"image/svg+xml";s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:17:"doordash-logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:29:"woocommerce_gallery_thumbnail";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:17:"doordash-logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:12:"shop_catalog";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:17:"doordash-logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:11:"shop_single";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:17:"doordash-logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:14:"shop_thumbnail";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:17:"doordash-logo.svg";s:9:"mime-type";s:13:"image/svg+xml";}}}'),
(744, 131, '_wp_attached_file', '2022/08/grubhub-1.svg'),
(745, 131, '_wp_attachment_metadata', 'a:4:{s:5:"width";i:2500;s:6:"height";i:525;s:4:"file";s:13:"grubhub-1.svg";s:5:"sizes";a:12:{s:9:"thumbnail";a:5:{s:5:"width";s:3:"150";s:6:"height";d:32;s:4:"crop";b:0;s:4:"file";s:13:"grubhub-1.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:6:"medium";a:5:{s:5:"width";s:3:"300";s:6:"height";d:63;s:4:"crop";b:0;s:4:"file";s:13:"grubhub-1.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:12:"medium_large";a:5:{s:5:"width";s:3:"768";s:6:"height";d:161;s:4:"crop";b:0;s:4:"file";s:13:"grubhub-1.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:5:"large";a:5:{s:5:"width";s:4:"1024";s:6:"height";d:215;s:4:"crop";b:0;s:4:"file";s:13:"grubhub-1.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:9:"1536x1536";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"grubhub-1.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:9:"2048x2048";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"grubhub-1.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:21:"woocommerce_thumbnail";a:6:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"grubhub-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"grubhub-1.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:29:"woocommerce_gallery_thumbnail";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"grubhub-1.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:12:"shop_catalog";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"grubhub-1.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:11:"shop_single";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"grubhub-1.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:14:"shop_thumbnail";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"grubhub-1.svg";s:9:"mime-type";s:13:"image/svg+xml";}}}'),
(746, 132, '_wp_attached_file', '2022/08/uber-eats.svg'),
(747, 132, '_wp_attachment_metadata', 'a:4:{s:5:"width";i:2500;s:6:"height";i:408;s:4:"file";s:13:"uber-eats.svg";s:5:"sizes";a:12:{s:9:"thumbnail";a:5:{s:5:"width";s:3:"150";s:6:"height";d:24;s:4:"crop";b:0;s:4:"file";s:13:"uber-eats.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:6:"medium";a:5:{s:5:"width";s:3:"300";s:6:"height";d:49;s:4:"crop";b:0;s:4:"file";s:13:"uber-eats.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:12:"medium_large";a:5:{s:5:"width";s:3:"768";s:6:"height";d:125;s:4:"crop";b:0;s:4:"file";s:13:"uber-eats.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:5:"large";a:5:{s:5:"width";s:4:"1024";s:6:"height";d:167;s:4:"crop";b:0;s:4:"file";s:13:"uber-eats.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:9:"1536x1536";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"uber-eats.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:9:"2048x2048";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"uber-eats.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:21:"woocommerce_thumbnail";a:6:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"uber-eats.svg";s:9:"mime-type";s:13:"image/svg+xml";s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"uber-eats.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:29:"woocommerce_gallery_thumbnail";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"uber-eats.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:12:"shop_catalog";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"uber-eats.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:11:"shop_single";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"uber-eats.svg";s:9:"mime-type";s:13:"image/svg+xml";}s:14:"shop_thumbnail";a:5:{s:5:"width";b:0;s:6:"height";d:0;s:4:"crop";b:0;s:4:"file";s:13:"uber-eats.svg";s:9:"mime-type";s:13:"image/svg+xml";}}}'),
(748, 135, '_edit_last', '1'),
(749, 135, '_edit_lock', '1661663383:1'),
(750, 55, 'image', '147'),
(751, 55, '_image', 'field_62d71babcd1c0'),
(752, 143, 'profile_image', '103'),
(753, 143, '_profile_image', 'field_62d71babcd1c0'),
(754, 143, 'image', '103'),
(755, 143, '_image', 'field_62d71babcd1c0'),
(756, 55, 'content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(757, 55, '_content', 'field_63334f6784972'),
(758, 146, 'profile_image', '103'),
(759, 146, '_profile_image', 'field_62d71babcd1c0'),
(760, 146, 'image', '103'),
(761, 146, '_image', 'field_62d71babcd1c0'),
(762, 146, 'content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(763, 146, '_content', 'field_63334f6784972'),
(764, 147, '_wp_attached_file', '2022/09/johnathan-macedo-4NQEvxW2_4w-unsplash-scaled.jpg'),
(765, 147, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:56:"2022/09/johnathan-macedo-4NQEvxW2_4w-unsplash-scaled.jpg";s:8:"filesize";i:450246;s:5:"sizes";a:12:{s:6:"medium";a:5:{s:4:"file";s:49:"johnathan-macedo-4NQEvxW2_4w-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16605;}s:5:"large";a:5:{s:4:"file";s:50:"johnathan-macedo-4NQEvxW2_4w-unsplash-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:104682;}s:9:"thumbnail";a:5:{s:4:"file";s:49:"johnathan-macedo-4NQEvxW2_4w-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7459;}s:12:"medium_large";a:5:{s:4:"file";s:49:"johnathan-macedo-4NQEvxW2_4w-unsplash-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:67964;}s:9:"1536x1536";a:5:{s:4:"file";s:51:"johnathan-macedo-4NQEvxW2_4w-unsplash-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:192686;}s:9:"2048x2048";a:5:{s:4:"file";s:51:"johnathan-macedo-4NQEvxW2_4w-unsplash-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:305738;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:49:"johnathan-macedo-4NQEvxW2_4w-unsplash-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20600;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:49:"johnathan-macedo-4NQEvxW2_4w-unsplash-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:47017;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:49:"johnathan-macedo-4NQEvxW2_4w-unsplash-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4340;}s:12:"shop_catalog";a:5:{s:4:"file";s:49:"johnathan-macedo-4NQEvxW2_4w-unsplash-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20600;}s:11:"shop_single";a:5:{s:4:"file";s:49:"johnathan-macedo-4NQEvxW2_4w-unsplash-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:47017;}s:14:"shop_thumbnail";a:5:{s:4:"file";s:49:"johnathan-macedo-4NQEvxW2_4w-unsplash-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4340;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:41:"johnathan-macedo-4NQEvxW2_4w-unsplash.jpg";}'),
(766, 148, 'profile_image', '103'),
(767, 148, '_profile_image', 'field_62d71babcd1c0'),
(768, 148, 'image', '147'),
(769, 148, '_image', 'field_62d71babcd1c0'),
(770, 148, 'content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(771, 148, '_content', 'field_63334f6784972'),
(772, 55, 'title', 'Our Story'),
(773, 55, '_title', 'field_633358419377d'),
(774, 150, 'profile_image', '103'),
(775, 150, '_profile_image', 'field_62d71babcd1c0'),
(776, 150, 'image', '147'),
(777, 150, '_image', 'field_62d71babcd1c0'),
(778, 150, 'content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(779, 150, '_content', 'field_63334f6784972'),
(780, 150, 'title', 'Our Story'),
(781, 150, '_title', 'field_633358419377d'),
(782, 152, '_wp_attached_file', '2022/09/signature.png'),
(783, 152, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:500;s:6:"height";i:150;s:4:"file";s:21:"2022/09/signature.png";s:8:"filesize";i:8273;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:20:"signature-300x90.png";s:5:"width";i:300;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2722;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"signature-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2535;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:21:"signature-300x150.png";s:5:"width";i:300;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3646;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:21:"signature-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2095;}s:12:"shop_catalog";a:5:{s:4:"file";s:21:"signature-300x150.png";s:5:"width";i:300;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3646;}s:14:"shop_thumbnail";a:5:{s:4:"file";s:21:"signature-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2095;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(784, 55, 'signature', '152'),
(785, 55, '_signature', 'field_63335f76f0086'),
(786, 153, 'profile_image', '103'),
(787, 153, '_profile_image', 'field_62d71babcd1c0'),
(788, 153, 'image', '147'),
(789, 153, '_image', 'field_62d71babcd1c0'),
(790, 153, 'content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(791, 153, '_content', 'field_63334f6784972'),
(792, 153, 'title', 'Our Story'),
(793, 153, '_title', 'field_633358419377d'),
(794, 153, 'signature', '152'),
(795, 153, '_signature', 'field_63335f76f0086') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-05-18 16:16:31', '2022-05-18 16:16:31', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2022-05-18 16:16:31', '2022-05-18 16:16:31', '', 0, 'http://localhost:8888/jtrc/?p=1', 0, 'post', '', 1),
(2, 1, '2022-05-18 16:16:31', '2022-05-18 16:16:31', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost:8888/jtrc/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2022-05-18 16:16:31', '2022-05-18 16:16:31', '', 0, 'http://localhost:8888/jtrc/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-05-18 16:16:31', '2022-05-18 16:16:31', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost:8888/jtrc.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2022-05-18 16:16:31', '2022-05-18 16:16:31', '', 0, 'http://localhost:8888/jtrc/?page_id=3', 0, 'page', '', 0),
(7, 1, '2022-05-29 16:52:55', '2022-05-29 16:52:55', '', 'Homepage', '', 'publish', 'closed', 'closed', '', 'homepage', '', '', '2022-07-19 19:51:56', '2022-07-19 19:51:56', '', 0, 'http://localhost:8888/jtrc/?page_id=7', 0, 'page', '', 0),
(8, 1, '2022-05-29 16:52:42', '2022-05-29 16:52:42', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-jtrc', '', '', '2022-05-29 16:52:42', '2022-05-29 16:52:42', '', 0, 'http://localhost:8888/jtrc/2022/05/29/wp-global-styles-jtrc/', 0, 'wp_global_styles', '', 0),
(9, 1, '2022-05-29 16:52:55', '2022-05-29 16:52:55', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-05-29 16:52:55', '2022-05-29 16:52:55', '', 7, 'http://localhost:8888/jtrc/?p=9', 0, 'revision', '', 0),
(10, 1, '2022-05-29 16:54:50', '2022-05-29 16:54:50', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:1:"7";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Slideshow', 'slideshow', 'publish', 'closed', 'closed', '', 'group_6293a4f74877f', '', '', '2022-05-29 16:54:50', '2022-05-29 16:54:50', '', 0, 'http://localhost:8888/jtrc/?post_type=acf-field-group&#038;p=10', 0, 'acf-field-group', '', 0),
(11, 1, '2022-05-29 16:54:50', '2022-05-29 16:54:50', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Homepage Slider', 'homepage_slider', 'publish', 'closed', 'closed', '', 'field_6293a512797d2', '', '', '2022-05-29 16:54:50', '2022-05-29 16:54:50', '', 10, 'http://localhost:8888/jtrc/?post_type=acf-field&p=11', 0, 'acf-field', '', 0),
(12, 1, '2022-05-29 16:54:50', '2022-05-29 16:54:50', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_6293a522797d3', '', '', '2022-05-29 16:54:50', '2022-05-29 16:54:50', '', 11, 'http://localhost:8888/jtrc/?post_type=acf-field&p=12', 0, 'acf-field', '', 0),
(13, 1, '2022-05-29 16:54:50', '2022-05-29 16:54:50', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'name', 'publish', 'closed', 'closed', '', 'field_6293a537797d4', '', '', '2022-05-29 16:54:50', '2022-05-29 16:54:50', '', 11, 'http://localhost:8888/jtrc/?post_type=acf-field&p=13', 1, 'acf-field', '', 0),
(14, 1, '2022-05-29 16:54:50', '2022-05-29 16:54:50', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_6293a53d797d5', '', '', '2022-05-29 16:54:50', '2022-05-29 16:54:50', '', 11, 'http://localhost:8888/jtrc/?post_type=acf-field&p=14', 2, 'acf-field', '', 0),
(15, 1, '2022-05-29 16:56:24', '2022-05-29 16:56:24', '', 'brooke-lark-08bOYnH_r_E-unsplash', '', 'inherit', 'open', 'closed', '', 'brooke-lark-08boynh_r_e-unsplash', '', '', '2022-05-29 16:56:24', '2022-05-29 16:56:24', '', 7, 'http://localhost:8888/jtrc/wp-content/uploads/2022/05/brooke-lark-08bOYnH_r_E-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(16, 1, '2022-05-29 16:56:33', '2022-05-29 16:56:33', '', 'food-13549', '', 'inherit', 'open', 'closed', '', 'food-13549', '', '', '2022-05-29 16:56:33', '2022-05-29 16:56:33', '', 7, 'http://localhost:8888/jtrc/wp-content/uploads/2022/05/food-13549.png', 0, 'attachment', 'image/png', 0),
(17, 1, '2022-05-29 16:56:35', '2022-05-29 16:56:35', '', 'lily-banse--YHSwy6uqvk-unsplash', '', 'inherit', 'open', 'closed', '', 'lily-banse-yhswy6uqvk-unsplash', '', '', '2022-05-29 16:56:35', '2022-05-29 16:56:35', '', 7, 'http://localhost:8888/jtrc/wp-content/uploads/2022/05/lily-banse-YHSwy6uqvk-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2022-05-29 16:56:55', '2022-05-29 16:56:55', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-05-29 16:56:55', '2022-05-29 16:56:55', '', 7, 'http://localhost:8888/jtrc/?p=18', 0, 'revision', '', 0),
(21, 1, '2022-05-29 17:38:13', '2022-05-29 17:38:13', '', 'Menu', '', 'publish', 'closed', 'closed', '', 'menu', '', '', '2022-05-29 21:08:27', '2022-05-29 21:08:27', '', 0, 'http://localhost:8888/jtrc/?page_id=21', 0, 'page', '', 0),
(22, 1, '2022-05-29 17:38:13', '2022-05-29 17:38:13', '', 'Menu', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2022-05-29 17:38:13', '2022-05-29 17:38:13', '', 21, 'http://localhost:8888/jtrc/?p=22', 0, 'revision', '', 0),
(23, 1, '2022-05-29 19:48:30', '2022-05-29 19:48:30', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"21";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Pages: Menu', 'pages-menu', 'publish', 'closed', 'closed', '', 'group_6293cd34661a5', '', '', '2022-05-29 21:03:02', '2022-05-29 21:03:02', '', 0, 'http://localhost:8888/jtrc/?post_type=acf-field-group&#038;p=23', 0, 'acf-field-group', '', 0),
(24, 1, '2022-05-29 19:48:30', '2022-05-29 19:48:30', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Breakfast/Brunch', 'breakfast_items', 'publish', 'closed', 'closed', '', 'field_6293cd42889c2', '', '', '2022-05-29 20:12:29', '2022-05-29 20:12:29', '', 23, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=24', 2, 'acf-field', '', 0),
(25, 1, '2022-05-29 19:48:30', '2022-05-29 19:48:30', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Menu Item Name', 'menu_item_name', 'publish', 'closed', 'closed', '', 'field_6293cd9b889c3', '', '', '2022-05-29 19:48:30', '2022-05-29 19:48:30', '', 24, 'http://localhost:8888/jtrc/?post_type=acf-field&p=25', 0, 'acf-field', '', 0),
(26, 1, '2022-05-29 19:48:30', '2022-05-29 19:48:30', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Menu Item Price (Small)', 'menu_item_price_s', 'publish', 'closed', 'closed', '', 'field_6293cdd8889c4', '', '', '2022-05-29 19:49:10', '2022-05-29 19:49:10', '', 24, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=26', 2, 'acf-field', '', 0),
(27, 1, '2022-05-29 19:48:30', '2022-05-29 19:48:30', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Menu Item Price( Full)', 'menu_item_price_f', 'publish', 'closed', 'closed', '', 'field_6293cdec889c5', '', '', '2022-05-29 19:49:10', '2022-05-29 19:49:10', '', 24, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=27', 3, 'acf-field', '', 0),
(28, 1, '2022-05-29 19:48:59', '2022-05-29 19:48:59', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Menu Item Description', 'menu_item_description', 'publish', 'closed', 'closed', '', 'field_6293ce19cf03f', '', '', '2022-05-29 19:49:10', '2022-05-29 19:49:10', '', 24, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=28', 1, 'acf-field', '', 0),
(29, 1, '2022-05-29 19:50:42', '2022-05-29 19:50:42', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";}', 'Menu Item Link', 'menu_item_link', 'publish', 'closed', 'closed', '', 'field_6293ce85f443b', '', '', '2022-05-29 19:50:42', '2022-05-29 19:50:42', '', 24, 'http://localhost:8888/jtrc/?post_type=acf-field&p=29', 4, 'acf-field', '', 0),
(30, 1, '2022-05-29 19:51:41', '2022-05-29 19:51:41', '', 'woocommerce-placeholder', '', 'inherit', 'open', 'closed', '', 'woocommerce-placeholder', '', '', '2022-05-29 19:51:41', '2022-05-29 19:51:41', '', 0, 'http://localhost:8888/jtrc/wp-content/uploads/2022/05/woocommerce-placeholder.png', 0, 'attachment', 'image/png', 0),
(31, 1, '2022-05-29 19:51:43', '2022-05-29 19:51:43', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2022-05-29 19:51:43', '2022-05-29 19:51:43', '', 0, 'http://localhost:8888/jtrc/shop/', 0, 'page', '', 0),
(32, 1, '2022-05-29 19:51:43', '2022-05-29 19:51:43', '<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2022-05-29 19:51:43', '2022-05-29 19:51:43', '', 0, 'http://localhost:8888/jtrc/cart/', 0, 'page', '', 0),
(33, 1, '2022-05-29 19:51:43', '2022-05-29 19:51:43', '<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2022-05-29 19:51:43', '2022-05-29 19:51:43', '', 0, 'http://localhost:8888/jtrc/checkout/', 0, 'page', '', 0),
(34, 1, '2022-05-29 19:51:43', '2022-05-29 19:51:43', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2022-05-29 19:51:43', '2022-05-29 19:51:43', '', 0, 'http://localhost:8888/jtrc/my-account/', 0, 'page', '', 0),
(35, 1, '2022-05-29 19:51:43', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p><b>This is a sample page.</b></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h3>Overview</h3>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Several types of goods are exempt from being returned. Perishable goods such as food, flowers, newspapers or magazines cannot be returned. We also do not accept products that are intimate or sanitary goods, hazardous materials, or flammable liquids or gases.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Additional non-returnable items:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Gift cards</li>\n<li>Downloadable software products</li>\n<li>Some health and personal care items</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>To complete your return, we require a receipt or proof of purchase.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Please do not send your purchase back to the manufacturer.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>There are certain situations where only partial refunds are granted:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Book with obvious signs of use</li>\n<li>CD, DVD, VHS tape, software, video game, cassette tape, or vinyl record that has been opened.</li>\n<li>Any item not in its original condition, is damaged or missing parts for reasons not due to our error.</li>\n<li>Any item that is returned more than 30 days after delivery</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<h2>Refunds</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Late or missing refunds</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you haven’t received a refund yet, first check your bank account again.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Then contact your credit card company, it may take some time before your refund is officially posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Next contact your bank. There is often some processing time before a refund is posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you’ve done all of this and you still have not received your refund yet, please contact us at {email address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Sale items</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Only regular priced items may be refunded. Sale items cannot be refunded.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Exchanges</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at {email address} and send your item to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Gifts</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item was marked as a gift when purchased and shipped directly to you, you’ll receive a gift credit for the value of your return. Once the returned item is received, a gift certificate will be mailed to you.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item wasn’t marked as a gift when purchased, or the gift giver had the order shipped to themselves to give to you later, we will send a refund to the gift giver and they will find out about your return.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Shipping returns</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To return your product, you should mail your product to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Depending on where you live, the time it may take for your exchanged product to reach you may vary.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are returning more expensive items, you may consider using a trackable shipping service or purchasing shipping insurance. We don’t guarantee that we will receive your returned item.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Need help?</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Contact us at {email} for questions related to refunds and returns.</p>\n<!-- /wp:paragraph -->', 'Refund and Returns Policy', '', 'draft', 'closed', 'closed', '', 'refund_returns', '', '', '2022-05-29 19:51:43', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/jtrc/?page_id=35', 0, 'page', '', 0),
(36, 1, '2022-08-28 13:49:06', '2022-05-29 19:54:51', ' ', '', '', 'publish', 'closed', 'closed', '', '36', '', '', '2022-08-28 13:49:06', '2022-08-28 13:49:06', '', 0, 'http://localhost:8888/jtrc/?p=36', 1, 'nav_menu_item', '', 0),
(37, 1, '2022-05-29 20:04:21', '2022-05-29 20:04:21', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Menu Title', 'menu_title', 'publish', 'closed', 'closed', '', 'field_6293d1bb456ea', '', '', '2022-05-29 20:04:21', '2022-05-29 20:04:21', '', 23, 'http://localhost:8888/jtrc/?post_type=acf-field&p=37', 0, 'acf-field', '', 0),
(38, 1, '2022-05-29 20:04:57', '2022-05-29 20:04:57', '', 'Menu', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2022-05-29 20:04:57', '2022-05-29 20:04:57', '', 21, 'http://localhost:8888/jtrc/?p=38', 0, 'revision', '', 0),
(39, 1, '2022-05-29 20:12:01', '2022-05-29 20:12:01', '', 'Menu', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2022-05-29 20:12:01', '2022-05-29 20:12:01', '', 21, 'http://localhost:8888/jtrc/?p=39', 0, 'revision', '', 0),
(40, 1, '2022-05-29 20:12:29', '2022-05-29 20:12:29', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Menu Description', 'menu_description', 'publish', 'closed', 'closed', '', 'field_6293d39ff58ee', '', '', '2022-05-29 20:12:29', '2022-05-29 20:12:29', '', 23, 'http://localhost:8888/jtrc/?post_type=acf-field&p=40', 1, 'acf-field', '', 0),
(41, 1, '2022-05-29 20:15:53', '2022-05-29 20:15:53', '', 'Menu', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2022-05-29 20:15:53', '2022-05-29 20:15:53', '', 21, 'http://localhost:8888/jtrc/?p=41', 0, 'revision', '', 0),
(42, 1, '2022-05-29 21:03:02', '2022-05-29 21:03:02', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Appetizers', 'appetizers_items', 'publish', 'closed', 'closed', '', 'field_6293df36d1f5e', '', '', '2022-05-29 21:03:02', '2022-05-29 21:03:02', '', 23, 'http://localhost:8888/jtrc/?post_type=acf-field&p=42', 3, 'acf-field', '', 0),
(43, 1, '2022-05-29 21:03:02', '2022-05-29 21:03:02', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Menu Item Name', 'menu_item_name', 'publish', 'closed', 'closed', '', 'field_6293df36d1f5f', '', '', '2022-05-29 21:03:02', '2022-05-29 21:03:02', '', 42, 'http://localhost:8888/jtrc/?post_type=acf-field&p=43', 0, 'acf-field', '', 0),
(44, 1, '2022-05-29 21:03:02', '2022-05-29 21:03:02', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Menu Item Description', 'menu_item_description', 'publish', 'closed', 'closed', '', 'field_6293df36d1f60', '', '', '2022-05-29 21:03:02', '2022-05-29 21:03:02', '', 42, 'http://localhost:8888/jtrc/?post_type=acf-field&p=44', 1, 'acf-field', '', 0),
(45, 1, '2022-05-29 21:03:02', '2022-05-29 21:03:02', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Quantity/Price (Small)', 'quantityprice_small', 'publish', 'closed', 'closed', '', 'field_6293df36d1f61', '', '', '2022-05-29 21:03:02', '2022-05-29 21:03:02', '', 42, 'http://localhost:8888/jtrc/?post_type=acf-field&p=45', 2, 'acf-field', '', 0),
(46, 1, '2022-05-29 21:03:02', '2022-05-29 21:03:02', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Quanity/Price (Large)', 'quantityprice_large', 'publish', 'closed', 'closed', '', 'field_6293df36d1f62', '', '', '2022-05-29 21:03:02', '2022-05-29 21:03:02', '', 42, 'http://localhost:8888/jtrc/?post_type=acf-field&p=46', 3, 'acf-field', '', 0),
(47, 1, '2022-05-29 21:03:02', '2022-05-29 21:03:02', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";}', 'Menu Item Link', 'menu_item_link', 'publish', 'closed', 'closed', '', 'field_6293df36d1f63', '', '', '2022-05-29 21:03:02', '2022-05-29 21:03:02', '', 42, 'http://localhost:8888/jtrc/?post_type=acf-field&p=47', 4, 'acf-field', '', 0),
(48, 1, '2022-05-29 21:08:27', '2022-05-29 21:08:27', '', 'Menu', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2022-05-29 21:08:27', '2022-05-29 21:08:27', '', 21, 'http://localhost:8888/jtrc/?p=48', 0, 'revision', '', 0),
(55, 1, '2022-05-29 21:39:09', '2022-05-29 21:39:09', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2022-09-27 20:40:09', '2022-09-27 20:40:09', '', 0, 'http://localhost:8888/jtrc/?page_id=55', 0, 'page', '', 0),
(56, 1, '2022-05-29 21:39:09', '2022-05-29 21:39:09', '', 'About', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-05-29 21:39:09', '2022-05-29 21:39:09', '', 55, 'http://localhost:8888/jtrc/?p=56', 0, 'revision', '', 0),
(57, 1, '2022-05-29 21:43:06', '2022-05-29 21:40:49', ' ', '', '', 'publish', 'closed', 'closed', '', '57', '', '', '2022-05-29 21:43:06', '2022-05-29 21:43:06', '', 0, 'http://localhost:8888/jtrc/?p=57', 1, 'nav_menu_item', '', 0),
(58, 1, '2022-05-29 21:43:06', '2022-05-29 21:40:49', ' ', '', '', 'publish', 'closed', 'closed', '', '58', '', '', '2022-05-29 21:43:06', '2022-05-29 21:43:06', '', 0, 'http://localhost:8888/jtrc/?p=58', 4, 'nav_menu_item', '', 0),
(59, 1, '2022-05-29 21:43:06', '2022-05-29 21:40:49', ' ', '', '', 'publish', 'closed', 'closed', '', '59', '', '', '2022-05-29 21:43:06', '2022-05-29 21:43:06', '', 0, 'http://localhost:8888/jtrc/?p=59', 3, 'nav_menu_item', '', 0),
(60, 1, '2022-05-29 21:43:06', '2022-05-29 21:40:49', ' ', '', '', 'publish', 'closed', 'closed', '', '60', '', '', '2022-05-29 21:43:06', '2022-05-29 21:43:06', '', 0, 'http://localhost:8888/jtrc/?p=60', 2, 'nav_menu_item', '', 0),
(61, 1, '2022-05-29 21:43:50', '2022-05-29 21:43:50', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-05-29 21:43:50', '2022-05-29 21:43:50', '', 7, 'http://localhost:8888/jtrc/?p=61', 0, 'revision', '', 0),
(62, 1, '2022-05-30 04:17:59', '2022-05-30 04:17:59', '', 'Brunch Package', 'Both <strong>descriptions</strong> of rock yielded good material for building; while in the soft meleke tanks, underground chambers, tombs, &amp;c., were easily excavated.', 'publish', 'open', 'closed', '', 'brunch-package', '', '', '2022-08-27 23:50:25', '2022-08-27 23:50:25', '', 0, 'http://localhost:8888/jtrc/?post_type=product&#038;p=62', 0, 'product', '', 1),
(63, 1, '2022-05-30 04:22:19', '2022-05-30 04:22:19', '', 'Waffles ( Small Size )', 'This is a description', 'publish', 'open', 'closed', '', 'waffles', '', '', '2022-07-18 16:43:28', '2022-07-18 16:43:28', '', 0, 'http://localhost:8888/jtrc/?post_type=product&#038;p=63', 0, 'product', '', 0),
(66, 1, '2022-05-30 04:27:53', '2022-05-30 04:27:53', '', 'Waffles ( Full Size )', '', 'publish', 'open', 'closed', '', 'waffles-full-size', '', '', '2022-07-18 16:38:53', '2022-07-18 16:38:53', '', 0, 'http://localhost:8888/jtrc/?post_type=product&#038;p=66', 0, 'product', '', 0),
(67, 1, '2022-05-30 04:29:44', '2022-05-30 04:29:44', '', 'mae-mu-dEUyLofZe5o-unsplash', '', 'inherit', 'open', 'closed', '', 'mae-mu-deuylofze5o-unsplash', '', '', '2022-05-30 04:29:44', '2022-05-30 04:29:44', '', 63, 'http://localhost:8888/jtrc/wp-content/uploads/2022/05/mae-mu-dEUyLofZe5o-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(68, 1, '2022-05-30 04:34:35', '2022-05-30 04:34:35', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-05-30 04:34:35', '2022-05-30 04:34:35', '', 7, 'http://localhost:8888/jtrc/?p=68', 0, 'revision', '', 0),
(69, 1, '2022-05-30 04:37:42', '2022-05-30 04:37:42', '', 'Scrambled Eggs ( Small )', '', 'publish', 'open', 'closed', '', 'scrambled-eggs-small', '', '', '2022-05-30 04:41:49', '2022-05-30 04:41:49', '', 0, 'http://localhost:8888/jtrc/?post_type=product&#038;p=69', 0, 'product', '', 0),
(70, 1, '2022-05-30 04:37:07', '2022-05-30 04:37:07', '', 'scrambled-eggs-sq', '', 'inherit', 'open', 'closed', '', 'scrambled-eggs-sq', '', '', '2022-05-30 04:37:07', '2022-05-30 04:37:07', '', 7, 'http://localhost:8888/jtrc/wp-content/uploads/2022/05/scrambled-eggs-sq.webp', 0, 'attachment', 'image/webp', 0),
(71, 1, '2022-05-30 04:37:17', '2022-05-30 04:37:17', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-05-30 04:37:17', '2022-05-30 04:37:17', '', 7, 'http://localhost:8888/jtrc/?p=71', 0, 'revision', '', 0),
(72, 1, '2022-05-30 04:38:14', '2022-05-30 04:38:14', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-05-30 04:38:14', '2022-05-30 04:38:14', '', 7, 'http://localhost:8888/jtrc/?p=72', 0, 'revision', '', 0),
(73, 1, '2022-05-30 04:38:37', '2022-05-30 04:38:37', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-05-30 04:38:37', '2022-05-30 04:38:37', '', 7, 'http://localhost:8888/jtrc/?p=73', 0, 'revision', '', 0),
(76, 1, '2022-05-30 04:47:33', '2022-05-30 04:47:33', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-05-30 04:47:33', '2022-05-30 04:47:33', '', 7, 'http://localhost:8888/jtrc/?p=76', 0, 'revision', '', 0),
(77, 1, '2022-08-28 13:49:06', '2022-05-30 04:52:21', ' ', '', '', 'publish', 'closed', 'closed', '', '77', '', '', '2022-08-28 13:49:06', '2022-08-28 13:49:06', '', 0, 'http://localhost:8888/jtrc/?p=77', 2, 'nav_menu_item', '', 0),
(79, 1, '2022-08-28 13:49:06', '2022-05-30 04:52:21', ' ', '', '', 'publish', 'closed', 'closed', '', '79', '', '', '2022-08-28 13:49:06', '2022-08-28 13:49:06', '', 0, 'http://localhost:8888/jtrc/?p=79', 3, 'nav_menu_item', '', 0),
(83, 1, '2022-07-14 19:19:19', '2022-07-14 19:19:19', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:1:"7";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Pages: Homepage', 'pages-homepage', 'publish', 'closed', 'closed', '', 'group_62d06beed4f1d', '', '', '2022-08-28 14:06:17', '2022-08-28 14:06:17', '', 0, 'http://localhost:8888/jtrc/?post_type=acf-field-group&#038;p=83', 0, 'acf-field-group', '', 0),
(84, 1, '2022-07-14 19:19:19', '2022-07-14 19:19:19', 'a:12:{s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:7:"product";}s:8:"taxonomy";s:0:"";s:7:"filters";a:3:{i:0;s:6:"search";i:1;s:9:"post_type";i:2;s:8:"taxonomy";}s:8:"elements";s:0:"";s:3:"min";i:1;s:3:"max";s:0:"";s:13:"return_format";s:6:"object";}', 'Featured Breakfast Items', 'featured_breakfast_items', 'publish', 'closed', 'closed', '', 'field_62d06c020cdae', '', '', '2022-07-14 19:43:04', '2022-07-14 19:43:04', '', 83, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=84', 1, 'acf-field', '', 0),
(85, 1, '2022-07-14 19:26:59', '2022-07-14 19:26:59', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-07-14 19:26:59', '2022-07-14 19:26:59', '', 7, 'http://localhost:8888/jtrc/?p=85', 0, 'revision', '', 0),
(86, 1, '2022-07-14 19:43:04', '2022-07-14 19:43:04', 'a:12:{s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:7:"product";}s:8:"taxonomy";s:0:"";s:7:"filters";a:3:{i:0;s:6:"search";i:1;s:9:"post_type";i:2;s:8:"taxonomy";}s:8:"elements";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:13:"return_format";s:6:"object";}', 'Featured Breakfast Packages', 'featured_breakfast_packages', 'publish', 'closed', 'closed', '', 'field_62d071a998c70', '', '', '2022-07-14 19:43:04', '2022-07-14 19:43:04', '', 83, 'http://localhost:8888/jtrc/?post_type=acf-field&p=86', 0, 'acf-field', '', 0),
(87, 1, '2022-07-18 16:06:09', '2022-07-18 16:06:09', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-07-18 16:06:09', '2022-07-18 16:06:09', '', 7, 'http://localhost:8888/jtrc/?p=87', 0, 'revision', '', 0),
(88, 1, '2022-07-18 16:25:12', '2022-07-18 16:25:12', '', 'brooke-lark-aGjP08-HbYY-unsplash', '', 'inherit', 'open', 'closed', '', 'brooke-lark-agjp08-hbyy-unsplash', '', '', '2022-07-18 16:25:12', '2022-07-18 16:25:12', '', 62, 'http://localhost:8888/jtrc/wp-content/uploads/2022/05/brooke-lark-aGjP08-HbYY-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(89, 1, '2022-07-18 16:38:36', '2022-07-18 16:38:36', '', 'erion-dalti-S8Aroj0Y4TA-unsplash', '', 'inherit', 'open', 'closed', '', 'erion-dalti-s8aroj0y4ta-unsplash', '', '', '2022-07-18 16:38:36', '2022-07-18 16:38:36', '', 66, 'http://localhost:8888/jtrc/wp-content/uploads/2022/05/erion-dalti-S8Aroj0Y4TA-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(90, 1, '2022-07-19 16:23:53', '2022-07-19 16:23:53', '', 'jtrc_logo', '', 'inherit', 'open', 'closed', '', 'jtrc_logo', '', '', '2022-07-19 16:23:53', '2022-07-19 16:23:53', '', 0, 'http://localhost:8888/jtrc/wp-content/uploads/2022/07/jtrc_logo.png', 0, 'attachment', 'image/png', 0),
(94, 1, '2022-07-19 16:54:06', '2022-07-19 16:54:06', 'a:12:{s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:7:"product";}s:8:"taxonomy";s:0:"";s:7:"filters";a:3:{i:0;s:6:"search";i:1;s:9:"post_type";i:2;s:8:"taxonomy";}s:8:"elements";s:0:"";s:3:"min";i:1;s:3:"max";i:1;s:13:"return_format";s:6:"object";}', 'Featured Appetizers Package', 'featured_appetizers_package', 'publish', 'closed', 'closed', '', 'field_62d6def8e06e8', '', '', '2022-07-19 16:54:06', '2022-07-19 16:54:06', '', 83, 'http://localhost:8888/jtrc/?post_type=acf-field&p=94', 2, 'acf-field', '', 0),
(95, 1, '2022-07-19 16:54:06', '2022-07-19 16:54:06', 'a:12:{s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:7:"product";}s:8:"taxonomy";s:0:"";s:7:"filters";a:3:{i:0;s:6:"search";i:1;s:9:"post_type";i:2;s:8:"taxonomy";}s:8:"elements";s:0:"";s:3:"min";i:1;s:3:"max";i:2;s:13:"return_format";s:6:"object";}', 'Featured Appetizers Items', 'featured_appetizers_items', 'publish', 'closed', 'closed', '', 'field_62d6e132e06e9', '', '', '2022-07-19 16:54:06', '2022-07-19 16:54:06', '', 83, 'http://localhost:8888/jtrc/?post_type=acf-field&p=95', 3, 'acf-field', '', 0),
(96, 1, '2022-07-19 19:34:40', '2022-07-19 19:34:40', '', 'Fried Chicken Cheddar Biscuit Sliders (20 each)', '', 'publish', 'open', 'closed', '', 'fried-chicken-cheddar-biscuit-sliders', '', '', '2022-07-19 19:53:44', '2022-07-19 19:53:44', '', 0, 'http://localhost:8888/jtrc/?post_type=product&#038;p=96', 0, 'product', '', 0),
(99, 1, '2022-07-19 19:38:17', '2022-07-19 19:38:17', '', 'tabitha-turner-Ns2aJ5OXKds-unsplash', '', 'inherit', 'open', 'closed', '', 'tabitha-turner-ns2aj5oxkds-unsplash', '', '', '2022-07-19 19:38:17', '2022-07-19 19:38:17', '', 96, 'http://localhost:8888/jtrc/wp-content/uploads/2022/07/tabitha-turner-Ns2aJ5OXKds-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(100, 1, '2022-07-19 19:39:49', '2022-07-19 19:39:49', '', 'Homepage', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-07-19 19:39:49', '2022-07-19 19:39:49', '', 7, 'http://localhost:8888/jtrc/?p=100', 0, 'revision', '', 0),
(101, 1, '2022-07-19 21:01:44', '2022-07-19 21:01:44', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"55";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Pages: About', 'pages-about', 'publish', 'closed', 'closed', '', 'group_62d71b9cde637', '', '', '2022-09-27 20:39:36', '2022-09-27 20:39:36', '', 0, 'http://localhost:8888/jtrc/?post_type=acf-field-group&#038;p=101', 0, 'acf-field-group', '', 0),
(102, 1, '2022-07-19 21:01:44', '2022-07-19 21:01:44', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_62d71babcd1c0', '', '', '2022-09-27 15:13:11', '2022-09-27 15:13:11', '', 101, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=102', 0, 'acf-field', '', 0),
(103, 1, '2022-07-19 21:08:06', '2022-07-19 21:08:06', '', 'image0', '', 'inherit', 'open', 'closed', '', 'image0', '', '', '2022-07-19 21:08:06', '2022-07-19 21:08:06', '', 55, 'http://localhost:8888/jtrc/wp-content/uploads/2022/07/image0.jpeg', 0, 'attachment', 'image/jpeg', 0),
(104, 1, '2022-07-19 21:08:15', '2022-07-19 21:08:15', '', 'About', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-07-19 21:08:15', '2022-07-19 21:08:15', '', 55, 'http://localhost:8888/jtrc/?p=104', 0, 'revision', '', 0),
(105, 1, '2022-07-19 21:16:55', '2022-07-19 21:16:55', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph -->', 'About', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-07-19 21:16:55', '2022-07-19 21:16:55', '', 55, 'http://localhost:8888/jtrc/?p=105', 0, 'revision', '', 0),
(106, 1, '2022-07-19 21:26:51', '2022-07-19 21:26:51', '', 'Weekly Special', '', 'publish', 'closed', 'closed', '', 'weekly-special', '', '', '2022-07-19 21:26:51', '2022-07-19 21:26:51', '', 0, 'http://localhost:8888/jtrc/?page_id=106', 0, 'page', '', 0),
(107, 1, '2022-07-19 21:26:51', '2022-07-19 21:26:51', '', 'Weekly Special', '', 'inherit', 'closed', 'closed', '', '106-revision-v1', '', '', '2022-07-19 21:26:51', '2022-07-19 21:26:51', '', 106, 'http://localhost:8888/jtrc/?p=107', 0, 'revision', '', 0),
(108, 1, '2022-07-20 03:51:37', '2022-07-20 03:51:37', '', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2022-07-20 03:51:37', '2022-07-20 03:51:37', '', 0, 'http://localhost:8888/jtrc/?page_id=108', 0, 'page', '', 0),
(109, 1, '2022-07-20 03:51:37', '2022-07-20 03:51:37', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '108-revision-v1', '', '', '2022-07-20 03:51:37', '2022-07-20 03:51:37', '', 108, 'http://localhost:8888/jtrc/?p=109', 0, 'revision', '', 0),
(111, 1, '2022-08-28 03:39:32', '2022-07-20 03:56:46', ' ', '', '', 'publish', 'closed', 'closed', '', '111', '', '', '2022-08-28 03:39:32', '2022-08-28 03:39:32', '', 0, 'http://localhost:8888/jtrc/?p=111', 1, 'nav_menu_item', '', 0),
(113, 1, '2022-08-27 22:56:20', '2022-08-27 22:56:20', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"product";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Pages: Single Product', 'pages-single-product', 'publish', 'closed', 'closed', '', 'group_630aa0fa26ced', '', '', '2022-08-27 22:56:20', '2022-08-27 22:56:20', '', 0, 'http://localhost:8888/jtrc/?post_type=acf-field-group&#038;p=113', 0, 'acf-field-group', '', 0),
(114, 1, '2022-08-27 22:56:20', '2022-08-27 22:56:20', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Serving Size', 'serving_size', 'publish', 'closed', 'closed', '', 'field_630aa10db0892', '', '', '2022-08-27 22:56:20', '2022-08-27 22:56:20', '', 113, 'http://localhost:8888/jtrc/?post_type=acf-field&p=114', 0, 'acf-field', '', 0),
(115, 1, '2022-08-28 01:17:04', '2022-08-28 01:17:04', '', 'Reviews', '', 'publish', 'closed', 'closed', '', 'reviews', '', '', '2022-08-28 01:17:04', '2022-08-28 01:17:04', '', 0, 'http://localhost:8888/jtrc/?page_id=115', 0, 'page', '', 0),
(116, 1, '2022-08-28 01:17:04', '2022-08-28 01:17:04', '', 'Reviews', '', 'inherit', 'closed', 'closed', '', '115-revision-v1', '', '', '2022-08-28 01:17:04', '2022-08-28 01:17:04', '', 115, 'http://localhost:8888/jtrc/?p=116', 0, 'revision', '', 0),
(117, 1, '2022-08-28 13:49:06', '2022-08-28 01:17:47', ' ', '', '', 'publish', 'closed', 'closed', '', '117', '', '', '2022-08-28 13:49:06', '2022-08-28 13:49:06', '', 0, 'http://localhost:8888/jtrc/?p=117', 4, 'nav_menu_item', '', 0),
(118, 1, '2022-08-28 13:49:06', '2022-08-28 01:17:47', ' ', '', '', 'publish', 'closed', 'closed', '', '118', '', '', '2022-08-28 13:49:06', '2022-08-28 13:49:06', '', 0, 'http://localhost:8888/jtrc/?p=118', 5, 'nav_menu_item', '', 0),
(120, 1, '2022-08-28 03:39:32', '2022-08-28 03:39:32', ' ', '', '', 'publish', 'closed', 'closed', '', '120', '', '', '2022-08-28 03:39:32', '2022-08-28 03:39:32', '', 0, 'http://localhost:8888/jtrc/?p=120', 2, 'nav_menu_item', '', 0),
(121, 1, '2022-08-28 03:39:32', '2022-08-28 03:39:32', ' ', '', '', 'publish', 'closed', 'closed', '', '121', '', '', '2022-08-28 03:39:32', '2022-08-28 03:39:32', '', 0, 'http://localhost:8888/jtrc/?p=121', 3, 'nav_menu_item', '', 0),
(122, 1, '2022-08-28 03:46:24', '2022-08-28 03:46:24', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:11:"acf-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Footer Fields', 'footer-fields', 'publish', 'closed', 'closed', '', 'group_630ae491b6927', '', '', '2022-08-28 05:57:26', '2022-08-28 05:57:26', '', 0, 'http://localhost:8888/jtrc/?post_type=acf-field-group&#038;p=122', 0, 'acf-field-group', '', 0),
(123, 1, '2022-08-28 03:46:24', '2022-08-28 03:46:24', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:30:"Please enter the Instagram URL";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Instagram', 'instagram', 'publish', 'closed', 'closed', '', 'field_630ae4a02b2d4', '', '', '2022-08-28 04:24:32', '2022-08-28 04:24:32', '', 122, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=123', 1, 'acf-field', '', 0),
(124, 1, '2022-08-28 03:47:53', '2022-08-28 03:47:53', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";}', 'Design Link', 'design_link', 'publish', 'closed', 'closed', '', 'field_630ae543c64a4', '', '', '2022-08-28 04:24:32', '2022-08-28 04:24:32', '', 122, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=124', 2, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(125, 1, '2022-08-28 04:24:24', '2022-08-28 04:24:24', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Social Links', 'social_links', 'publish', 'closed', 'closed', '', 'field_630aed4e34192', '', '', '2022-08-28 04:24:32', '2022-08-28 04:24:32', '', 122, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=125', 0, 'acf-field', '', 0),
(126, 1, '2022-08-28 04:24:24', '2022-08-28 04:24:24', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Delivery Information', 'delivery_information', 'publish', 'closed', 'closed', '', 'field_630aed6634193', '', '', '2022-08-28 04:24:24', '2022-08-28 04:24:24', '', 122, 'http://localhost:8888/jtrc/?post_type=acf-field&p=126', 3, 'acf-field', '', 0),
(127, 1, '2022-08-28 04:24:24', '2022-08-28 04:24:24', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:56:"Add a delivery service ex.(Uber Eats, Doordash, Grubhub)";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:20:"Add Delivery Service";}', 'Delivery Services', 'delivery_services', 'publish', 'closed', 'closed', '', 'field_630aed7634194', '', '', '2022-08-28 05:57:26', '2022-08-28 05:57:26', '', 122, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=127', 5, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(128, 1, '2022-08-28 04:24:24', '2022-08-28 04:24:24', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Logo', 'logo', 'publish', 'closed', 'closed', '', 'field_630aedc134195', '', '', '2022-08-28 04:24:24', '2022-08-28 04:24:24', '', 127, 'http://localhost:8888/jtrc/?post_type=acf-field&p=128', 0, 'acf-field', '', 0),
(129, 1, '2022-08-28 04:24:24', '2022-08-28 04:24:24', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_630aedd134196', '', '', '2022-08-28 04:24:24', '2022-08-28 04:24:24', '', 127, 'http://localhost:8888/jtrc/?post_type=acf-field&p=129', 1, 'acf-field', '', 0),
(130, 1, '2022-08-28 04:26:49', '2022-08-28 04:26:49', '', 'doordash-logo', '', 'inherit', 'open', 'closed', '', 'doordash-logo', '', '', '2022-08-28 04:26:49', '2022-08-28 04:26:49', '', 0, 'http://localhost:8888/jtrc/wp-content/uploads/2022/08/doordash-logo.svg', 0, 'attachment', 'image/svg+xml', 0),
(131, 1, '2022-08-28 04:26:50', '2022-08-28 04:26:50', '', 'grubhub-1', '', 'inherit', 'open', 'closed', '', 'grubhub-1', '', '', '2022-08-28 04:26:50', '2022-08-28 04:26:50', '', 0, 'http://localhost:8888/jtrc/wp-content/uploads/2022/08/grubhub-1.svg', 0, 'attachment', 'image/svg+xml', 0),
(132, 1, '2022-08-28 04:26:51', '2022-08-28 04:26:51', '', 'uber-eats', '', 'inherit', 'open', 'closed', '', 'uber-eats', '', '', '2022-08-28 04:26:51', '2022-08-28 04:26:51', '', 0, 'http://localhost:8888/jtrc/wp-content/uploads/2022/08/uber-eats.svg', 0, 'attachment', 'image/svg+xml', 0),
(133, 1, '2022-08-28 05:04:39', '2022-08-28 05:04:39', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Copyright', 'copyright', 'publish', 'closed', 'closed', '', 'field_630af75294f89', '', '', '2022-08-28 05:57:26', '2022-08-28 05:57:26', '', 122, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=133', 6, 'acf-field', '', 0),
(134, 1, '2022-08-28 05:04:39', '2022-08-28 05:04:39', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Copyright Year', 'copyright_year', 'publish', 'closed', 'closed', '', 'field_630af76094f8a', '', '', '2022-08-28 05:57:26', '2022-08-28 05:57:26', '', 122, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=134', 7, 'acf-field', '', 0),
(135, 1, '2022-08-28 05:09:17', '2022-08-28 05:09:17', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:11:"acf-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Header Fields', 'header-fields', 'publish', 'closed', 'closed', '', 'group_630af85220a31', '', '', '2022-08-28 05:09:17', '2022-08-28 05:09:17', '', 0, 'http://localhost:8888/jtrc/?post_type=acf-field-group&#038;p=135', 0, 'acf-field-group', '', 0),
(136, 1, '2022-08-28 05:09:17', '2022-08-28 05:09:17', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Annoucement Banner', 'annoucement_banner', 'publish', 'closed', 'closed', '', 'field_630af8619f7af', '', '', '2022-08-28 05:09:17', '2022-08-28 05:09:17', '', 135, 'http://localhost:8888/jtrc/?post_type=acf-field&p=136', 0, 'acf-field', '', 0),
(137, 1, '2022-08-28 05:56:53', '2022-08-28 05:56:53', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Payment Options', 'payment_options', 'publish', 'closed', 'closed', '', 'field_630b034f67cd1', '', '', '2022-08-28 05:57:26', '2022-08-28 05:57:26', '', 122, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=137', 8, 'acf-field', '', 0),
(138, 1, '2022-08-28 05:56:53', '2022-08-28 05:56:53', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Payment Options Title', 'payment_options_title', 'publish', 'closed', 'closed', '', 'field_630b036467cd2', '', '', '2022-08-28 05:57:26', '2022-08-28 05:57:26', '', 122, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=138', 9, 'acf-field', '', 0),
(139, 1, '2022-08-28 05:56:53', '2022-08-28 05:56:53', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:16:"Add Payment Icon";}', 'Payment Options', 'payment_options', 'publish', 'closed', 'closed', '', 'field_630b036d67cd3', '', '', '2022-08-28 05:57:26', '2022-08-28 05:57:26', '', 122, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=139', 10, 'acf-field', '', 0),
(140, 1, '2022-08-28 05:56:53', '2022-08-28 05:56:53', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:32:"Upload an accepted payment icon.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Payment Icon', 'payment_icon', 'publish', 'closed', 'closed', '', 'field_630b038367cd4', '', '', '2022-08-28 05:56:53', '2022-08-28 05:56:53', '', 139, 'http://localhost:8888/jtrc/?post_type=acf-field&p=140', 0, 'acf-field', '', 0),
(141, 1, '2022-08-28 05:57:16', '2022-08-28 05:57:16', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Delivery Options Title', 'delivery_options_title', 'publish', 'closed', 'closed', '', 'field_630b03b2bdd61', '', '', '2022-08-28 05:57:26', '2022-08-28 05:57:26', '', 122, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=141', 4, 'acf-field', '', 0),
(143, 1, '2022-09-27 19:30:21', '2022-09-27 19:30:21', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph -->', 'About', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-09-27 19:30:21', '2022-09-27 19:30:21', '', 55, 'http://localhost:8888/jtrc/?p=143', 0, 'revision', '', 0),
(144, 1, '2022-09-27 19:30:56', '2022-09-27 19:30:56', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"new_lines";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:4:"rows";s:0:"";}', 'Content', 'content', 'publish', 'closed', 'closed', '', 'field_63334f6784972', '', '', '2022-09-27 20:39:36', '2022-09-27 20:39:36', '', 101, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=144', 2, 'acf-field', '', 0),
(145, 1, '2022-09-27 19:31:23', '2022-09-27 19:31:23', '', 'About', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-09-27 19:31:23', '2022-09-27 19:31:23', '', 55, 'http://localhost:8888/jtrc/?p=145', 0, 'revision', '', 0),
(146, 1, '2022-09-27 19:31:24', '2022-09-27 19:31:24', '', 'About', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-09-27 19:31:24', '2022-09-27 19:31:24', '', 55, 'http://localhost:8888/jtrc/?p=146', 0, 'revision', '', 0),
(147, 1, '2022-09-27 20:03:50', '2022-09-27 20:03:50', '', 'johnathan-macedo-4NQEvxW2_4w-unsplash', '', 'inherit', 'open', 'closed', '', 'johnathan-macedo-4nqevxw2_4w-unsplash', '', '', '2022-09-27 20:03:50', '2022-09-27 20:03:50', '', 55, 'http://localhost:8888/jtrc/wp-content/uploads/2022/09/johnathan-macedo-4NQEvxW2_4w-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(148, 1, '2022-09-27 20:04:16', '2022-09-27 20:04:16', '', 'About', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-09-27 20:04:16', '2022-09-27 20:04:16', '', 55, 'http://localhost:8888/jtrc/?p=148', 0, 'revision', '', 0),
(149, 1, '2022-09-27 20:08:38', '2022-09-27 20:08:38', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_633358419377d', '', '', '2022-09-27 20:39:36', '2022-09-27 20:39:36', '', 101, 'http://localhost:8888/jtrc/?post_type=acf-field&#038;p=149', 1, 'acf-field', '', 0),
(150, 1, '2022-09-27 20:09:09', '2022-09-27 20:09:09', '', 'About', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-09-27 20:09:09', '2022-09-27 20:09:09', '', 55, 'http://localhost:8888/jtrc/?p=150', 0, 'revision', '', 0),
(151, 1, '2022-09-27 20:39:29', '2022-09-27 20:39:29', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Signature', 'signature', 'publish', 'closed', 'closed', '', 'field_63335f76f0086', '', '', '2022-09-27 20:39:29', '2022-09-27 20:39:29', '', 101, 'http://localhost:8888/jtrc/?post_type=acf-field&p=151', 3, 'acf-field', '', 0),
(152, 1, '2022-09-27 20:39:59', '2022-09-27 20:39:59', '', 'signature', '', 'inherit', 'open', 'closed', '', 'signature', '', '', '2022-09-27 20:39:59', '2022-09-27 20:39:59', '', 55, 'http://localhost:8888/jtrc/wp-content/uploads/2022/09/signature.png', 0, 'attachment', 'image/png', 0),
(153, 1, '2022-09-27 20:40:09', '2022-09-27 20:40:09', '', 'About', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-09-27 20:40:09', '2022-09-27 20:40:09', '', 55, 'http://localhost:8888/jtrc/?p=153', 0, 'revision', '', 0),
(154, 1, '2022-10-12 03:23:05', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-10-12 03:23:05', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/jtrc/?p=154', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(8, 2, 0),
(36, 3, 0),
(57, 18, 0),
(58, 18, 0),
(59, 18, 0),
(60, 18, 0),
(62, 5, 0),
(62, 16, 0),
(62, 19, 0),
(63, 4, 0),
(63, 11, 0),
(63, 19, 0),
(66, 4, 0),
(66, 17, 0),
(69, 4, 0),
(69, 19, 0),
(77, 3, 0),
(79, 3, 0),
(96, 6, 0),
(96, 11, 0),
(96, 20, 0),
(96, 21, 0),
(111, 22, 0),
(117, 3, 0),
(118, 3, 0),
(120, 22, 0),
(121, 22, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'nav_menu', '', 0, 5),
(4, 4, 'product_type', '', 0, 3),
(5, 5, 'product_type', '', 0, 1),
(6, 6, 'product_type', '', 0, 1),
(7, 7, 'product_type', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 2),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_visibility', '', 0, 0),
(16, 16, 'product_visibility', '', 0, 1),
(17, 17, 'product_cat', '', 0, 1),
(18, 18, 'nav_menu', '', 0, 4),
(19, 19, 'product_cat', '', 0, 3),
(20, 20, 'product_cat', '', 0, 1),
(21, 21, 'product_tag', '', 0, 1),
(22, 22, 'nav_menu', '', 0, 3) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#
INSERT INTO `wp_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 17, 'product_count_product_cat', '1'),
(2, 19, 'order', '0'),
(3, 19, 'product_count_product_cat', '3'),
(4, 20, 'order', '0'),
(5, 20, 'product_count_product_cat', '1'),
(6, 21, 'product_count_product_tag', '1') ;

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'jtrc', 'jtrc', 0),
(3, 'Menu 1', 'menu-1', 0),
(4, 'simple', 'simple', 0),
(5, 'grouped', 'grouped', 0),
(6, 'variable', 'variable', 0),
(7, 'external', 'external', 0),
(8, 'exclude-from-search', 'exclude-from-search', 0),
(9, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(10, 'featured', 'featured', 0),
(11, 'outofstock', 'outofstock', 0),
(12, 'rated-1', 'rated-1', 0),
(13, 'rated-2', 'rated-2', 0),
(14, 'rated-3', 'rated-3', 0),
(15, 'rated-4', 'rated-4', 0),
(16, 'rated-5', 'rated-5', 0),
(17, 'Uncategorized', 'uncategorized', 0),
(18, 'Primary Navigation', 'primary-navigation', 0),
(19, 'Breakfast/Brunch', 'breakfast-brunch', 0),
(20, 'Appetizers', 'appetizers', 0),
(21, 'Appetizers', 'appetizers', 0),
(22, 'Footer Menu', 'footer-menu', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'Lawrence'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '154'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'wp_user-settings', 'libraryContent=browse'),
(20, 1, 'wp_user-settings-time', '1653843411'),
(21, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(22, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(23, 1, '_woocommerce_tracks_anon_id', 'woo:nFqvq6/MvK35MAr7VNygKfEc'),
(24, 1, 'wc_last_active', '1665532800'),
(25, 1, 'nav_menu_recently_edited', '3'),
(26, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:"cart";a:1:{s:32:"3295c76acbf4caaed33c36b1b5fc2cb1";a:11:{s:3:"key";s:32:"3295c76acbf4caaed33c36b1b5fc2cb1";s:10:"product_id";i:66;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:100;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:100;s:8:"line_tax";i:0;}}}'),
(30, 1, 'closedpostboxes_toplevel_page_acf-options', 'a:1:{i:0;s:23:"acf-group_630ae491b6927";}'),
(31, 1, 'metaboxhidden_toplevel_page_acf-options', 'a:0:{}'),
(32, 1, 'session_tokens', 'a:1:{s:64:"71ce12e95729b54eb8f7ce1384f6f34873b8e8701e46ef73351fe24fb090532e";a:4:{s:10:"expiration";i:1666754582;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:84:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:105.0) Gecko/20100101 Firefox/105.0";s:5:"login";i:1665544982;}}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'Lawrence', '$P$BmOhn5OpH4onaZwECBO15IPmaO8V4b0', 'lawrence', 'lthomas@southleft.com', 'http://localhost:8888/jtrc', '2022-05-18 16:16:31', '', 0, 'Lawrence') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_admin_note_actions`
#

DROP TABLE IF EXISTS `wp_wc_admin_note_actions`;


#
# Table structure of table `wp_wc_admin_note_actions`
#

CREATE TABLE `wp_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonce_action` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `nonce_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1480 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_admin_note_actions`
#
INSERT INTO `wp_wc_admin_note_actions` ( `action_id`, `note_id`, `name`, `label`, `query`, `status`, `actioned_text`, `nonce_action`, `nonce_name`) VALUES
(1, 1, 'enable-navigation', 'Enable in Settings', 'http://localhost:8888/jtrc/wp-admin/admin.php?page=wc-settings&tab=advanced&section=features', 'actioned', '', NULL, NULL),
(2, 2, 'add-store-details', 'Add store details', 'http://localhost:8888/jtrc/wp-admin/admin.php?page=wc-admin&path=/setup-wizard', 'actioned', '', NULL, NULL),
(3, 3, 'notify-refund-returns-page', 'Edit page', 'http://localhost:8888/jtrc/wp-admin/post.php?post=35&action=edit', 'actioned', '', NULL, NULL),
(41, 37, 'connect', 'Connect', '?page=wc-addons&section=helper', 'unactioned', '', NULL, NULL),
(42, 38, 'learn_more', 'Learn More', 'https://woocommerce.com/checkout-blocks/', 'actioned', '', NULL, NULL),
(79, 36, 'wc_ipp_order_creation_GTM_launch_q2_2022', 'Grow my business on the go', 'https://woocommerce.com/in-person-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_ipp_order_creation_GTM_launch_q2_2022', 'actioned', '', NULL, NULL),
(80, 39, 'view-payment-gateways', 'Learn more', 'https://woocommerce.com/product-category/woocommerce-extensions/payment-gateways/?utm_medium=product', 'actioned', '', NULL, NULL),
(81, 40, 'learn-more', 'Learn more', 'https://woocommerce.com/payments/?utm_medium=product', 'unactioned', '', NULL, NULL),
(82, 40, 'get-started', 'Get started', 'http://localhost:8888/jtrc/wp-admin/admin.php?page=wc-admin&action=setup-woocommerce-payments', 'actioned', '', 'setup-woocommerce-payments', ''),
(83, 41, 'affirm-insight-first-sale', 'Yes', '', 'actioned', 'Thanks for your feedback', NULL, NULL),
(84, 41, 'deny-insight-first-sale', 'No', '', 'actioned', 'Thanks for your feedback', NULL, NULL),
(120, 35, 'wc-admin-EU-consumer-protection', 'Learn more about these changes', 'https://ec.europa.eu/info/law/law-topic/consumer-protection-law/review-eu-consumer-law_en#guidance', 'actioned', '', NULL, NULL),
(121, 42, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/pre-launch-checklist-the-essentials/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(536, 33, 'setup_task_initiative_survey_q2_2022_share_your_input', 'Share your input', 'https://t.maze.co/87390007', 'actioned', '', NULL, NULL),
(622, 46, 'klarna_q3_2022', 'Grow with Klarna', 'https://woocommerce.com/products/klarna-payments?utm_source=inbox_note&utm_medium=product&utm_campaign=klarna_q3_2022', 'unactioned', '', NULL, NULL),
(628, 50, 'learn-more', 'Learn more', 'https://woocommerce.com/mobile/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(911, 45, 'mercado_pago_q3_2022', 'Free download', 'https://woocommerce.com/products/mercado-pago-checkout/?utm_source=inbox_note&utm_medium=product&utm_campaign=mercado_pago_q3_2022', 'unactioned', '', NULL, NULL),
(916, 49, 'mobile_app_order_management_q3_2022', 'Get the WooCommerce Mobile App', 'https://woocommerce.com/mobile/?utm_source=inbox_note&utm_medium=product&utm_campaign=mobile_app_order_management_q3_2022', 'actioned', '', NULL, NULL),
(1007, 52, 'product_creation_usability_test_6_months_take_a_look', 'Try it now', 'https://t.maze.co/103446424', 'unactioned', '', NULL, NULL),
(1008, 51, 'product_creation_usability_test_3_months_take_a_look', 'Try it now', 'https://t.maze.co/103446424', 'unactioned', '', NULL, NULL),
(1431, 4, 'browse_extensions', 'Browse extensions', 'http://localhost:8888/jtrc/wp-admin/admin.php?page=wc-addons', 'unactioned', '', NULL, NULL),
(1432, 5, 'wayflyer_bnpl_q4_2021', 'Level up with funding', 'https://woocommerce.com/products/wayflyer/?utm_source=inbox_note&utm_medium=product&utm_campaign=wayflyer_bnpl_q4_2021', 'actioned', '', NULL, NULL),
(1433, 6, 'wc_shipping_mobile_app_usps_q4_2021', 'Get WooCommerce Shipping', 'https://woocommerce.com/woocommerce-shipping/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_usps_q4_2021', 'actioned', '', NULL, NULL),
(1434, 7, 'wc_shipping_mobile_app_q4_2021', 'Get the WooCommerce Mobile App', 'https://woocommerce.com/mobile/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_q4_2021', 'actioned', '', NULL, NULL),
(1435, 8, 'set-up-concierge', 'Schedule free session', 'https://wordpress.com/me/concierge', 'actioned', '', NULL, NULL),
(1436, 9, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox', 'unactioned', '', NULL, NULL),
(1437, 10, 'learn-more-ecomm-unique-shopping-experience', 'Learn more', 'https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox', 'actioned', '', NULL, NULL),
(1438, 11, 'watch-the-webinar', 'Watch the webinar', 'https://youtu.be/V_2XtCOyZ7o', 'actioned', '', NULL, NULL),
(1439, 12, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'actioned', '', NULL, NULL),
(1440, 13, 'optimizing-the-checkout-flow', 'Learn more', 'https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=optimizing-the-checkout-flow', 'actioned', '', NULL, NULL),
(1441, 14, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/first-things-customize-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(1442, 15, 'qualitative-feedback-from-new-users', 'Share feedback', 'https://automattic.survey.fm/wc-pay-new', 'actioned', '', NULL, NULL),
(1443, 16, 'share-feedback', 'Share feedback', 'http://automattic.survey.fm/paypal-feedback', 'unactioned', '', NULL, NULL),
(1444, 17, 'get-started', 'Get started', 'https://woocommerce.com/products/google-listings-and-ads?utm_source=inbox_note&utm_medium=product&utm_campaign=get-started', 'actioned', '', NULL, NULL),
(1445, 18, 'update-wc-subscriptions-3-0-15', 'View latest version', 'http://localhost:8888/jtrc/wp-admin/&page=wc-addons&section=helper', 'actioned', '', NULL, NULL),
(1446, 19, 'update-wc-core-5-4-0', 'How to update WooCommerce', 'https://docs.woocommerce.com/document/how-to-update-woocommerce/', 'actioned', '', NULL, NULL),
(1447, 22, 'ppxo-pps-install-paypal-payments-1', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(1448, 23, 'ppxo-pps-install-paypal-payments-2', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(1449, 24, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(1450, 24, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1451, 25, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(1452, 25, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1453, 26, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(1454, 26, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1455, 27, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(1456, 27, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1457, 28, 'share-feedback', 'Share feedback', 'https://automattic.survey.fm/store-management', 'unactioned', '', NULL, NULL),
(1458, 29, 'share-navigation-survey-feedback', 'Share feedback', 'https://automattic.survey.fm/feedback-on-woocommerce-navigation', 'actioned', '', NULL, NULL),
(1459, 30, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(1460, 30, 'woocommerce-core-paypal-march-2022-dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1461, 31, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(1462, 31, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1463, 32, 'pinterest_03_2022_update', 'Update Instructions', 'https://woocommerce.com/document/pinterest-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=pinterest_03_2022_update#section-3', 'actioned', '', NULL, NULL),
(1464, 34, 'store_setup_survey_survey_q2_2022_share_your_thoughts', 'Tell us how it’s going', 'https://automattic.survey.fm/store-setup-survey-2022', 'actioned', '', NULL, NULL),
(1465, 43, 'wc-admin-wisepad3', 'Grow my business offline', 'https://woocommerce.com/products/wisepad3-card-reader/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wisepad3', 'actioned', '', NULL, NULL),
(1466, 47, 'learn-more', 'Find out more', 'https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/', 'unactioned', '', NULL, NULL),
(1467, 47, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1468, 48, 'learn-more', 'Find out more', 'https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/', 'unactioned', '', NULL, NULL),
(1469, 48, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1470, 53, 'googlelistings_signals2022_hasGLA_click', 'Connect Google Listings & Ads', 'http://localhost:8888/jtrc/wp-admin/admin.php?page=wc-admin&path=marketing', 'unactioned', '', NULL, NULL),
(1471, 54, 'googlelistings_signals2022_noGLA', 'Connect Google Listings & Ads', 'https://woocommerce.com/products/google-listings-and-ads/?utm_medium=product&utm_source=inbox_note&utm_campaign=googlelistings_signals2022_noGLA', 'unactioned', '', NULL, NULL),
(1479, 44, 'update-db_done', 'Thanks!', 'http://localhost:8888/jtrc/wp-admin/tools.php?page=wp-migrate-db-pro&wc-hide-notice=update', 'actioned', 'woocommerce_hide_notices_nonce', 'woocommerce_hide_notices_nonce', '_wc_notice_nonce') ;

#
# End of data contents of table `wp_wc_admin_note_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_admin_notes`
#

DROP TABLE IF EXISTS `wp_wc_admin_notes`;


#
# Table structure of table `wp_wc_admin_notes`
#

CREATE TABLE `wp_wc_admin_notes` (
  `note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_520_ci,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT '0',
  `layout` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `icon` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_admin_notes`
#
INSERT INTO `wp_wc_admin_notes` ( `note_id`, `name`, `type`, `locale`, `title`, `content`, `content_data`, `status`, `source`, `date_created`, `date_reminder`, `is_snoozable`, `layout`, `image`, `is_deleted`, `is_read`, `icon`) VALUES
(1, 'wc-admin-navigation-nudge', 'info', 'en_US', 'You now have access to the WooCommerce navigation', 'We’re introducing a new navigation for a more intuitive and improved user experience. You can enable the beta version of the new experience in the Advanced Settings. Enable it now for your store.', '[]', 'unactioned', 'woocommerce-admin', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(2, 'wc-admin-complete-store-details', 'info', 'en_US', 'Add your store details to complete store setup', 'Complete your store details with important information for setup such as your store’s base address', '[]', 'unactioned', 'woocommerce-admin', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(3, 'wc-refund-returns-page', 'info', 'en_US', 'Setup a Refund and Returns Policy page to boost your store\'s credibility.', 'We have created a sample draft Refund and Returns Policy page for you. Please have a look and update it to fit your store.', '[]', 'unactioned', 'woocommerce-core', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(4, 'new_in_app_marketplace_2021', 'info', 'en_US', 'Customize your store with extensions', 'Check out our NEW Extensions tab to see our favorite extensions for customizing your store, and discover the most popular extensions in the WooCommerce Marketplace.', '[]', 'unactioned', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(5, 'wayflyer_bnpl_q4_2021', 'marketing', 'en_US', 'Grow your business with funding through Wayflyer', 'Fast, flexible financing to boost cash flow and help your business grow – one fee, no interest rates, penalties, equity, or personal guarantees. Based on your store’s performance, Wayflyer provides funding and analytical insights to invest in your business.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(6, 'wc_shipping_mobile_app_usps_q4_2021', 'marketing', 'en_US', 'Print and manage your shipping labels with WooCommerce Shipping and the WooCommerce Mobile App', 'Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href="https://woocommerce.com/woocommerce-shipping/">WooCommerce Shipping</a> – all directly from your mobile device!', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(7, 'wc_shipping_mobile_app_q4_2021', 'marketing', 'en_US', 'Print and manage your shipping labels with the WooCommerce Mobile App', 'Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href="https://woocommerce.com/woocommerce-shipping/">WooCommerce Shipping</a> – all directly from your mobile device!', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(8, 'ecomm-need-help-setting-up-your-store', 'info', 'en_US', 'Need help setting up your Store?', 'Schedule a free 30-min <a href="https://wordpress.com/support/concierge-support/">quick start session</a> and get help from our specialists. We’re happy to walk through setup steps, show you around the WordPress.com dashboard, troubleshoot any issues you may have, and help you the find the features you need to accomplish your goals for your site.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(9, 'woocommerce-services', 'info', 'en_US', 'WooCommerce Shipping & Tax', 'WooCommerce Shipping &amp; Tax helps get your store "ready to sell" as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(10, 'ecomm-unique-shopping-experience', 'info', 'en_US', 'For a shopping experience as unique as your customers', 'Product Add-Ons allow your customers to personalize products while they\'re shopping on your online store. No more follow-up email requests—customers get what they want, before they\'re done checking out. Learn more about this extension that comes included in your plan.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(11, 'wc-admin-getting-started-in-ecommerce', 'info', 'en_US', 'Getting Started in eCommerce - webinar', 'We want to make eCommerce and this process of getting started as easy as possible for you. Watch this webinar to get tips on how to have our store up and running in a breeze.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(12, 'your-first-product', 'info', 'en_US', 'Your first product', 'That’s huge! You’re well on your way to building a successful online store — now it’s time to think about how you’ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href="https://href.li/?https://woocommerce.com/shipping" target="_blank">WooCommerce Shipping</a>.', '[]', 'unactioned', 'woocommerce.com', '2022-06-15 01:30:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(13, 'wc-admin-optimizing-the-checkout-flow', 'info', 'en_US', 'Optimizing the checkout flow', 'It’s crucial to get your store’s checkout as smooth as possible to avoid losing sales. Let’s take a look at how you can optimize the checkout experience for your shoppers.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(14, 'wc-admin-first-five-things-to-customize', 'info', 'en_US', 'The first 5 things to customize in your store', 'Deciding what to start with first is tricky. To help you properly prioritize, we’ve put together this short list of the first few things you should customize in WooCommerce.', '[]', 'unactioned', 'woocommerce.com', '2022-06-15 01:30:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(15, 'wc-payments-qualitative-feedback', 'info', 'en_US', 'WooCommerce Payments setup - let us know what you think', 'Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(16, 'share-your-feedback-on-paypal', 'info', 'en_US', 'Share your feedback on PayPal', 'Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(17, 'google_listings_and_ads_install', 'marketing', 'en_US', 'Drive traffic and sales with Google', 'Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(18, 'wc-subscriptions-security-update-3-0-15', 'info', 'en_US', 'WooCommerce Subscriptions security update!', 'We recently released an important security update to WooCommerce Subscriptions. To ensure your site’s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br /><br />Click the button below to view and update to the latest Subscriptions version, or log in to <a href="https://woocommerce.com/my-dashboard">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br /><br />We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br /><br />If you have any questions we are here to help — just <a href="https://woocommerce.com/my-account/create-a-ticket/">open a ticket</a>.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(19, 'woocommerce-core-update-5-4-0', 'info', 'en_US', 'Update to WooCommerce 5.4.1 now', 'WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(20, 'wcpay-promo-2020-11', 'marketing', 'en_US', 'wcpay-promo-2020-11', 'wcpay-promo-2020-11', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(21, 'wcpay-promo-2020-12', 'marketing', 'en_US', 'wcpay-promo-2020-12', 'wcpay-promo-2020-12', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(22, 'ppxo-pps-upgrade-paypal-payments-1', 'info', 'en_US', 'Get the latest PayPal extension for WooCommerce', 'Heads up! There’s a new PayPal on the block!<br /><br />Now is a great time to upgrade to our latest <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">PayPal extension</a> to continue to receive support and updates with PayPal.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(23, 'ppxo-pps-upgrade-paypal-payments-2', 'info', 'en_US', 'Upgrade your PayPal experience!', 'Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br /><br />Start using our <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">latest PayPal today</a> to continue to receive support and updates.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(24, 'woocommerce-core-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(25, 'woocommerce-blocks-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(26, 'woocommerce-core-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(27, 'woocommerce-blocks-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(28, 'habit-moment-survey', 'marketing', 'en_US', 'We’re all ears! Share your experience so far with WooCommerce', 'We’d love your input to shape the future of WooCommerce together. Feel free to share any feedback, ideas or suggestions that you have.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(29, 'ecomm-wc-navigation-survey', 'info', 'en_US', 'We’d like your feedback on the WooCommerce navigation', 'We’re making improvements to the WooCommerce navigation and would love your feedback. Share your experience in this 2 minute survey.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(30, 'woocommerce-core-paypal-march-2022-updated', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy PayPal Standard security updates for stores running WooCommerce (version 3.5 to 6.3). It’s recommended to disable PayPal Standard, and use <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">PayPal Payments</a> to accept PayPal.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(31, 'woocommerce-core-paypal-march-2022-updated-nopp', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy security updates related to PayPal Standard payment gateway for stores running WooCommerce (version 3.5 to 6.3).', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(32, 'pinterest_03_2022_update', 'marketing', 'en_US', 'Your Pinterest for WooCommerce plugin is out of date!', 'Update to the latest version of Pinterest for WooCommerce to continue using this plugin and keep your store connected with Pinterest. To update, visit <strong>Plugins &gt; Installed Plugins</strong>, and click on “update now” under Pinterest for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(33, 'setup_task_initiative_survey_q2_2022', 'survey', 'en_US', 'We want to know what matters most to you', 'Take 2 minutes to give us your input on what is important for you while setting up your store and help shape the future of WooCommerce together.', '[]', 'unactioned', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(34, 'store_setup_survey_survey_q2_2022', 'survey', 'en_US', 'How is your store setup going?', 'Our goal is to make sure you have all the right tools to start setting up your store in the smoothest way possible.\r\nWe’d love to know if we hit our mark and how we can improve. To collect your thoughts, we made a 2-minute survey.', '[]', 'pending', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(35, 'wc-admin-EU-consumer-protection', 'marketing', 'en_US', 'Important changes to EU consumer protection laws', 'New regulations to help modernize and strengthen consumer protection laws in the European Union (EU) take effect on May 28, 2022. These rules impact all merchants selling to the EU, regardless of where their business is located. Further detailed information is available on the European Commission\'s official website.', '[]', 'unactioned', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(36, 'wc_ipp_order_creation_GTM_launch_q2_2022', 'marketing', 'en_US', 'Grow your business on the go with WooCommerce In-Person Payments', 'Quickly create new orders, manage transactions, and take secure payments no matter where your business takes you. With automatic inventory sync, WooCommerce In-Person Payments is the only fully integrated solution for taking your WooCommerce store offline.', '[]', 'unactioned', 'woocommerce.com', '2022-05-29 19:51:45', NULL, 0, 'plain', '', 0, 0, 'info'),
(37, 'wc-admin-wc-helper-connection', 'info', 'en_US', 'Connect to WooCommerce.com', 'Connect to get important product notifications and updates.', '[]', 'unactioned', 'woocommerce-admin', '2022-05-29 19:51:46', NULL, 0, 'plain', '', 0, 0, 'info'),
(38, 'surface_cart_checkout', 'info', 'en_US', 'Introducing the Cart and Checkout blocks!', 'Increase your store\'s revenue with the conversion optimized Cart &amp; Checkout WooCommerce blocks available in the WooCommerce Blocks extension.', '[]', 'unactioned', 'woo-gutenberg-products-block', '2022-05-29 19:51:46', NULL, 0, 'plain', '', 0, 0, 'info'),
(39, 'wc-admin-onboarding-payments-reminder', 'info', 'en_US', 'Start accepting payments on your store!', 'Take payments with the provider that’s right for you - choose from 100+ payment gateways for WooCommerce.', '[]', 'unactioned', 'woocommerce-admin', '2022-06-15 01:30:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(40, 'wc-admin-woocommerce-payments', 'marketing', 'en_US', 'Try the new way to get paid', 'Securely accept credit and debit cards on your site. Manage transactions without leaving your WordPress dashboard. Only with <strong>WooCommerce Payments</strong>.<br><br>By clicking "Get started", you agree to our <a href="https://wordpress.com/tos/" target="_blank">Terms of Service</a>', '[]', 'unactioned', 'woocommerce-admin', '2022-06-15 01:30:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(41, 'wc-admin-insight-first-sale', 'survey', 'en_US', 'Did you know?', 'A WooCommerce powered store needs on average 31 days to get the first sale. You\'re on the right track! Do you find this type of insight useful?', '[]', 'unactioned', 'woocommerce-admin', '2022-06-15 01:30:50', NULL, 0, 'plain', '', 0, 0, 'info'),
(42, 'wc-admin-launch-checklist', 'info', 'en_US', 'Ready to launch your store?', 'To make sure you never get that sinking "what did I forget" feeling, we\'ve put together the essential pre-launch checklist.', '[]', 'unactioned', 'woocommerce-admin', '2022-07-14 17:24:32', NULL, 0, 'plain', '', 0, 0, 'info'),
(43, 'wc-admin-wisepad3', 'marketing', 'en_US', 'Take your business on the go in Canada with WooCommerce In-Person Payments', 'Quickly create new orders, accept payment in person for orders placed online, and automatically sync your inventory – no matter where your business takes you. With WooCommerce In-Person Payments and the WisePad 3 card reader, you can bring the power of your store anywhere.', '[]', 'pending', 'woocommerce.com', '2022-07-14 17:24:32', NULL, 0, 'plain', '', 0, 0, 'info'),
(44, 'wc-update-db-reminder', 'update', 'en_US', 'WooCommerce database update done', 'WooCommerce database update complete. Thank you for updating to the latest version!', '[]', 'unactioned', 'woocommerce-core', '2022-07-14 19:26:38', NULL, 0, 'plain', '', 0, 0, 'info'),
(45, 'mercado_pago_q3_2022', 'marketing', 'en_US', 'Get paid with Mercado Pago Checkout', 'Give your customers a checkout they can trust with Latin America\'s leading payment processor. Securely accept debit and credit cards, cash, bank transfers, and installment payments – backed by exclusive fraud prevention tools.', '[]', 'pending', 'woocommerce.com', '2022-08-20 15:54:10', NULL, 0, 'plain', '', 0, 0, 'info'),
(46, 'klarna_q3_2022', 'marketing', 'en_US', 'Meet Klarna – your ultimate growth partner', 'Increase conversions by offering secure, flexible payment solutions – including buy now, pay later – all through a one-click checkout experience. Plus, you’ll tap into a whole new market of the world’s most engaged shoppers.', '[]', 'unactioned', 'woocommerce.com', '2022-08-20 15:54:10', NULL, 0, 'plain', '', 0, 0, 'info'),
(47, 'woocommerce-payments-august-2022-need-to-update', 'update', 'en_US', 'Action required: Please update WooCommerce Payments', 'An updated secure version of WooCommerce Payments is available – please ensure that you’re using the latest patch version. For more information on what action you need to take, please review the article below.', '[]', 'pending', 'woocommerce.com', '2022-08-20 15:54:10', NULL, 0, 'plain', '', 0, 0, 'info'),
(48, 'woocommerce-payments-august-2022-store-patched', 'update', 'en_US', 'WooCommerce Payments has been automatically updated', 'You’re now running the latest secure version of WooCommerce Payments. We’ve worked with the WordPress Plugins team to deploy a security update to stores running WooCommerce Payments (version 3.9 to 4.5). For further information, please review the article below.', '[]', 'pending', 'woocommerce.com', '2022-08-20 15:54:10', NULL, 0, 'plain', '', 0, 0, 'info'),
(49, 'mobile_app_order_management_q3_2022', 'marketing', 'en_US', 'Take order management on the go', 'The WooCommerce Mobile App continues to get better with added order management functionality! Add or remove products, edit fees, or change the shipping options in any existing order – all from within the app.', '[]', 'unactioned', 'woocommerce.com', '2022-08-20 15:54:10', NULL, 0, 'plain', '', 0, 0, 'info'),
(50, 'wc-admin-real-time-order-alerts', 'info', 'en_US', 'Get real-time order alerts anywhere', 'Get notifications about store activity, including new orders and product reviews directly on your mobile devices with the Woo app.', '[]', 'unactioned', 'woocommerce-admin', '2022-08-27 21:05:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(51, 'product_creation_usability_test_3_months', 'survey', 'en_US', 'Have a say in the future of WooCommerce', 'Take an early look at the future of editing products in WooCommerce. Share your thoughts (~5 minutes) and help shape the experience for yourself and other merchants.', '[]', 'pending', 'woocommerce.com', '2022-08-27 21:05:09', NULL, 0, 'plain', '', 0, 0, 'info'),
(52, 'product_creation_usability_test_6_months', 'survey', 'en_US', 'Try the new product edit form prototype', 'Take an early look at the future of editing products in WooCommerce. Share your thoughts (~5 minutes) and help shape the experience for yourself and other merchants.', '[]', 'pending', 'woocommerce.com', '2022-09-04 23:47:25', NULL, 0, 'plain', '', 0, 0, 'info'),
(53, 'googlelistings_signals2022_hasGLA', 'marketing', 'en_US', 'Show off your products with Ads on Google', 'You’re ready to grow with ads. Google optimizes for performance across your products; you only pay for results. If you’re new to Google, you can earn up to $500 in ad credits (T&amp;Cs apply). <a href="https://woocommerce.com/my-account/create-a-ticket/">Contact support</a> if you need guidance with Google Listings &amp; Ads.', '[]', 'pending', 'woocommerce.com', '2022-09-27 14:29:42', NULL, 0, 'plain', '', 0, 0, 'info'),
(54, 'googlelistings_signals2022_noGLA', 'marketing', 'en_US', 'Show off your products with Ads on Google', 'You’re ready to grow with ads. Google optimizes for performance across your products; you only pay for results. If you’re new to Google, you can earn up to $500 in ad credits (T&amp;Cs apply). <a href="https://woocommerce.com/my-account/create-a-ticket/">Contact support</a> if you need guidance with Google Listings &amp; Ads.', '[]', 'pending', 'woocommerce.com', '2022-09-27 14:29:42', NULL, 0, 'plain', '', 0, 0, 'info') ;

#
# End of data contents of table `wp_wc_admin_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_category_lookup`
#

DROP TABLE IF EXISTS `wp_wc_category_lookup`;


#
# Table structure of table `wp_wc_category_lookup`
#

CREATE TABLE `wp_wc_category_lookup` (
  `category_tree_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_category_lookup`
#
INSERT INTO `wp_wc_category_lookup` ( `category_tree_id`, `category_id`) VALUES
(17, 17),
(19, 19),
(20, 20) ;

#
# End of data contents of table `wp_wc_category_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_customer_lookup`
#

DROP TABLE IF EXISTS `wp_wc_customer_lookup`;


#
# Table structure of table `wp_wc_customer_lookup`
#

CREATE TABLE `wp_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_customer_lookup`
#

#
# End of data contents of table `wp_wc_customer_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_download_log`
#

DROP TABLE IF EXISTS `wp_wc_download_log`;


#
# Table structure of table `wp_wc_download_log`
#

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_download_log`
#

#
# End of data contents of table `wp_wc_download_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_coupon_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_coupon_lookup`;


#
# Table structure of table `wp_wc_order_coupon_lookup`
#

CREATE TABLE `wp_wc_order_coupon_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_coupon_lookup`
#

#
# End of data contents of table `wp_wc_order_coupon_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_product_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_product_lookup`;


#
# Table structure of table `wp_wc_order_product_lookup`
#

CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT '0',
  `product_gross_revenue` double NOT NULL DEFAULT '0',
  `coupon_amount` double NOT NULL DEFAULT '0',
  `tax_amount` double NOT NULL DEFAULT '0',
  `shipping_amount` double NOT NULL DEFAULT '0',
  `shipping_tax_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_product_lookup`
#

#
# End of data contents of table `wp_wc_order_product_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_stats`
#

DROP TABLE IF EXISTS `wp_wc_order_stats`;


#
# Table structure of table `wp_wc_order_stats`
#

CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT '0',
  `total_sales` double NOT NULL DEFAULT '0',
  `tax_total` double NOT NULL DEFAULT '0',
  `shipping_total` double NOT NULL DEFAULT '0',
  `net_total` double NOT NULL DEFAULT '0',
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_stats`
#

#
# End of data contents of table `wp_wc_order_stats`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_tax_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_tax_lookup`;


#
# Table structure of table `wp_wc_order_tax_lookup`
#

CREATE TABLE `wp_wc_order_tax_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT '0',
  `order_tax` double NOT NULL DEFAULT '0',
  `total_tax` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`tax_rate_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_tax_lookup`
#

#
# End of data contents of table `wp_wc_order_tax_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_attributes_lookup`
#

DROP TABLE IF EXISTS `wp_wc_product_attributes_lookup`;


#
# Table structure of table `wp_wc_product_attributes_lookup`
#

CREATE TABLE `wp_wc_product_attributes_lookup` (
  `product_id` bigint(20) NOT NULL,
  `product_or_parent_id` bigint(20) NOT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `term_id` bigint(20) NOT NULL,
  `is_variation_attribute` tinyint(1) NOT NULL,
  `in_stock` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_or_parent_id`,`term_id`,`product_id`,`taxonomy`),
  KEY `is_variation_attribute_term_id` (`is_variation_attribute`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_attributes_lookup`
#

#
# End of data contents of table `wp_wc_product_attributes_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_download_directories`
#

DROP TABLE IF EXISTS `wp_wc_product_download_directories`;


#
# Table structure of table `wp_wc_product_download_directories`
#

CREATE TABLE `wp_wc_product_download_directories` (
  `url_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`url_id`),
  KEY `url` (`url`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_download_directories`
#
INSERT INTO `wp_wc_product_download_directories` ( `url_id`, `url`, `enabled`) VALUES
(1, 'file:///Users/lawrence/Sites/localhost/jtrc/wp-content/uploads/woocommerce_uploads/', 1),
(2, 'http://localhost:8888/jtrc/wp-content/uploads/woocommerce_uploads/', 1) ;

#
# End of data contents of table `wp_wc_product_download_directories`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_meta_lookup`
#

DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;


#
# Table structure of table `wp_wc_product_meta_lookup`
#

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT '0',
  `downloadable` tinyint(1) DEFAULT '0',
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT '0',
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT '0',
  `average_rating` decimal(3,2) DEFAULT '0.00',
  `total_sales` bigint(20) DEFAULT '0',
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_meta_lookup`
#
INSERT INTO `wp_wc_product_meta_lookup` ( `product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`, `tax_status`, `tax_class`) VALUES
(62, '', 0, 0, '50.0000', '100.0000', 0, NULL, 'instock', 1, '5.00', 0, 'taxable', ''),
(63, '', 0, 0, '50.0000', '50.0000', 0, NULL, 'outofstock', 0, '0.00', 0, 'taxable', ''),
(66, '', 0, 0, '100.0000', '100.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(69, '', 0, 0, '40.0000', '40.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(96, '', 0, 0, '100.0000', '100.0000', 0, NULL, 'outofstock', 0, '0.00', 0, 'taxable', '') ;

#
# End of data contents of table `wp_wc_product_meta_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_rate_limits`
#

DROP TABLE IF EXISTS `wp_wc_rate_limits`;


#
# Table structure of table `wp_wc_rate_limits`
#

CREATE TABLE `wp_wc_rate_limits` (
  `rate_limit_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rate_limit_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `rate_limit_expiry` bigint(20) unsigned NOT NULL,
  `rate_limit_remaining` smallint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rate_limit_id`),
  UNIQUE KEY `rate_limit_key` (`rate_limit_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_rate_limits`
#

#
# End of data contents of table `wp_wc_rate_limits`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_reserved_stock`
#

DROP TABLE IF EXISTS `wp_wc_reserved_stock`;


#
# Table structure of table `wp_wc_reserved_stock`
#

CREATE TABLE `wp_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT '0',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_reserved_stock`
#

#
# End of data contents of table `wp_wc_reserved_stock`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_tax_rate_classes`
#

DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;


#
# Table structure of table `wp_wc_tax_rate_classes`
#

CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_tax_rate_classes`
#
INSERT INTO `wp_wc_tax_rate_classes` ( `tax_rate_class_id`, `name`, `slug`) VALUES
(1, 'Reduced rate', 'reduced-rate'),
(2, 'Zero rate', 'zero-rate') ;

#
# End of data contents of table `wp_wc_tax_rate_classes`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_webhooks`
#

DROP TABLE IF EXISTS `wp_wc_webhooks`;


#
# Table structure of table `wp_wc_webhooks`
#

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_webhooks`
#

#
# End of data contents of table `wp_wc_webhooks`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_api_keys`
#

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;


#
# Table structure of table `wp_woocommerce_api_keys`
#

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_api_keys`
#

#
# End of data contents of table `wp_woocommerce_api_keys`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;


#
# Table structure of table `wp_woocommerce_attribute_taxonomies`
#

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_attribute_taxonomies`
#

#
# End of data contents of table `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `wp_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_downloadable_product_permissions`
#

#
# End of data contents of table `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_log`
#

DROP TABLE IF EXISTS `wp_woocommerce_log`;


#
# Table structure of table `wp_woocommerce_log`
#

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_log`
#

#
# End of data contents of table `wp_woocommerce_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;


#
# Table structure of table `wp_woocommerce_order_itemmeta`
#

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_order_itemmeta`
#

#
# End of data contents of table `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_items`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;


#
# Table structure of table `wp_woocommerce_order_items`
#

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_order_items`
#

#
# End of data contents of table `wp_woocommerce_order_items`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokenmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;


#
# Table structure of table `wp_woocommerce_payment_tokenmeta`
#

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_payment_tokenmeta`
#

#
# End of data contents of table `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokens`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;


#
# Table structure of table `wp_woocommerce_payment_tokens`
#

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_payment_tokens`
#

#
# End of data contents of table `wp_woocommerce_payment_tokens`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_sessions`
#

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;


#
# Table structure of table `wp_woocommerce_sessions`
#

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_sessions`
#
INSERT INTO `wp_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(1, '1', 'a:7:{s:4:"cart";s:412:"a:1:{s:32:"3295c76acbf4caaed33c36b1b5fc2cb1";a:11:{s:3:"key";s:32:"3295c76acbf4caaed33c36b1b5fc2cb1";s:10:"product_id";i:66;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:100;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:100;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:396:"a:15:{s:8:"subtotal";s:3:"100";s:12:"subtotal_tax";i:0;s:14:"shipping_total";s:1:"0";s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";s:3:"100";s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:6:"100.00";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:742:"a:27:{s:2:"id";s:1:"1";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:2:"NY";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:2:"NY";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:21:"lthomas@southleft.com";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";s:14:"shipping_phone";s:0:"";}";}', 1665717787) ;

#
# End of data contents of table `wp_woocommerce_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;


#
# Table structure of table `wp_woocommerce_shipping_zone_locations`
#

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_locations`
#

#
# End of data contents of table `wp_woocommerce_shipping_zone_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_methods`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;


#
# Table structure of table `wp_woocommerce_shipping_zone_methods`
#

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_methods`
#

#
# End of data contents of table `wp_woocommerce_shipping_zone_methods`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zones`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;


#
# Table structure of table `wp_woocommerce_shipping_zones`
#

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zones`
#

#
# End of data contents of table `wp_woocommerce_shipping_zones`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;


#
# Table structure of table `wp_woocommerce_tax_rate_locations`
#

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_tax_rate_locations`
#

#
# End of data contents of table `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;


#
# Table structure of table `wp_woocommerce_tax_rates`
#

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_tax_rates`
#

#
# End of data contents of table `wp_woocommerce_tax_rates`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

ALTER TABLE `wp_wc_download_log`
  ADD CONSTRAINT `fk_wp_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE;

